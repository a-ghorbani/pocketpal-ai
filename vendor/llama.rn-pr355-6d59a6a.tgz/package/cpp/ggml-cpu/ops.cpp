#include "ops.h"

#include "ggml-cpu.h"
#include "ggml-impl.h"
#include "binary-ops.h"
#include "simd-gemm.h"
#include "ggml.h"
#include "unary-ops.h"
#include "vec.h"

#include <algorithm>
#include <cfloat>
#include <cmath>

// lm_ggml_compute_forward_dup

static void lm_ggml_compute_forward_dup_same_cont(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    LM_GGML_ASSERT(lm_ggml_nelements(dst) == lm_ggml_nelements(src0));
    LM_GGML_ASSERT(lm_ggml_is_contiguous(dst) && lm_ggml_is_contiguous(src0));
    LM_GGML_ASSERT(src0->type == dst->type);

    const size_t nb0 = lm_ggml_type_size(src0->type);

    const int ith = params->ith; // thread index
    const int nth = params->nth; // number of threads

    // parallelize by blocks
    const int nk = lm_ggml_nelements(src0)/lm_ggml_blck_size(src0->type);
    const int dr = (nk + nth - 1) / nth;
    const int k0 = dr * ith;
    const int k1 = MIN(k0 + dr, nk);

    if (k0 < k1) {
        memcpy(
            ((char *)  dst->data + k0*nb0),
            ((char *) src0->data + k0*nb0),
            (k1 - k0) * nb0);
    }
}

template<typename src_t, typename dst_t>
static void lm_ggml_compute_forward_dup_flt(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    LM_GGML_ASSERT(lm_ggml_nelements(dst) == lm_ggml_nelements(src0));
    LM_GGML_ASSERT(!lm_ggml_is_quantized(src0->type) && !lm_ggml_is_quantized(dst->type));

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    const int ith = params->ith; // thread index
    const int nth = params->nth; // number of threads

    // parallelize by rows
    const int nr = ne01;
    // number of rows per thread
    const int dr = (nr + nth - 1) / nth;
    // row range for this thread
    const int ir0 = dr * ith;
    const int ir1 = MIN(ir0 + dr, nr);

    // case: type & row size equal
    if (src0->type == dst->type &&
        ne00 == ne0 &&
        nb00 == lm_ggml_type_size(src0->type) && nb0 == lm_ggml_type_size(dst->type)) {
        // copy by rows
        const size_t rs = ne00*nb00;
        for (int64_t i03 = 0; i03 < ne03; i03++) {
            for (int64_t i02 = 0; i02 < ne02; i02++) {
                for (int64_t i01 = ir0; i01 < ir1; i01++) {
                    memcpy(
                        ((char *)  dst->data + i01*nb1  + i02*nb2  + i03*nb3),
                        ((char *) src0->data + i01*nb01 + i02*nb02 + i03*nb03),
                        rs);
                }
            }
        }
        return;
    }

    // case: dst tensor is contiguous
    if (lm_ggml_is_contiguous(dst)) {
        if (nb00 == sizeof(src_t)) {
            if constexpr (std::is_same_v<dst_t, src_t>) {
                // same type
                size_t id = 0;
                const size_t rs = ne00 * nb00;
                char * dst_ptr = (char *) dst->data;

                for (int i03 = 0; i03 < ne03; i03++) {
                    for (int i02 = 0; i02 < ne02; i02++) {
                        id += rs * ir0;
                        for (int i01 = ir0; i01 < ir1; i01++) {
                            const char * src0_ptr = (char *) src0->data + i01*nb01 + i02*nb02 + i03*nb03;
                            memcpy(dst_ptr + id, src0_ptr, rs);
                            id += rs;
                        }
                        id += rs * (ne01 - ir1);
                    }
                }
            } else {
                // casting between non-quantized types
                size_t id = 0;
                dst_t * dst_ptr = (dst_t *) dst->data;

                for (int i03 = 0; i03 < ne03; i03++) {
                    for (int i02 = 0; i02 < ne02; i02++) {
                        id += ne00 * ir0;
                        for (int i01 = ir0; i01 < ir1; i01++) {
                            const src_t * src0_ptr = (src_t *) ((char *) src0->data + i01*nb01 + i02*nb02 + i03*nb03);
                            for (int i00 = 0; i00 < ne00; i00++) {
                                float tmp = type_conversion_table<src_t>::to_f32(src0_ptr[i00]);
                                dst_ptr[id] = type_conversion_table<dst_t>::from_f32(tmp);
                                id++;
                            }
                        }
                        id += ne00 * (ne01 - ir1);
                    }
                }
            }
        } else {
            //printf("%s: this is not optimal - fix me\n", __func__);

            size_t id = 0;
            dst_t * dst_ptr = (dst_t *) dst->data;

            for (int i03 = 0; i03 < ne03; i03++) {
                for (int i02 = 0; i02 < ne02; i02++) {
                    id += ne00 * ir0;
                    for (int i01 = ir0; i01 < ir1; i01++) {
                        for (int i00 = 0; i00 < ne00; i00++) {
                            const src_t * src0_ptr = (src_t *) ((char *) src0->data + i00*nb00 + i01*nb01 + i02*nb02 + i03*nb03);

                            float tmp = type_conversion_table<src_t>::to_f32(*src0_ptr);
                            dst_ptr[id] = type_conversion_table<dst_t>::from_f32(tmp);
                            id++;
                        }
                    }
                    id += ne00 * (ne01 - ir1);
                }
            }
        }
        return;
    }

    // dst counters
    int64_t i10 = 0;
    int64_t i11 = 0;
    int64_t i12 = 0;
    int64_t i13 = 0;

    if constexpr (std::is_same_v<dst_t, src_t>) {
        for (int64_t i03 = 0; i03 < ne03; i03++) {
            for (int64_t i02 = 0; i02 < ne02; i02++) {
                i10 += ne00 * ir0;
                while (i10 >= ne0) {
                    i10 -= ne0;
                    if (++i11 == ne1) {
                        i11 = 0;
                        if (++i12 == ne2) {
                            i12 = 0;
                            if (++i13 == ne3) {
                                i13 = 0;
                            }
                        }
                    }
                }
                for (int64_t i01 = ir0; i01 < ir1; i01++) {
                    for (int64_t i00 = 0; i00 < ne00; i00++) {
                        const char * src0_ptr = ((char *) src0->data + i00*nb00 + i01*nb01 + i02*nb02 + i03*nb03);
                              char * dst_ptr  = ((char *)  dst->data + i10*nb0  + i11*nb1  + i12*nb2  + i13*nb3);

                        memcpy(dst_ptr, src0_ptr, sizeof(dst_t));

                        if (++i10 == ne00) {
                            i10 = 0;
                            if (++i11 == ne01) {
                                i11 = 0;
                                if (++i12 == ne02) {
                                    i12 = 0;
                                    if (++i13 == ne03) {
                                        i13 = 0;
                                    }
                                }
                            }
                        }
                    }
                }
                i10 += ne00 * (ne01 - ir1);
                while (i10 >= ne0) {
                    i10 -= ne0;
                    if (++i11 == ne1) {
                        i11 = 0;
                        if (++i12 == ne2) {
                            i12 = 0;
                            if (++i13 == ne3) {
                                i13 = 0;
                            }
                        }
                    }
                }
            }
        }

    } else {
        for (int64_t i03 = 0; i03 < ne03; i03++) {
            for (int64_t i02 = 0; i02 < ne02; i02++) {
                i10 += ne00 * ir0;
                while (i10 >= ne0) {
                    i10 -= ne0;
                    if (++i11 == ne1) {
                        i11 = 0;
                        if (++i12 == ne2) {
                            i12 = 0;
                            if (++i13 == ne3) {
                                i13 = 0;
                            }
                        }
                    }
                }
                for (int64_t i01 = ir0; i01 < ir1; i01++) {
                    for (int64_t i00 = 0; i00 < ne00; i00++) {
                        const char * src0_ptr = ((char *) src0->data + i00*nb00 + i01*nb01 + i02*nb02 + i03*nb03);
                              char * dst_ptr  = ((char *)  dst->data + i10*nb0  + i11*nb1  + i12*nb2  + i13*nb3);

                        float tmp = type_conversion_table<src_t>::to_f32(*(const src_t *) src0_ptr);
                        *(dst_t *) dst_ptr = type_conversion_table<dst_t>::from_f32(tmp);

                        if (++i10 == ne0) {
                            i10 = 0;
                            if (++i11 == ne1) {
                                i11 = 0;
                                if (++i12 == ne2) {
                                    i12 = 0;
                                    if (++i13 == ne3) {
                                        i13 = 0;
                                    }
                                }
                            }
                        }
                    }
                }
                i10 += ne00 * (ne01 - ir1);
                while (i10 >= ne0) {
                    i10 -= ne0;
                    if (++i11 == ne1) {
                        i11 = 0;
                        if (++i12 == ne2) {
                            i12 = 0;
                            if (++i13 == ne3) {
                                i13 = 0;
                            }
                        }
                    }
                }
            }
        }
    }
}


template<typename src_t>
static void lm_ggml_compute_forward_dup_to_q(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    LM_GGML_ASSERT(lm_ggml_nelements(dst) == lm_ggml_nelements(src0));
    LM_GGML_ASSERT(!lm_ggml_is_quantized(src0->type));

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    const int ith = params->ith; // thread index
    const int nth = params->nth; // number of threads

    // parallelize by rows
    const int nr = ne01;
    // number of rows per thread
    const int dr = (nr + nth - 1) / nth;
    // row range for this thread
    const int ir0 = dr * ith;
    const int ir1 = MIN(ir0 + dr, nr);

    if (lm_ggml_is_contiguous(dst) &&
            nb00 == sizeof(src_t) &&
            lm_ggml_get_type_traits_cpu(dst->type)->from_float) {
        // casting non-quantized types --> intermediate f32 --> quantized
        lm_ggml_from_float_t const quantize_row_q = lm_ggml_get_type_traits_cpu(dst->type)->from_float;
        float * src0_f32 = (float *) params->wdata + (ne00 + CACHE_LINE_SIZE_F32) * ith;

        size_t id = 0;
        size_t rs = nb0 * (ne00 / lm_ggml_blck_size(dst->type));
        char * dst_ptr = (char *) dst->data;

        for (int i03 = 0; i03 < ne03; i03++) {
            for (int i02 = 0; i02 < ne02; i02++) {
                id += rs * ir0;
                for (int i01 = ir0; i01 < ir1; i01++) {
                    const src_t * src0_ptr = (src_t *) ((char *) src0->data + i01*nb01 + i02*nb02 + i03*nb03);

                    for (int i00 = 0; i00 < ne00; i00++) {
                        src0_f32[i00] = type_conversion_table<src_t>::to_f32(src0_ptr[i00]);
                    }

                    quantize_row_q(src0_f32, dst_ptr + id, ne00);
                    id += rs;
                }
                id += rs * (ne01 - ir1);
            }
        }
    } else {
        // printf("%s %s\n", lm_ggml_type_name(src0->type), lm_ggml_type_name(dst->type));
        LM_GGML_ABORT("not implemented");
    }
}

// A simplified version of lm_ggml_compute_forward_dup that doesn't do float upcasting, and just plain old memcpy.
static void lm_ggml_compute_forward_dup_bytes(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {
    const lm_ggml_tensor * src0 = dst->src[0];

    LM_GGML_ASSERT(lm_ggml_nelements(dst) == lm_ggml_nelements(src0));
    LM_GGML_ASSERT(src0->type == dst->type);

    LM_GGML_TENSOR_UNARY_OP_LOCALS;

    if (lm_ggml_is_contiguous(src0) && lm_ggml_is_contiguous(dst)) {
        lm_ggml_compute_forward_dup_same_cont(params, dst);
        return;
    }

    const size_t type_size = lm_ggml_type_size(src0->type);

    const int ith = params->ith; // thread index
    const int nth = params->nth; // number of threads

    // parallelize by rows
    const int nr = ne01;
    // number of rows per thread
    const int dr = (nr + nth - 1) / nth;
    // row range for this thread
    const int ir0 = dr * ith;
    const int ir1 = MIN(ir0 + dr, nr);

    if (src0->type == dst->type &&
        lm_ggml_are_same_shape(src0, dst) &&
        nb00 == type_size && nb0 == type_size) {
        // copy by rows
        const size_t rs = lm_ggml_row_size(src0->type, ne00);
        for (int64_t i03 = 0; i03 < ne03; i03++) {
            for (int64_t i02 = 0; i02 < ne02; i02++) {
                for (int64_t i01 = ir0; i01 < ir1; i01++) {
                    memcpy(
                        ((char *)  dst->data + i01*nb1  + i02*nb2  + i03*nb3),
                        ((char *) src0->data + i01*nb01 + i02*nb02 + i03*nb03),
                        rs);
                }
            }
        }
        return;
    }

    if (lm_ggml_is_contiguous(dst)) {
        size_t id = 0;
        char * dst_ptr = (char *) dst->data;
        const size_t rs = ne00 * type_size;

        if (nb00 == type_size) {
            // src0 is contiguous on first dimension, copy by rows
            for (int64_t i03 = 0; i03 < ne03; i03++) {
                for (int64_t i02 = 0; i02 < ne02; i02++) {
                    id += rs * ir0;
                    for (int64_t i01 = ir0; i01 < ir1; i01++) {
                        const char * src0_ptr = (char *) src0->data + i01*nb01 + i02*nb02 + i03*nb03;
                        memcpy(dst_ptr + id, src0_ptr, rs);
                        id += rs;
                    }
                    id += rs * (ne01 - ir1);
                }
            }
        } else {
            //printf("%s: this is not optimal - fix me\n", __func__);

            for (int64_t i03 = 0; i03 < ne03; i03++) {
                for (int64_t i02 = 0; i02 < ne02; i02++) {
                    id += rs * ir0;
                    for (int64_t i01 = ir0; i01 < ir1; i01++) {
                        for (int64_t i00 = 0; i00 < ne00; i00++) {
                            const char * src0_ptr = (char *) src0->data + i00*nb00 + i01*nb01 + i02*nb02 + i03*nb03;
                            memcpy(dst_ptr + id, src0_ptr, type_size);

                            id += type_size;
                        }
                    }
                    id += rs * (ne01 - ir1);
                }
            }
        }

        return;
    }

    // dst counters
    int64_t k10 = 0;
    int64_t i11 = 0;
    int64_t i12 = 0;
    int64_t i13 = 0;

    // number of blocks in a row
    const int64_t nk00 = ne00 / lm_ggml_blck_size(src0->type);
    const int64_t nk0  = ne0  / lm_ggml_blck_size(dst->type);

    for (int64_t i03 = 0; i03 < ne03; i03++) {
        for (int64_t i02 = 0; i02 < ne02; i02++) {
            k10 += nk00 * ir0;
            while (k10 >= nk0) {
                k10 -= nk0;
                if (++i11 == ne1) {
                    i11 = 0;
                    if (++i12 == ne2) {
                        i12 = 0;
                        if (++i13 == ne3) {
                            i13 = 0;
                        }
                    }
                }
            }
            for (int64_t i01 = ir0; i01 < ir1; i01++) {
                for (int64_t k00 = 0; k00 < nk00; k00++) {
                    const char * src0_ptr = ((char *) src0->data + k00*nb00 + i01*nb01 + i02*nb02 + i03*nb03);
                          char * dst_ptr  = ((char *)  dst->data + k10*nb0  + i11*nb1  + i12*nb2  + i13*nb3);

                    memcpy(dst_ptr, src0_ptr, type_size);

                    if (++k10 == nk0) {
                        k10 = 0;
                        if (++i11 == ne1) {
                            i11 = 0;
                            if (++i12 == ne2) {
                                i12 = 0;
                                if (++i13 == ne3) {
                                    i13 = 0;
                                }
                            }
                        }
                    }
                }
            }
            k10 += nk00 * (ne01 - ir1);
            while (k10 >= nk0) {
                k10 -= nk0;
                if (++i11 == ne1) {
                    i11 = 0;
                    if (++i12 == ne2) {
                        i12 = 0;
                        if (++i13 == ne3) {
                            i13 = 0;
                        }
                    }
                }
            }
        }
    }
}

static void lm_ggml_compute_forward_dup_from_q(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    const lm_ggml_type type = src0->type;
    lm_ggml_to_float_t const dequantize_row_q = lm_ggml_get_type_traits(type)->to_float;

    size_t qk = lm_ggml_blck_size(type);
    const int64_t nr = lm_ggml_nelements(src1) / qk;

    // destination must be contiguous in the first dimension
    LM_GGML_ASSERT(nb10 == lm_ggml_type_size(dst->type));
    // must either have first dimension large enough to hold a row, or fully contiguous
    LM_GGML_ASSERT((ne10 % qk) == 0 || lm_ggml_is_contiguous(dst));

    const int ith = params->ith;
    const int nth = params->nth;

    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int64_t ir = ir0; ir < ir1; ++ir) {

        uint32_t i = ir * qk;

        const int64_t i03 = i/(ne00 * ne01 * ne02);
        const int64_t i02 = (i - i03*ne00*ne01*ne02 )/ (ne00*ne01);
        const int64_t i01 = (i - i03*ne00*ne01*ne02  -  i02*ne01*ne00) / ne00;
        const int64_t i00 = i - i03*ne00*ne01*ne02 - i02*ne01*ne00 - i01*ne00;
        const int64_t x_offset = (i00/qk)*nb00 + i01*nb01 + i02*nb02 + i03 * nb03;

        const int64_t i13 = i/(ne10 * ne11 * ne12);
        const int64_t i12 = (i - i13*ne10*ne11*ne12) / (ne10*ne11);
        const int64_t i11 = (i - i13*ne10*ne11*ne12 - i12*ne10*ne11) / ne10;
        const int64_t i10 = i - i13*ne10*ne11*ne12 - i12*ne10*ne11 - i11*ne10;
        const int64_t dst_offset = i10*nb10 + i11*nb11 + i12*nb12 + i13*nb13;

        dequantize_row_q(
                (const void *) ((char *) src0->data + x_offset),
                     (float *) ((char *)  dst->data + dst_offset), qk);
    }
}

void lm_ggml_compute_forward_dup(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    if (src0->type == dst->type) {
        lm_ggml_compute_forward_dup_bytes(params, dst);
        return;
    }

    switch (src0->type) {
        case LM_GGML_TYPE_F16:
            {
                /**/ if (dst->type == LM_GGML_TYPE_F16)  lm_ggml_compute_forward_dup_flt<lm_ggml_fp16_t, lm_ggml_fp16_t>(params, dst);
                else if (dst->type == LM_GGML_TYPE_BF16) lm_ggml_compute_forward_dup_flt<lm_ggml_fp16_t, lm_ggml_bf16_t>(params, dst);
                else if (dst->type == LM_GGML_TYPE_F32)  lm_ggml_compute_forward_dup_flt<lm_ggml_fp16_t, float      >(params, dst);
                else lm_ggml_compute_forward_dup_to_q<lm_ggml_fp16_t>(params, dst);
            } break;
        case LM_GGML_TYPE_BF16:
            {
                /**/ if (dst->type == LM_GGML_TYPE_F16)  lm_ggml_compute_forward_dup_flt<lm_ggml_bf16_t, lm_ggml_fp16_t>(params, dst);
                else if (dst->type == LM_GGML_TYPE_BF16) lm_ggml_compute_forward_dup_flt<lm_ggml_bf16_t, lm_ggml_bf16_t>(params, dst);
                else if (dst->type == LM_GGML_TYPE_F32)  lm_ggml_compute_forward_dup_flt<lm_ggml_bf16_t, float      >(params, dst);
                else lm_ggml_compute_forward_dup_to_q<lm_ggml_bf16_t>(params, dst);
            } break;
        case LM_GGML_TYPE_F32:
            {
                /**/ if (dst->type == LM_GGML_TYPE_F16)  lm_ggml_compute_forward_dup_flt<float, lm_ggml_fp16_t>(params, dst);
                else if (dst->type == LM_GGML_TYPE_BF16) lm_ggml_compute_forward_dup_flt<float, lm_ggml_bf16_t>(params, dst);
                else if (dst->type == LM_GGML_TYPE_F32)  lm_ggml_compute_forward_dup_flt<float, float      >(params, dst);
                else if (dst->type == LM_GGML_TYPE_I32)  lm_ggml_compute_forward_dup_flt<float, int32_t    >(params, dst);
                else lm_ggml_compute_forward_dup_to_q<float>(params, dst);
            } break;
        case LM_GGML_TYPE_I32:
            {
                if (dst->type == LM_GGML_TYPE_F32) lm_ggml_compute_forward_dup_flt<int32_t, float>(params, dst);
                else LM_GGML_ABORT("not implemented");
            } break;
        default:
            {
                if (lm_ggml_is_quantized(src0->type) && dst->type == LM_GGML_TYPE_F32) {
                    lm_ggml_compute_forward_dup_from_q(params, dst);
                    break;
                }
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_add

static void lm_ggml_compute_forward_add_q_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, src1) && lm_ggml_are_same_shape(src0, dst));

    const int nr  = lm_ggml_nrows(src0);

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    const int ith = params->ith;
    const int nth = params->nth;

    const lm_ggml_type type = src0->type;
    const lm_ggml_type dtype = dst->type;
    lm_ggml_to_float_t const dequantize_row_q = lm_ggml_get_type_traits(type)->to_float;
    lm_ggml_from_float_t const quantize_row_q = lm_ggml_get_type_traits_cpu(dtype)->from_float;

    // we don't support permuted src0 or src1
    LM_GGML_ASSERT(nb00 == lm_ggml_type_size(type));
    LM_GGML_ASSERT(nb10 == sizeof(float));

    // dst cannot be transposed or permuted
    LM_GGML_ASSERT(nb0 <= nb1);
    LM_GGML_ASSERT(nb1 <= nb2);
    LM_GGML_ASSERT(nb2 <= nb3);

    LM_GGML_ASSERT(lm_ggml_is_quantized(src0->type));
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F32);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    float * wdata = (float *) params->wdata + (ne00 + CACHE_LINE_SIZE_F32) * ith;

    for (int ir = ir0; ir < ir1; ++ir) {
        // src0 indices
        const int i03 = ir/(ne02*ne01);
        const int i02 = (ir - i03*ne02*ne01)/ne01;
        const int i01 = (ir - i03*ne02*ne01 - i02*ne01);

        // src1 and dst are same shape as src0 => same indices
        const int i13 = i03;
        const int i12 = i02;
        const int i11 = i01;

        const int i3 = i03;
        const int i2 = i02;
        const int i1 = i01;

        void  * src0_row = (void *) ((char *) src0->data + (i01*nb01 + i02*nb02 + i03*nb03));
        float * src1_row = (float *)((char *) src1->data + (i11*nb11 + i12*nb12 + i13*nb13));
        void  * dst_row  = (void *) ((char *)  dst->data + ( i1*nb1  +  i2*nb2  +  i3*nb3));

        assert(ne00 % 32 == 0);

        // unquantize row from src0 to temp buffer
        dequantize_row_q(src0_row, wdata, ne00);
        // add src1
        lm_ggml_vec_acc_f32(ne00, wdata, src1_row);
        // quantize row to dst
        if (quantize_row_q != NULL) {
            quantize_row_q(wdata, dst_row, ne00);
        } else {
            memcpy(dst_row, wdata, ne0*nb0);
        }
    }
}

void lm_ggml_compute_forward_add(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
        case LM_GGML_TYPE_F16:
        case LM_GGML_TYPE_BF16:
            {
                lm_ggml_compute_forward_add_non_quantized(params, dst);
            } break;
        case LM_GGML_TYPE_Q1_0:
        case LM_GGML_TYPE_Q4_0:
        case LM_GGML_TYPE_Q4_1:
        case LM_GGML_TYPE_Q5_0:
        case LM_GGML_TYPE_Q5_1:
        case LM_GGML_TYPE_Q8_0:
        case LM_GGML_TYPE_MXFP4:
        case LM_GGML_TYPE_NVFP4:
        case LM_GGML_TYPE_Q2_K:
        case LM_GGML_TYPE_Q3_K:
        case LM_GGML_TYPE_Q4_K:
        case LM_GGML_TYPE_Q5_K:
        case LM_GGML_TYPE_Q6_K:
        case LM_GGML_TYPE_TQ1_0:
        case LM_GGML_TYPE_TQ2_0:
        case LM_GGML_TYPE_IQ2_XXS:
        case LM_GGML_TYPE_IQ2_XS:
        case LM_GGML_TYPE_IQ3_XXS:
        case LM_GGML_TYPE_IQ1_S:
        case LM_GGML_TYPE_IQ1_M:
        case LM_GGML_TYPE_IQ4_NL:
        case LM_GGML_TYPE_IQ4_XS:
        case LM_GGML_TYPE_IQ3_S:
        case LM_GGML_TYPE_IQ2_S:
            {
                lm_ggml_compute_forward_add_q_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_add_id

static void lm_ggml_compute_forward_add_id_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];
    const lm_ggml_tensor * src2 = dst->src[2];

    LM_GGML_ASSERT(dst->type  == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT(src2->type == LM_GGML_TYPE_I32);

    LM_GGML_ASSERT(src0->nb[0] == sizeof(float));
    LM_GGML_ASSERT(src1->nb[0] == sizeof(float));

    const int ith = params->ith;
    const int nth = params->nth;

    const int nr  = lm_ggml_nrows(src0);

    LM_GGML_TENSOR_TERNARY_OP_LOCALS

    LM_GGML_ASSERT( nb0 == sizeof(float));
    LM_GGML_ASSERT(nb10 == sizeof(float));

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int ir = ir0; ir < ir1; ++ir) {
        // src0 indices
        const int i3 = ir/(ne2*ne1);
        const int i2 = (ir - i3*ne2*ne1)/ne1;
        const int i1 = (ir - i3*ne2*ne1 - i2*ne1);

        // src1 indices
        const int i11 = *(int32_t *) ((char *) src2->data + i1*nb20 + i2*nb21);

        LM_GGML_ASSERT(i11 >= 0 && i11 < ne11);

        lm_ggml_vec_add_f32(ne0,
                (float *) ((char *) dst->data  + i3*nb3  + i2*nb2  + i1*nb1 ),
                (float *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01),
                (float *) ((char *) src1->data + i11*nb11));
    }
}

void lm_ggml_compute_forward_add_id(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_add_id_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("unsupported type for lm_ggml_compute_forward_add_id: %s", lm_ggml_type_name(src0->type));
            }
    }
}

// lm_ggml_compute_forward_add1

static void lm_ggml_compute_forward_add1_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, dst));
    LM_GGML_ASSERT(lm_ggml_is_scalar(src1));

    const int ith = params->ith;
    const int nth = params->nth;

    const int nr  = lm_ggml_nrows(src0);

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    LM_GGML_ASSERT( nb0 == sizeof(float));
    LM_GGML_ASSERT(nb00 == sizeof(float));

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int ir = ir0; ir < ir1; ++ir) {
        // src0 and dst are same shape => same indices
        const int i3 = ir/(ne2*ne1);
        const int i2 = (ir - i3*ne2*ne1)/ne1;
        const int i1 = (ir - i3*ne2*ne1 - i2*ne1);

#ifdef LM_GGML_USE_ACCELERATE
        LM_GGML_UNUSED(lm_ggml_vec_add1_f32);

        vDSP_vadd(
                (float *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01), 1,
                (float *) ((char *) src1->data), 0,
                (float *) ((char *) dst->data  + i3*nb3  + i2*nb2  + i1*nb1 ), 1,
                ne0);
#else
        lm_ggml_vec_add1_f32(ne0,
                (float *) ((char *) dst->data  + i3*nb3  + i2*nb2  + i1*nb1 ),
                (float *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01),
               *(float *) src1->data);
#endif
    }
}

static void lm_ggml_compute_forward_add1_f16_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, dst));
    LM_GGML_ASSERT(lm_ggml_is_scalar(src1));

    // scalar to add
    const float v = *(float *) src1->data;

    const int ith = params->ith;
    const int nth = params->nth;

    const int nr  = lm_ggml_nrows(src0);

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_F16);
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT(dst->type  == LM_GGML_TYPE_F16);

    LM_GGML_ASSERT( nb0 == sizeof(lm_ggml_fp16_t));
    LM_GGML_ASSERT(nb00 == sizeof(lm_ggml_fp16_t));

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int ir = ir0; ir < ir1; ++ir) {
        // src0 and dst are same shape => same indices
        const int i3 = ir/(ne2*ne1);
        const int i2 = (ir - i3*ne2*ne1)/ne1;
        const int i1 = (ir - i3*ne2*ne1 - i2*ne1);

        lm_ggml_fp16_t * dst_ptr  = (lm_ggml_fp16_t *) ((char *) dst->data  + i3*nb3  + i2*nb2  + i1*nb1 );
        lm_ggml_fp16_t * src0_ptr = (lm_ggml_fp16_t *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01);
        for (int i = 0; i < ne0; i++) {
            dst_ptr[i] = LM_GGML_CPU_FP32_TO_FP16(LM_GGML_CPU_FP16_TO_FP32(src0_ptr[i]) + v);
        }
    }
}

static void lm_ggml_compute_forward_add1_f16_f16(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, dst));
    LM_GGML_ASSERT(lm_ggml_is_scalar(src1));

    // scalar to add
    const float v = LM_GGML_CPU_FP16_TO_FP32(*(lm_ggml_fp16_t *) src1->data);

    const int ith = params->ith;
    const int nth = params->nth;

    const int nr  = lm_ggml_nrows(src0);

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_F16);
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F16);
    LM_GGML_ASSERT(dst->type  == LM_GGML_TYPE_F16);

    LM_GGML_ASSERT( nb0 == sizeof(lm_ggml_fp16_t));
    LM_GGML_ASSERT(nb00 == sizeof(lm_ggml_fp16_t));

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int ir = ir0; ir < ir1; ++ir) {
        // src0 and dst are same shape => same indices
        const int i3 = ir/(ne2*ne1);
        const int i2 = (ir - i3*ne2*ne1)/ne1;
        const int i1 = (ir - i3*ne2*ne1 - i2*ne1);

        lm_ggml_fp16_t * dst_ptr  = (lm_ggml_fp16_t *) ((char *) dst->data  + i3*nb3  + i2*nb2  + i1*nb1 );
        lm_ggml_fp16_t * src0_ptr = (lm_ggml_fp16_t *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01);
        for (int i = 0; i < ne0; i++) {
            dst_ptr[i] = LM_GGML_CPU_FP32_TO_FP16(LM_GGML_CPU_FP16_TO_FP32(src0_ptr[i]) + v);
        }
    }
}

static void lm_ggml_compute_forward_add1_q_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, dst));
    LM_GGML_ASSERT(lm_ggml_is_scalar(src1));

    // scalar to add
    const float v = *(float *) src1->data;

    const int ith = params->ith;
    const int nth = params->nth;

    const int nr  = lm_ggml_nrows(src0);

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    const lm_ggml_type type = src0->type;
    lm_ggml_to_float_t const dequantize_row_q = lm_ggml_get_type_traits(type)->to_float;
    lm_ggml_from_float_t const quantize_row_q = lm_ggml_get_type_traits_cpu(type)->from_float;

    // we don't support permuted src0
    LM_GGML_ASSERT(nb00 == lm_ggml_type_size(type));

    // dst cannot be transposed or permuted
    LM_GGML_ASSERT(nb0 <= nb1);
    LM_GGML_ASSERT(nb1 <= nb2);
    LM_GGML_ASSERT(nb2 <= nb3);

    LM_GGML_ASSERT(lm_ggml_is_quantized(src0->type));
    LM_GGML_ASSERT(dst->type == src0->type);
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F32);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    float * wdata = (float *) params->wdata + (ne0 + CACHE_LINE_SIZE_F32) * ith;

    for (int ir = ir0; ir < ir1; ++ir) {
        // src0 and dst are same shape => same indices
        const int i3 = ir/(ne2*ne1);
        const int i2 = (ir - i3*ne2*ne1)/ne1;
        const int i1 = (ir - i3*ne2*ne1 - i2*ne1);

        void  * src0_row = (void *) ((char *) src0->data + (i1*nb01 + i2*nb02 + i3*nb03));
        void  * dst_row  = (void *) ((char *)  dst->data + (i1*nb1  + i2*nb2  + i3*nb0 ));

        assert(ne0 % 32 == 0);

        // unquantize row from src0 to temp buffer
        dequantize_row_q(src0_row, wdata, ne0);
        // add src1
        lm_ggml_vec_acc1_f32(ne0, wdata, v);
        // quantize row to dst
        quantize_row_q(wdata, dst_row, ne0);
    }
}

static void lm_ggml_compute_forward_add1_bf16_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, dst));
    LM_GGML_ASSERT(lm_ggml_is_scalar(src1));

    // scalar to add
    const float v = *(float *) src1->data;

    const int ith = params->ith;
    const int nth = params->nth;

    const int nr  = lm_ggml_nrows(src0);

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_BF16);
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT(dst->type  == LM_GGML_TYPE_BF16);

    LM_GGML_ASSERT( nb0 == sizeof(lm_ggml_bf16_t));
    LM_GGML_ASSERT(nb00 == sizeof(lm_ggml_bf16_t));

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int ir = ir0; ir < ir1; ++ir) {
        // src0 and dst are same shape => same indices
        const int i3 = ir/(ne2*ne1);
        const int i2 = (ir - i3*ne2*ne1)/ne1;
        const int i1 = (ir - i3*ne2*ne1 - i2*ne1);

        lm_ggml_bf16_t * dst_ptr  = (lm_ggml_bf16_t *) ((char *) dst->data  + i3*nb3  + i2*nb2  + i1*nb1 );
        lm_ggml_bf16_t * src0_ptr = (lm_ggml_bf16_t *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01);
        for (int i = 0; i < ne0; i++) {
            dst_ptr[i] = LM_GGML_FP32_TO_BF16(LM_GGML_BF16_TO_FP32(src0_ptr[i]) + v);
        }
    }
}

static void lm_ggml_compute_forward_add1_bf16_bf16(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, dst));
    LM_GGML_ASSERT(lm_ggml_is_scalar(src1));

    // scalar to add
    const float v = LM_GGML_BF16_TO_FP32(*(lm_ggml_bf16_t *) src1->data);

    const int ith = params->ith;
    const int nth = params->nth;

    const int nr  = lm_ggml_nrows(src0);

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_BF16);
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_BF16);
    LM_GGML_ASSERT(dst->type  == LM_GGML_TYPE_BF16);

    LM_GGML_ASSERT( nb0 == sizeof(lm_ggml_bf16_t));
    LM_GGML_ASSERT(nb00 == sizeof(lm_ggml_bf16_t));

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int ir = ir0; ir < ir1; ++ir) {
        // src0 and dst are same shape => same indices
        const int i3 = ir/(ne2*ne1);
        const int i2 = (ir - i3*ne2*ne1)/ne1;
        const int i1 = (ir - i3*ne2*ne1 - i2*ne1);

        lm_ggml_bf16_t * dst_ptr  = (lm_ggml_bf16_t *) ((char *) dst->data  + i3*nb3  + i2*nb2  + i1*nb1 );
        lm_ggml_bf16_t * src0_ptr = (lm_ggml_bf16_t *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01);
        for (int i = 0; i < ne0; i++) {
            dst_ptr[i] = LM_GGML_FP32_TO_BF16(LM_GGML_BF16_TO_FP32(src0_ptr[i]) + v);
        }
    }
}

void lm_ggml_compute_forward_add1(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_add1_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
            {
                if (src1->type == LM_GGML_TYPE_F16) {
                    lm_ggml_compute_forward_add1_f16_f16(params, dst);
                }
                else if (src1->type == LM_GGML_TYPE_F32) {
                    lm_ggml_compute_forward_add1_f16_f32(params, dst);
                }
                else {
                    LM_GGML_ABORT("fatal error");
                }
            } break;
        case LM_GGML_TYPE_BF16:
            {
                if (src1->type == LM_GGML_TYPE_BF16) {
                    lm_ggml_compute_forward_add1_bf16_bf16(params, dst);
                }
                else if (src1->type == LM_GGML_TYPE_F32) {
                    lm_ggml_compute_forward_add1_bf16_f32(params, dst);
                }
                else {
                    LM_GGML_ABORT("fatal error");
                }
            } break;
        case LM_GGML_TYPE_Q1_0:
        case LM_GGML_TYPE_Q4_0:
        case LM_GGML_TYPE_Q4_1:
        case LM_GGML_TYPE_Q5_0:
        case LM_GGML_TYPE_Q5_1:
        case LM_GGML_TYPE_Q8_0:
        case LM_GGML_TYPE_Q8_1:
        case LM_GGML_TYPE_MXFP4:
        case LM_GGML_TYPE_NVFP4:
        case LM_GGML_TYPE_Q2_K:
        case LM_GGML_TYPE_Q3_K:
        case LM_GGML_TYPE_Q4_K:
        case LM_GGML_TYPE_Q5_K:
        case LM_GGML_TYPE_Q6_K:
        case LM_GGML_TYPE_TQ1_0:
        case LM_GGML_TYPE_TQ2_0:
        case LM_GGML_TYPE_IQ2_XXS:
        case LM_GGML_TYPE_IQ2_XS:
        case LM_GGML_TYPE_IQ3_XXS:
        case LM_GGML_TYPE_IQ1_S:
        case LM_GGML_TYPE_IQ1_M:
        case LM_GGML_TYPE_IQ4_NL:
        case LM_GGML_TYPE_IQ4_XS:
        case LM_GGML_TYPE_IQ3_S:
        case LM_GGML_TYPE_IQ2_S:
            {
                lm_ggml_compute_forward_add1_q_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_acc

static void lm_ggml_compute_forward_acc_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, dst));
    LM_GGML_ASSERT(lm_ggml_is_contiguous(dst) && lm_ggml_is_contiguous(src0));

    // view src0 and dst with these strides and data offset inbytes during acc
    // nb0 is implicitly element_size because src0 and dst are contiguous
    size_t nb1     = ((int32_t *) dst->op_params)[0];
    size_t nb2     = ((int32_t *) dst->op_params)[1];
    size_t nb3     = ((int32_t *) dst->op_params)[2];
    size_t offset  = ((int32_t *) dst->op_params)[3];
    bool   inplace = (bool) ((int32_t *) dst->op_params)[4];

    if (!inplace) {
        if (params->ith == 0) {
            // memcpy needs to be synchronized across threads to avoid race conditions.
            // => do it in INIT phase
            memcpy(
                ((char *)  dst->data),
                ((char *) src0->data),
                lm_ggml_nbytes(dst));
        }
        lm_ggml_barrier(params->threadpool);
    }

    const int ith = params->ith;
    const int nth = params->nth;

    const int nr = lm_ggml_nrows(src1);
    const int nc = src1->ne[0];

    LM_GGML_TENSOR_LOCALS(int64_t, ne1, src1, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb1, src1, nb)

    // src0 and dst as viewed during acc
    const size_t nb0 = lm_ggml_element_size(src0);

    const size_t nb00 = nb0;
    const size_t nb01 = nb1;
    const size_t nb02 = nb2;
    const size_t nb03 = nb3;

    LM_GGML_ASSERT(offset + (ne10 == 0 ? 0 : ne10-1)*nb0  + (ne11 == 0 ? 0 : ne11-1)*nb1  + (ne12 == 0 ? 0 : ne12-1)*nb2  + (ne13 == 0 ? 0 : ne13-1)*nb3  < lm_ggml_nbytes(dst));
    LM_GGML_ASSERT(offset + (ne10 == 0 ? 0 : ne10-1)*nb00 + (ne11 == 0 ? 0 : ne11-1)*nb01 + (ne12 == 0 ? 0 : ne12-1)*nb02 + (ne13 == 0 ? 0 : ne13-1)*nb03 < lm_ggml_nbytes(src0));

    LM_GGML_ASSERT(nb10 == sizeof(float));

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int ir = ir0; ir < ir1; ++ir) {
        // src0 and dst are viewed with shape of src1 and offset
        // => same indices
        const int i3 = ir/(ne12*ne11);
        const int i2 = (ir - i3*ne12*ne11)/ne11;
        const int i1 = (ir - i3*ne12*ne11 - i2*ne11);

#ifdef LM_GGML_USE_ACCELERATE
        vDSP_vadd(
                (float *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01 + offset), 1,
                (float *) ((char *) src1->data + i3*nb13 + i2*nb12 + i1*nb11), 1,
                (float *) ((char *) dst->data  + i3*nb3  + i2*nb2  + i1*nb1  + offset), 1, nc);
#else
        lm_ggml_vec_add_f32(nc,
                (float *) ((char *)  dst->data + i3*nb3  + i2*nb2  + i1*nb1  + offset),
                (float *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01 + offset),
                (float *) ((char *) src1->data + i3*nb13 + i2*nb12 + i1*nb11));
#endif
    }
}

void lm_ggml_compute_forward_acc(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_acc_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
        case LM_GGML_TYPE_BF16:
        case LM_GGML_TYPE_Q1_0:
        case LM_GGML_TYPE_Q4_0:
        case LM_GGML_TYPE_Q4_1:
        case LM_GGML_TYPE_Q5_0:
        case LM_GGML_TYPE_Q5_1:
        case LM_GGML_TYPE_Q8_0:
        case LM_GGML_TYPE_Q8_1:
        case LM_GGML_TYPE_MXFP4:
        case LM_GGML_TYPE_NVFP4:
        case LM_GGML_TYPE_Q2_K:
        case LM_GGML_TYPE_Q3_K:
        case LM_GGML_TYPE_Q4_K:
        case LM_GGML_TYPE_Q5_K:
        case LM_GGML_TYPE_Q6_K:
        case LM_GGML_TYPE_TQ1_0:
        case LM_GGML_TYPE_TQ2_0:
        case LM_GGML_TYPE_IQ2_XXS:
        case LM_GGML_TYPE_IQ2_XS:
        case LM_GGML_TYPE_IQ3_XXS:
        case LM_GGML_TYPE_IQ1_S:
        case LM_GGML_TYPE_IQ1_M:
        case LM_GGML_TYPE_IQ4_NL:
        case LM_GGML_TYPE_IQ4_XS:
        case LM_GGML_TYPE_IQ3_S:
        case LM_GGML_TYPE_IQ2_S:
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_sum

static void lm_ggml_compute_forward_sum_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    if (params->ith != 0) {
        return;
    }

    assert(lm_ggml_is_scalar(dst));
    assert(src0->nb[0] == sizeof(float));

    LM_GGML_TENSOR_LOCALS(int64_t, ne0, src0, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb0, src0, nb)

    lm_ggml_float sum     = 0;
    lm_ggml_float row_sum = 0;

    for (int64_t i03 = 0; i03 < ne03; i03++) {
        for (int64_t i02 = 0; i02 < ne02; i02++) {
            for (int64_t i01 = 0; i01 < ne01; i01++) {
                lm_ggml_vec_sum_f32_ggf(ne00,
                        &row_sum,
                        (float *) ((char *) src0->data + i01*nb01 + i02*nb02 + i03*nb03));
                sum += row_sum;
            }
        }
    }
    ((float *) dst->data)[0] = sum;
}

static void lm_ggml_compute_forward_sum_f16(
    const lm_ggml_compute_params * params,
          lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    if (params->ith != 0) {
        return;
    }

    assert(lm_ggml_is_scalar(dst));

    assert(src0->nb[0] == sizeof(lm_ggml_fp16_t));

    LM_GGML_TENSOR_LOCALS(int64_t, ne0, src0, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb0, src0, nb)

    float sum = 0;
    float row_sum = 0;

    for (int64_t i03 = 0; i03 < ne03; i03++) {
        for (int64_t i02 = 0; i02 < ne02; i02++) {
            for (int64_t i01 = 0; i01 < ne01; i01++) {
                lm_ggml_vec_sum_f16_ggf(ne00,
                    &row_sum,
                    (lm_ggml_fp16_t *) ((char *) src0->data + i01 * nb01 + i02 * nb02 + i03 * nb03));
                sum += row_sum;
            }
        }
    }
    ((lm_ggml_fp16_t *) dst->data)[0] = LM_GGML_CPU_FP32_TO_FP16(sum);
}

static void lm_ggml_compute_forward_sum_bf16(
    const lm_ggml_compute_params * params,
          lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    if (params->ith != 0) {
        return;
    }

    assert(lm_ggml_is_scalar(dst));

    assert(src0->nb[0] == sizeof(lm_ggml_bf16_t));

    LM_GGML_TENSOR_LOCALS(int64_t, ne0, src0, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb0, src0, nb)

    float sum = 0;
    float row_sum = 0;

    for (int64_t i03 = 0; i03 < ne03; i03++) {
        for (int64_t i02 = 0; i02 < ne02; i02++) {
            for (int64_t i01 = 0; i01 < ne01; i01++) {
                lm_ggml_vec_sum_bf16_ggf(ne00,
                    &row_sum,
                    (lm_ggml_bf16_t *) ((char *) src0->data + i01 * nb01 + i02 * nb02 + i03 * nb03));
                sum += row_sum;
            }
        }
    }
    ((lm_ggml_bf16_t *) dst->data)[0] = LM_GGML_FP32_TO_BF16(sum);
}

void lm_ggml_compute_forward_sum(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_sum_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_sum_f16(params, dst);
            } break;
        case LM_GGML_TYPE_BF16:
            {
                lm_ggml_compute_forward_sum_bf16(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_cumsum

static void lm_ggml_compute_forward_cumsum_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    LM_GGML_ASSERT(src0->nb[0] == sizeof(float));
    LM_GGML_ASSERT(dst->nb[0] == sizeof(float));

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    LM_GGML_ASSERT(ne0 == ne00);
    LM_GGML_ASSERT(ne1 == ne01);
    LM_GGML_ASSERT(ne2 == ne02);
    LM_GGML_ASSERT(ne3 == ne03);

    const auto [ir0, ir1] = get_thread_range(params, src0);

    for (int64_t ir = ir0; ir < ir1; ++ir) {
        const int64_t i03 = ir/(ne02*ne01);
        const int64_t i02 = (ir - i03*ne02*ne01)/ne01;
        const int64_t i01 = (ir - i03*ne02*ne01 - i02*ne01);

        float * src_row = (float *) ((char *) src0->data + i01*nb01 + i02*nb02 + i03*nb03);
        float * dst_row = (float *) ((char *) dst->data  + i01*nb1  + i02*nb2  + i03*nb3);

        lm_ggml_vec_cumsum_f32(ne00, dst_row, src_row);
    }
}

void lm_ggml_compute_forward_cumsum(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_cumsum_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_sum_rows

static void lm_ggml_compute_forward_sum_rows_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    if (params->ith != 0) {
        return;
    }

    LM_GGML_ASSERT(src0->nb[0] == sizeof(float));
    LM_GGML_ASSERT(dst->nb[0] == sizeof(float));

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    LM_GGML_ASSERT(ne0 == 1);
    LM_GGML_ASSERT(ne1 == ne01);
    LM_GGML_ASSERT(ne2 == ne02);
    LM_GGML_ASSERT(ne3 == ne03);

    for (int64_t i3 = 0; i3 < ne03; i3++) {
        for (int64_t i2 = 0; i2 < ne02; i2++) {
            for (int64_t i1 = 0; i1 < ne01; i1++) {
                float * src_row = (float *) ((char *) src0->data + i1*nb01 + i2*nb02 + i3*nb03);
                float * dst_row = (float *) ((char *) dst->data  + i1*nb1  + i2*nb2  + i3*nb3);
                float row_sum = 0;
                lm_ggml_vec_sum_f32(ne00, &row_sum, src_row);
                dst_row[0] = row_sum;
            }
        }
    }
}

void lm_ggml_compute_forward_sum_rows(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_sum_rows_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_mean

static void lm_ggml_compute_forward_mean_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    if (params->ith != 0) {
        return;
    }

    assert(src0->nb[0] == sizeof(float));

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    assert(ne0 == 1);
    assert(ne1 == ne01);
    assert(ne2 == ne02);
    assert(ne3 == ne03);

    LM_GGML_UNUSED(ne0);
    LM_GGML_UNUSED(ne1);
    LM_GGML_UNUSED(ne2);
    LM_GGML_UNUSED(ne3);

    for (int64_t i03 = 0; i03 < ne03; i03++) {
        for (int64_t i02 = 0; i02 < ne02; i02++) {
            for (int64_t i01 = 0; i01 < ne01; i01++) {
                lm_ggml_vec_sum_f32(ne00,
                        (float *) ((char *)  dst->data + i01*nb1  + i02*nb2  + i03*nb3),
                        (float *) ((char *) src0->data + i01*nb01 + i02*nb02 + i03*nb03));

                *(float *) ((char *) dst->data + i01*nb1 + i02*nb2 + i03*nb3) /= (float) ne00;
            }
        }
    }
}

void lm_ggml_compute_forward_mean(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_mean_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_argmax

static void lm_ggml_compute_forward_argmax_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    if (params->ith != 0) {
        return;
    }

    assert(src0->nb[0] == sizeof(float));
    assert(dst->nb[0] == sizeof(float));

    const int64_t ne00 = src0->ne[0];
    const int64_t ne01 = src0->ne[1];

    const size_t nb01 = src0->nb[1];
    const size_t nb0 = dst->nb[0];

    for (int64_t i1 = 0; i1 < ne01; i1++) {
        float * src = (float *) ((char *) src0->data + i1*nb01);
        int32_t * dst_ = (int32_t *) ((char *)  dst->data + i1*nb0);
        int v = 0;
        lm_ggml_vec_argmax_f32(ne00, &v, src);
        dst_[0] = v;
    }
}

void lm_ggml_compute_forward_argmax(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_argmax_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_count_equal

static void lm_ggml_compute_forward_count_equal_i32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_TENSOR_BINARY_OP_LOCALS;

    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_I32);
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_I32);
    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, src1));
    LM_GGML_ASSERT(lm_ggml_is_scalar(dst));
    LM_GGML_ASSERT(dst->type == LM_GGML_TYPE_I64);

    const int64_t nr = lm_ggml_nrows(src0);

    const int ith = params->ith;
    const int nth = params->nth;

    int64_t * sums = (int64_t *) params->wdata;
    int64_t sum_thread = 0;

    // rows per thread
    const int64_t dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int64_t ir0 = dr*ith;
    const int64_t ir1 = MIN(ir0 + dr, nr);

    for (int64_t ir = ir0; ir < ir1; ++ir) {
        const int64_t i03 =  ir                        / (ne02*ne01);
        const int64_t i02 = (ir - i03*ne03)            /       ne01;
        const int64_t i01 =  ir - i03*ne03 - i02*ne02;

        const char * data0 = (const char *) src0->data + i03*nb03 + i02*nb02 + i01*nb01;
        const char * data1 = (const char *) src1->data + i03*nb13 + i02*nb12 + i01*nb11;

        for (int64_t i00 = 0; i00 < ne00; ++i00) {
            const int32_t val0 = *((const int32_t *) (data0 + i00*nb00));
            const int32_t val1 = *((const int32_t *) (data1 + i00*nb10));

            sum_thread += val0 == val1;
        }
    }
    if (ith != 0) {
        sums[ith] = sum_thread;
    }
    lm_ggml_barrier(params->threadpool);

    if (ith != 0) {
        return;
    }

    for (int ith_other = 1; ith_other < nth; ++ith_other) {
        sum_thread += sums[ith_other];
    }
    *((int64_t *) dst->data) = sum_thread;
}

void lm_ggml_compute_forward_count_equal(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_I32:
            {
                lm_ggml_compute_forward_count_equal_i32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_repeat

static void lm_ggml_compute_forward_repeat_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    if (params->ith != 0) {
        return;
    }

    LM_GGML_ASSERT(lm_ggml_can_repeat(src0, dst));

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    // guaranteed to be an integer due to the check in lm_ggml_can_repeat
    const int nr0 = (int)(ne0/ne00);
    const int nr1 = (int)(ne1/ne01);
    const int nr2 = (int)(ne2/ne02);
    const int nr3 = (int)(ne3/ne03);

    // TODO: support for transposed / permuted tensors
    LM_GGML_ASSERT(nb0  == sizeof(float));
    LM_GGML_ASSERT(nb00 == sizeof(float));

    // TODO: maybe this is not optimal?
    for                         (int i3 = 0; i3 < nr3;  i3++) {
        for                     (int k3 = 0; k3 < ne03; k3++) {
            for                 (int i2 = 0; i2 < nr2;  i2++) {
                for             (int k2 = 0; k2 < ne02; k2++) {
                    for         (int i1 = 0; i1 < nr1;  i1++) {
                        for     (int k1 = 0; k1 < ne01; k1++) {
                            for (int i0 = 0; i0 < nr0;  i0++) {
                                lm_ggml_vec_cpy_f32(ne00,
                                        (float *) ((char *)  dst->data + (i3*ne03 + k3)*nb3  + (i2*ne02 + k2)*nb2  + (i1*ne01 + k1)*nb1  + (i0*ne00)*nb0),
                                        (float *) ((char *) src0->data + (          k3)*nb03 + (          k2)*nb02 + (          k1)*nb01));
                            }
                        }
                    }
                }
            }
        }
    }
}

static void lm_ggml_compute_forward_repeat_f16(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    if (params->ith != 0) {
        return;
    }

    LM_GGML_ASSERT(lm_ggml_can_repeat(src0, dst));

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    // guaranteed to be an integer due to the check in lm_ggml_can_repeat
    const int nr0 = (int)(ne0/ne00);
    const int nr1 = (int)(ne1/ne01);
    const int nr2 = (int)(ne2/ne02);
    const int nr3 = (int)(ne3/ne03);

    // TODO: support for transposed / permuted tensors
    LM_GGML_ASSERT(nb0  == sizeof(lm_ggml_fp16_t));
    LM_GGML_ASSERT(nb00 == sizeof(lm_ggml_fp16_t));

    // TODO: maybe this is not optimal?
    for                         (int i3 = 0; i3 < nr3;  i3++) {
        for                     (int k3 = 0; k3 < ne03; k3++) {
            for                 (int i2 = 0; i2 < nr2;  i2++) {
                for             (int k2 = 0; k2 < ne02; k2++) {
                    for         (int i1 = 0; i1 < nr1;  i1++) {
                        for     (int k1 = 0; k1 < ne01; k1++) {
                            for (int i0 = 0; i0 < nr0;  i0++) {
                                lm_ggml_fp16_t * y = (lm_ggml_fp16_t *) ((char *)  dst->data + (i3*ne03 + k3)*nb3  + (i2*ne02 + k2)*nb2  + (i1*ne01 + k1)*nb1  + (i0*ne00)*nb0);
                                lm_ggml_fp16_t * x = (lm_ggml_fp16_t *) ((char *) src0->data + (          k3)*nb03 + (          k2)*nb02 + (          k1)*nb01);
                                // lm_ggml_vec_cpy_f16(ne00, y, x)
                                for (int i = 0; i < ne00; ++i) {
                                    y[i]  = x[i];
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

void lm_ggml_compute_forward_repeat(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F16:
        case LM_GGML_TYPE_BF16:
        case LM_GGML_TYPE_I16:
            {
                lm_ggml_compute_forward_repeat_f16(params, dst);
            } break;
        case LM_GGML_TYPE_F32:
        case LM_GGML_TYPE_I32:
            {
                lm_ggml_compute_forward_repeat_f32(params, dst);
            } break;
        // TODO: templateify the implementation and support for I64
        //       ref https://github.com/ggml-org/llama.cpp/pull/14274#discussion_r2169492225
        //case LM_GGML_TYPE_I64:
        //    {
        //        lm_ggml_compute_forward_repeat_i64(params, dst);
        //    } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_repeat_back

static void lm_ggml_compute_forward_repeat_back_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    if (params->ith != 0) {
        return;
    }

    LM_GGML_ASSERT(lm_ggml_can_repeat(dst, src0));

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    // guaranteed to be an integer due to the check in lm_ggml_can_repeat
    const int nr0 = (int)(ne00/ne0);
    const int nr1 = (int)(ne01/ne1);
    const int nr2 = (int)(ne02/ne2);
    const int nr3 = (int)(ne03/ne3);

    // TODO: support for transposed / permuted tensors
    LM_GGML_ASSERT(nb0  == sizeof(float));
    LM_GGML_ASSERT(nb00 == sizeof(float));

    if (lm_ggml_is_contiguous(dst)) {
        lm_ggml_vec_set_f32(ne0*ne1*ne2*ne3, (float *)dst->data, 0);
    } else {
        for         (int k3 = 0; k3 < ne3; k3++) {
            for     (int k2 = 0; k2 < ne2; k2++) {
                for (int k1 = 0; k1 < ne1; k1++) {
                    lm_ggml_vec_set_f32(ne0,
                        (float *) ((char *) dst->data + k1*nb1 + k2*nb2 + k3*nb3),
                        0);
                }
            }
        }
    }

    // TODO: maybe this is not optimal?
    for                         (int i3 = 0; i3 < nr3; i3++) {
        for                     (int k3 = 0; k3 < ne3; k3++) {
            for                 (int i2 = 0; i2 < nr2; i2++) {
                for             (int k2 = 0; k2 < ne2; k2++) {
                    for         (int i1 = 0; i1 < nr1; i1++) {
                        for     (int k1 = 0; k1 < ne1; k1++) {
                            for (int i0 = 0; i0 < nr0; i0++) {
                                lm_ggml_vec_acc_f32(ne0,
                                        (float *) ((char *)  dst->data + (         k3)*nb3  + (         k2)*nb2  + (         k1)*nb1),
                                        (float *) ((char *) src0->data + (i3*ne3 + k3)*nb03 + (i2*ne2 + k2)*nb02 + (i1*ne1 + k1)*nb01 + (i0*ne0)*nb00));
                            }
                        }
                    }
                }
            }
        }
    }
}

void lm_ggml_compute_forward_repeat_back(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_repeat_back_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_concat

static void lm_ggml_compute_forward_concat_any(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    const size_t len = lm_ggml_type_size(src0->type);

    const int ith = params->ith;
    const int nth = params->nth;

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    const int32_t dim = lm_ggml_get_op_params_i32(dst, 0);

    LM_GGML_ASSERT(dim >= 0 && dim < 4);

    int64_t o[4] = {0, 0, 0, 0};
    o[dim] = src0->ne[dim];

    const char * x;

    // TODO: smarter multi-theading
    for (int i3 = 0; i3 < ne3; i3++) {
        for (int i2 = ith; i2 < ne2; i2 += nth) {
            for (int i1 = 0; i1 < ne1; i1++) {
                for (int i0 = 0; i0 < ne0; i0++) {
                    if (i0 < ne00 && i1 < ne01 && i2 < ne02 && i3 < ne03) {
                        x = (const char *)src0->data + (i0       )*nb00 + (i1       )*nb01 + (i2       )*nb02 + (i3       )*nb03;
                    } else {
                        x = (const char *)src1->data + (i0 - o[0])*nb10 + (i1 - o[1])*nb11 + (i2 - o[2])*nb12 + (i3 - o[3])*nb13;
                    }

                    char * y = (char *)dst->data + i0*nb0 + i1*nb1 + i2*nb2 + i3*nb3;

                    memcpy(y, x, len);
                }
            }
        }
    }
}

static void lm_ggml_compute_forward_concat_i8(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(lm_ggml_type_size(src0->type) == sizeof(int8_t));

    const int ith = params->ith;
    const int nth = params->nth;

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    const int32_t dim = lm_ggml_get_op_params_i32(dst, 0);

    LM_GGML_ASSERT(dim >= 0 && dim < 4);

    int64_t o[4] = {0, 0, 0, 0};
    o[dim] = src0->ne[dim];

    const int8_t * x;

    // TODO: smarter multi-theading
    for (int i3 = 0; i3 < ne3; i3++) {
        for (int i2 = ith; i2 < ne2; i2 += nth) {
            for (int i1 = 0; i1 < ne1; i1++) {
                for (int i0 = 0; i0 < ne0; i0++) {
                    if (i0 < ne00 && i1 < ne01 && i2 < ne02 && i3 < ne03) {
                        x = (const int8_t *) ((const char *)src0->data + (i0       )*nb00 + (i1       )*nb01 + (i2       )*nb02 + (i3       )*nb03);
                    } else {
                        x = (const int8_t *) ((const char *)src1->data + (i0 - o[0])*nb10 + (i1 - o[1])*nb11 + (i2 - o[2])*nb12 + (i3 - o[3])*nb13);
                    }

                    int8_t * y = (int8_t *)((char *)dst->data + i0*nb0 + i1*nb1 + i2*nb2 + i3*nb3);

                    *y = *x;
                }
            }
        }
    }
}

static void lm_ggml_compute_forward_concat_f16(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(lm_ggml_type_size(src0->type) == sizeof(lm_ggml_fp16_t));

    const int ith = params->ith;
    const int nth = params->nth;

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    const int32_t dim = lm_ggml_get_op_params_i32(dst, 0);

    LM_GGML_ASSERT(dim >= 0 && dim < 4);

    int64_t o[4] = {0, 0, 0, 0};
    o[dim] = src0->ne[dim];

    const lm_ggml_fp16_t * x;

    // TODO: smarter multi-theading
    for (int i3 = 0; i3 < ne3; i3++) {
        for (int i2 = ith; i2 < ne2; i2 += nth) {
            for (int i1 = 0; i1 < ne1; i1++) {
                for (int i0 = 0; i0 < ne0; i0++) {
                    if (i0 < ne00 && i1 < ne01 && i2 < ne02 && i3 < ne03) {
                        x = (const lm_ggml_fp16_t *) ((const char *)src0->data + (i0       )*nb00 + (i1       )*nb01 + (i2       )*nb02 + (i3       )*nb03);
                    } else {
                        x = (const lm_ggml_fp16_t *) ((const char *)src1->data + (i0 - o[0])*nb10 + (i1 - o[1])*nb11 + (i2 - o[2])*nb12 + (i3 - o[3])*nb13);
                    }

                    lm_ggml_fp16_t * y = (lm_ggml_fp16_t *)((char *)dst->data + i0*nb0 + i1*nb1 + i2*nb2 + i3*nb3);

                    *y = *x;
                }
            }
        }
    }
}

static void lm_ggml_compute_forward_concat_f32(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(lm_ggml_type_size(src0->type) == sizeof(float));

    const int ith = params->ith;
    const int nth = params->nth;

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    const int32_t dim = lm_ggml_get_op_params_i32(dst, 0);

    LM_GGML_ASSERT(dim >= 0 && dim < 4);

    int64_t o[4] = {0, 0, 0, 0};
    o[dim] = src0->ne[dim];

    const float * x;

    // TODO: smarter multi-theading
    for (int i3 = 0; i3 < ne3; i3++) {
        for (int i2 = ith; i2 < ne2; i2 += nth) {
            for (int i1 = 0; i1 < ne1; i1++) {
                for (int i0 = 0; i0 < ne0; i0++) {
                    if (i0 < ne00 && i1 < ne01 && i2 < ne02 && i3 < ne03) {
                        x = (const float *) ((const char *)src0->data + (i0       )*nb00 + (i1       )*nb01 + (i2       )*nb02 + (i3       )*nb03);
                    } else {
                        x = (const float *) ((const char *)src1->data + (i0 - o[0])*nb10 + (i1 - o[1])*nb11 + (i2 - o[2])*nb12 + (i3 - o[3])*nb13);
                    }

                    float * y = (float *)((char *)dst->data + i0*nb0 + i1*nb1 + i2*nb2 + i3*nb3);

                    *y = *x;
                }
            }
        }
    }
}

void lm_ggml_compute_forward_concat(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F16:
        case LM_GGML_TYPE_BF16:
        case LM_GGML_TYPE_I16:
            {
                lm_ggml_compute_forward_concat_f16(params, dst);
            } break;
        case LM_GGML_TYPE_I8:
            {
                lm_ggml_compute_forward_concat_i8(params, dst);
            } break;
        case LM_GGML_TYPE_F32:
        case LM_GGML_TYPE_I32:
            {
                lm_ggml_compute_forward_concat_f32(params, dst);
            } break;
        default:
            {
                lm_ggml_compute_forward_concat_any(params, dst);
            }
    }
}

// lm_ggml_compute_forward_gelu

static void lm_ggml_compute_forward_gelu_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    assert(lm_ggml_is_contiguous_rows(src0));
    assert(lm_ggml_are_same_shape(src0, dst));

    LM_GGML_TENSOR_LOCALS(int64_t, ne0, src0, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb0, src0, nb)
    LM_GGML_TENSOR_LOCALS(int64_t, ne,  dst,  ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb,  dst,  nb)

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src0->ne[0];
    const int nr = lm_ggml_nrows(src0);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int ir = ir0; ir < ir1; ++ir) {
        const int i3 = ir/(ne02*ne01);
        const int i2 = (ir - i3*ne02*ne01)/ne01;
        const int i1 = (ir - i3*ne02*ne01 - i2*ne01);

        lm_ggml_vec_gelu_f32(nc,
                (float *) ((char *) dst->data  + i3*nb3  + i2*nb2  + i1*nb1),
                (float *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01));

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const float x = ((float *) ((char *) dst->data + i3*nb3 + i2*nb2 + i1*(dst->nb[1])))[k];
            LM_GGML_UNUSED(x);
            assert(!isnan(x));
            assert(!isinf(x));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_gelu_f16(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    assert(lm_ggml_is_contiguous_rows(src0));
    assert(lm_ggml_are_same_shape(src0, dst));

    LM_GGML_TENSOR_LOCALS(int64_t, ne0, src0, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb0, src0, nb)
    LM_GGML_TENSOR_LOCALS(int64_t, ne,  dst,  ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb,  dst,  nb)

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src0->ne[0];
    const int nr = lm_ggml_nrows(src0);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int ir = ir0; ir < ir1; ++ir) {
        const int i3 = ir/(ne02*ne01);
        const int i2 = (ir - i3*ne02*ne01)/ne01;
        const int i1 = (ir - i3*ne02*ne01 - i2*ne01);

        lm_ggml_vec_gelu_f16(nc,
                (lm_ggml_fp16_t *) ((char *) dst->data  + i3*nb3  + i2*nb2  + i1*nb1),
                (lm_ggml_fp16_t *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01));

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const lm_ggml_fp16_t x = ((lm_ggml_fp16_t *) ((char *) dst->data + i3*nb3 + i2*nb2 + i1*( dst->nb[1])))[k];
            const float v = LM_GGML_CPU_FP16_TO_FP32(x);
            LM_GGML_UNUSED(v);
            assert(!isnan(v));
            assert(!isinf(v));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_gelu(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_gelu_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_gelu_f16(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_fill

static void lm_ggml_compute_forward_fill_f32(const lm_ggml_compute_params * params, lm_ggml_tensor * dst) {
    const float c = lm_ggml_get_op_params_f32(dst, 0);

    LM_GGML_TENSOR_LOCALS(int64_t, ne, dst, ne);
    LM_GGML_TENSOR_LOCALS(size_t,  nb, dst, nb);

    const auto [ir0, ir1] = get_thread_range(params, dst);

    for (int64_t ir = ir0; ir < ir1; ++ir) {
        const int64_t i03 = ir/(ne2*ne1);
        const int64_t i02 = (ir - i03*ne2*ne1)/ne1;
        const int64_t i01 = (ir - i03*ne2*ne1 - i02*ne1);

        float * dst_ptr  = (float *) ((char *) dst->data + i03*nb3 + i02*nb2 + i01*nb1);

        lm_ggml_vec_set_f32(ne0, dst_ptr, c);
    }
}

static void lm_ggml_compute_forward_fill_f16(const lm_ggml_compute_params * params, lm_ggml_tensor * dst) {
    const lm_ggml_fp16_t c = LM_GGML_CPU_FP32_TO_FP16(lm_ggml_get_op_params_f32(dst, 0));

    LM_GGML_TENSOR_LOCALS(int64_t, ne, dst, ne);
    LM_GGML_TENSOR_LOCALS(size_t,  nb, dst, nb);

    const auto [ir0, ir1] = get_thread_range(params, dst);

    for (int64_t ir = ir0; ir < ir1; ++ir) {
        const int64_t i03 = ir/(ne2*ne1);
        const int64_t i02 = (ir - i03*ne2*ne1)/ne1;
        const int64_t i01 = (ir - i03*ne2*ne1 - i02*ne1);

        lm_ggml_fp16_t * dst_ptr  = (lm_ggml_fp16_t *) ((char *) dst->data + i03*nb3 + i02*nb2 + i01*nb1);

        lm_ggml_vec_set_f16(ne0, dst_ptr, c);
    }
}

void lm_ggml_compute_forward_fill(const lm_ggml_compute_params * params, lm_ggml_tensor * dst) {
    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_fill_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_fill_f16(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("unsupported type for lm_ggml_compute_forward_fill: %s", lm_ggml_type_name(src0->type));
            }
    }
}

// lm_ggml_compute_tri

static void lm_ggml_compute_forward_tri_f32(const lm_ggml_compute_params * params, lm_ggml_tensor * dst) {
    const lm_ggml_tensor * src0 = dst->src[0];

    const lm_ggml_tri_type ttype = (lm_ggml_tri_type) lm_ggml_get_op_params_i32(dst, 0);

    LM_GGML_ASSERT(lm_ggml_is_contiguous(src0));

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    const auto [ir0, ir1] = get_thread_range(params, src0);

    bool (*bipred)(int, int);

    switch (ttype) {
        case LM_GGML_TRI_TYPE_LOWER:      bipred = [](int i, int r) { return i <  r; }; break;
        case LM_GGML_TRI_TYPE_LOWER_DIAG: bipred = [](int i, int r) { return i <= r; }; break;
        case LM_GGML_TRI_TYPE_UPPER:      bipred = [](int i, int r) { return i >  r; }; break;
        case LM_GGML_TRI_TYPE_UPPER_DIAG: bipred = [](int i, int r) { return i >= r; }; break;
        default: LM_GGML_ABORT("invalid tri type");
    }

    for (int64_t ir = ir0; ir < ir1; ++ir) {
        const int64_t i03 = ir/(ne02*ne01);
        const int64_t i02 = (ir - i03*ne02*ne01)/ne01;
        const int64_t i01 = (ir - i03*ne02*ne01 - i02*ne01);

        const float * src_ptr = (const float  *) ((const char *) src0->data + i03*nb03 + i02*nb02 + i01*nb01);
              float * dst_ptr = (      float  *) ((      char *) dst->data  + i03*nb3  + i02*nb2  + i01*nb1);

        for (int i0 = 0; i0 < ne0; ++i0) {
            dst_ptr[i0] = bipred(i0, i01) ? src_ptr[i0] : 0.0f;
        }
    }
}

void lm_ggml_compute_forward_tri(const lm_ggml_compute_params * params, lm_ggml_tensor * dst) {
    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_tri_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_gelu_erf

static void lm_ggml_compute_forward_gelu_erf_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    assert(lm_ggml_is_contiguous_rows(src0));
    assert(lm_ggml_are_same_shape(src0, dst));

    LM_GGML_TENSOR_LOCALS(int64_t, ne0, src0, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb0, src0, nb)
    LM_GGML_TENSOR_LOCALS(int64_t, ne,  dst,  ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb,  dst,  nb)

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src0->ne[0];
    const int nr = lm_ggml_nrows(src0);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int ir = ir0; ir < ir1; ++ir) {
        const int i3 = ir/(ne02*ne01);
        const int i2 = (ir - i3*ne02*ne01)/ne01;
        const int i1 = (ir - i3*ne02*ne01 - i2*ne01);

        lm_ggml_vec_gelu_erf_f32(nc,
                (float *) ((char *) dst->data  + i3*nb3  + i2*nb2  + i1*nb1),
                (float *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01));

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const float x = ((float *) ((char *) dst->data + i3*nb3 + i2*nb2 + i1*(dst->nb[1])))[k];
            LM_GGML_UNUSED(x);
            assert(!isnan(x));
            assert(!isinf(x));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_gelu_erf_f16(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    assert(lm_ggml_is_contiguous_rows(src0));
    assert(lm_ggml_are_same_shape(src0, dst));

    LM_GGML_TENSOR_LOCALS(int64_t, ne0, src0, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb0, src0, nb)
    LM_GGML_TENSOR_LOCALS(int64_t, ne,  dst,  ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb,  dst,  nb)

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src0->ne[0];
    const int nr = lm_ggml_nrows(src0);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int ir = ir0; ir < ir1; ++ir) {
        const int i3 = ir/(ne02*ne01);
        const int i2 = (ir - i3*ne02*ne01)/ne01;
        const int i1 = (ir - i3*ne02*ne01 - i2*ne01);

        lm_ggml_vec_gelu_erf_f16(nc,
                (lm_ggml_fp16_t *) ((char *) dst->data  + i3*nb3  + i2*nb2  + i1*nb1),
                (lm_ggml_fp16_t *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01));

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const lm_ggml_fp16_t x = ((lm_ggml_fp16_t *) ((char *) dst->data + i3*nb3 + i2*nb2 + i1*( dst->nb[1])))[k];
            const float v = LM_GGML_CPU_FP16_TO_FP32(x);
            LM_GGML_UNUSED(v);
            assert(!isnan(v));
            assert(!isinf(v));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_gelu_erf(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_gelu_erf_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_gelu_erf_f16(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_gelu_quick

static void lm_ggml_compute_forward_gelu_quick_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    assert(lm_ggml_is_contiguous_rows(src0));
    assert(lm_ggml_are_same_shape(src0, dst));

    LM_GGML_TENSOR_LOCALS(int64_t, ne0, src0, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb0, src0, nb)
    LM_GGML_TENSOR_LOCALS(int64_t, ne,  dst,  ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb,  dst,  nb)

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src0->ne[0];
    const int nr = lm_ggml_nrows(src0);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int ir = ir0; ir < ir1; ++ir) {
        const int i3 = ir/(ne02*ne01);
        const int i2 = (ir - i3*ne02*ne01)/ne01;
        const int i1 = (ir - i3*ne02*ne01 - i2*ne01);

        lm_ggml_vec_gelu_quick_f32(nc,
                (float *) ((char *) dst->data  + i3*nb3  + i2*nb2  + i1*nb1),
                (float *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01));

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const float x = ((float *) ((char *) dst->data + i3*nb3 + i2*nb2 + i1*(dst->nb[1])))[k];
            LM_GGML_UNUSED(x);
            assert(!isnan(x));
            assert(!isinf(x));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_gelu_quick_f16(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    assert(lm_ggml_is_contiguous_rows(src0));
    assert(lm_ggml_are_same_shape(src0, dst));

    LM_GGML_TENSOR_LOCALS(int64_t, ne0, src0, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb0, src0, nb)
    LM_GGML_TENSOR_LOCALS(int64_t, ne,  dst,  ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb,  dst,  nb)

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src0->ne[0];
    const int nr = lm_ggml_nrows(src0);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int ir = ir0; ir < ir1; ++ir) {
        const int i3 = ir/(ne02*ne01);
        const int i2 = (ir - i3*ne02*ne01)/ne01;
        const int i1 = (ir - i3*ne02*ne01 - i2*ne01);

        lm_ggml_vec_gelu_quick_f16(nc,
                (lm_ggml_fp16_t *) ((char *) dst->data  + i3*nb3  + i2*nb2  + i1*nb1),
                (lm_ggml_fp16_t *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01));

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const lm_ggml_fp16_t x = ((lm_ggml_fp16_t *) ((char *) dst->data + i3*nb3 + i2*nb2 + i1*( dst->nb[1])))[k];
            const float v = LM_GGML_CPU_FP16_TO_FP32(x);
            LM_GGML_UNUSED(v);
            assert(!isnan(v));
            assert(!isinf(v));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_gelu_quick(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_gelu_quick_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_gelu_quick_f16(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_silu

static void lm_ggml_compute_forward_silu_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    assert(lm_ggml_is_contiguous_rows(src0));
    assert(lm_ggml_are_same_shape(src0, dst));

    LM_GGML_TENSOR_LOCALS(int64_t, ne0, src0, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb0, src0, nb)
    LM_GGML_TENSOR_LOCALS(int64_t, ne,  dst,  ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb,  dst,  nb)

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src0->ne[0];
    const int nr = lm_ggml_nrows(src0);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int ir = ir0; ir < ir1; ++ir) {
        const int i3 = ir/(ne02*ne01);
        const int i2 = (ir - i3*ne02*ne01)/ne01;
        const int i1 = (ir - i3*ne02*ne01 - i2*ne01);

        lm_ggml_vec_silu_f32(nc,
                (float *) ((char *) dst->data  + i3*nb3  + i2*nb2  + i1*nb1),
                (float *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01));

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const float x = ((float *) ((char *) dst->data + i3*nb3 + i2*nb2 + i1*(dst->nb[1])))[k];
            LM_GGML_UNUSED(x);
            assert(!isnan(x));
            assert(!isinf(x));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_silu_f16(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    assert(lm_ggml_is_contiguous_rows(src0));
    assert(lm_ggml_are_same_shape(src0, dst));

    LM_GGML_TENSOR_LOCALS(int64_t, ne0, src0, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb0, src0, nb)
    LM_GGML_TENSOR_LOCALS(int64_t, ne,  dst,  ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb,  dst,  nb)

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src0->ne[0];
    const int nr = lm_ggml_nrows(src0);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int ir = ir0; ir < ir1; ++ir) {
        const int i3 = ir/(ne02*ne01);
        const int i2 = (ir - i3*ne02*ne01)/ne01;
        const int i1 = (ir - i3*ne02*ne01 - i2*ne01);

        lm_ggml_vec_silu_f16(nc,
                (lm_ggml_fp16_t *) ((char *) dst->data  + i3*nb3  + i2*nb2  + i1*nb1),
                (lm_ggml_fp16_t *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01));

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const lm_ggml_fp16_t x = ((lm_ggml_fp16_t *) ((char *) dst->data + i3*nb3 + i2*nb2 + i1*( dst->nb[1])))[k];
            const float v = LM_GGML_CPU_FP16_TO_FP32(x);
            LM_GGML_UNUSED(v);
            assert(!isnan(v));
            assert(!isinf(v));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_silu(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_silu_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_silu_f16(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}
// lm_ggml_compute_forward_leaky_relu

static void lm_ggml_compute_forward_leaky_relu_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    if (params->ith != 0) {
        return;
    }

    assert(lm_ggml_is_contiguous_1(src0));
    assert(lm_ggml_is_contiguous_1(dst));
    assert(lm_ggml_are_same_shape(src0, dst));

    const int n  = lm_ggml_nrows(src0);
    const int nc = src0->ne[0];

    float negative_slope;
    memcpy(&negative_slope, dst->op_params, sizeof(float));

    assert(dst->nb[0]  == sizeof(float));
    assert(src0->nb[0] == sizeof(float));

    for (int i = 0; i < n; i++) {
        lm_ggml_vec_leaky_relu_f32(nc,
                (float *) ((char *) dst->data  + i*( dst->nb[1])),
                (float *) ((char *) src0->data + i*(src0->nb[1])), negative_slope);
    }
}

static void lm_ggml_compute_forward_leaky_relu_f16(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    if (params->ith != 0) {
        return;
    }

    assert(lm_ggml_is_contiguous_1(src0));
    assert(lm_ggml_is_contiguous_1(dst));
    assert(lm_ggml_are_same_shape(src0, dst));

    const int n  = lm_ggml_nrows(src0);
    const int nc = src0->ne[0];

    float negative_slope;
    memcpy(&negative_slope, dst->op_params, sizeof(float));

    assert(dst->nb[0]  == sizeof(lm_ggml_fp16_t));
    assert(src0->nb[0] == sizeof(lm_ggml_fp16_t));

    for (int i = 0; i < n; i++) {
        lm_ggml_vec_leaky_relu_f16(nc,
                (lm_ggml_fp16_t *) ((char *) dst->data  + i*( dst->nb[1])),
                (lm_ggml_fp16_t *) ((char *) src0->data + i*(src0->nb[1])), negative_slope);
    }
}

void lm_ggml_compute_forward_leaky_relu(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_leaky_relu_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_leaky_relu_f16(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_silu_back

static void lm_ggml_compute_forward_silu_back_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * grad = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    assert(lm_ggml_is_contiguous_1(grad));
    assert(lm_ggml_is_contiguous_1(src1));
    assert(lm_ggml_is_contiguous_1(dst));
    assert(lm_ggml_are_same_shape(src1, dst));
    assert(lm_ggml_are_same_shape(src1, grad));

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src1->ne[0];
    const int nr = lm_ggml_nrows(src1);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int i1 = ir0; i1 < ir1; i1++) {
        lm_ggml_vec_silu_backward_f32(nc,
                (float *) ((char *) dst->data  + i1*( dst->nb[1])),
                (float *) ((char *) src1->data + i1*(src1->nb[1])),
                (float *) ((char *) grad->data + i1*(grad->nb[1])));

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const float x = ((float *) ((char *) dst->data + i1*( dst->nb[1])))[k];
            LM_GGML_UNUSED(x);
            assert(!isnan(x));
            assert(!isinf(x));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_silu_back_f16(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * grad = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    assert(lm_ggml_is_contiguous_1(grad));
    assert(lm_ggml_is_contiguous_1(src1));
    assert(lm_ggml_is_contiguous_1(dst));
    assert(lm_ggml_are_same_shape(src1, dst));
    assert(lm_ggml_are_same_shape(src1, grad));

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src1->ne[0];
    const int nr = lm_ggml_nrows(src1);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int i1 = ir0; i1 < ir1; i1++) {
        lm_ggml_vec_silu_backward_f16(nc,
                (lm_ggml_fp16_t *) ((char *) dst->data  + i1*( dst->nb[1])),
                (lm_ggml_fp16_t *) ((char *) src1->data + i1*(src1->nb[1])),
                (lm_ggml_fp16_t *) ((char *) grad->data + i1*(grad->nb[1])));

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const float x = ((lm_ggml_fp16_t *) ((char *) dst->data + i1*( dst->nb[1])))[k];
            const float v = LM_GGML_CPU_FP16_TO_FP32(x);
            LM_GGML_UNUSED(v);
            assert(!isnan(v));
            assert(!isinf(v));
        }
#endif // NDEBUG
    }
}

void lm_ggml_compute_forward_silu_back(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_silu_back_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_silu_back_f16(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_reglu

static void lm_ggml_compute_forward_reglu_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];
    char * src0_d = (char *) src0->data;
    char * src1_d = (char *) (src1 ? src1->data : src0->data);
    const size_t src0_o = src0->nb[1];
    const size_t src1_o = src1 ? src1->nb[1] : src0->nb[1];

    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src0));
    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(dst));

    if (src1) {
        LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src1));
        LM_GGML_ASSERT(src0->type == src1->type);
    }

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src1 ? src0->ne[0] : src0->ne[0] / 2;
    const int nr = lm_ggml_nrows(src0);

    LM_GGML_ASSERT(dst->ne[0] == nc);
    LM_GGML_ASSERT(lm_ggml_nrows(dst) == nr);

    const int32_t swapped = lm_ggml_get_op_params_i32(dst, 1);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int i1 = ir0; i1 < ir1; i1++) {
        float * src0_p = (float *) (src0_d + i1*src0_o);
        float * src1_p = (float *) (src1_d + i1*src1_o);

        if (!src1) {
            src0_p += swapped ? nc : 0;
            src1_p += swapped ? 0 : nc;
        }

        lm_ggml_vec_reglu_f32(nc, (float *) ((char *) dst->data + i1*(dst->nb[1])), src0_p, src1_p);

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const float x = ((float *) ((char *) dst->data + i1*( dst->nb[1])))[k];
            LM_GGML_UNUSED(x);
            assert(!isnan(x));
            assert(!isinf(x));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_reglu_f16(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];
    char * src0_d = (char *) src0->data;
    char * src1_d = (char *) (src1 ? src1->data : src0->data);
    const size_t src0_o = src0->nb[1];
    const size_t src1_o = src1 ? src1->nb[1] : src0->nb[1];

    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src0));
    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(dst));

    if (src1) {
        LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src1));
        LM_GGML_ASSERT(src0->type == src1->type);
    }

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src1 ? src0->ne[0] : src0->ne[0] / 2;
    const int nr = lm_ggml_nrows(src0);

    LM_GGML_ASSERT(dst->ne[0] == nc);
    LM_GGML_ASSERT(lm_ggml_nrows(dst) == nr);

    const int32_t swapped = lm_ggml_get_op_params_i32(dst, 1);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int i1 = ir0; i1 < ir1; i1++) {
        lm_ggml_fp16_t * src0_p = (lm_ggml_fp16_t *) (src0_d + i1*src0_o);
        lm_ggml_fp16_t * src1_p = (lm_ggml_fp16_t *) (src1_d + i1*src1_o);

        if (!src1) {
            src0_p += swapped ? nc : 0;
            src1_p += swapped ? 0 : nc;
        }

        lm_ggml_vec_reglu_f16(nc, (lm_ggml_fp16_t *) ((char *) dst->data + i1*(dst->nb[1])), src0_p, src1_p);

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const lm_ggml_fp16_t x = ((lm_ggml_fp16_t *) ((char *) dst->data + i1*( dst->nb[1])))[k];
            const float v = LM_GGML_FP16_TO_FP32(x);
            LM_GGML_UNUSED(v);
            assert(!isnan(v));
            assert(!isinf(v));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_reglu(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_reglu_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_reglu_f16(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_geglu

static void lm_ggml_compute_forward_geglu_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];
    char * src0_d = (char *) src0->data;
    char * src1_d = (char *) (src1 ? src1->data : src0->data);
    const size_t src0_o = src0->nb[1];
    const size_t src1_o = src1 ? src1->nb[1] : src0->nb[1];

    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src0));
    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(dst));

    if (src1) {
        LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src1));
        LM_GGML_ASSERT(src0->type == src1->type);
    }

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src1 ? src0->ne[0] : src0->ne[0] / 2;
    const int nr = lm_ggml_nrows(src0);

    LM_GGML_ASSERT(dst->ne[0] == nc);
    LM_GGML_ASSERT(lm_ggml_nrows(dst) == nr);

    const int32_t swapped = lm_ggml_get_op_params_i32(dst, 1);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int i1 = ir0; i1 < ir1; i1++) {
        float * src0_p = (float *) (src0_d + i1*src0_o);
        float * src1_p = (float *) (src1_d + i1*src1_o);

        if (!src1) {
            src0_p += swapped ? nc : 0;
            src1_p += swapped ? 0 : nc;
        }

        lm_ggml_vec_geglu_f32(nc, (float *) ((char *) dst->data + i1*(dst->nb[1])), src0_p, src1_p);

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const float x = ((float *) ((char *) dst->data + i1*( dst->nb[1])))[k];
            LM_GGML_UNUSED(x);
            assert(!isnan(x));
            assert(!isinf(x));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_geglu_f16(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];
    char * src0_d = (char *) src0->data;
    char * src1_d = (char *) (src1 ? src1->data : src0->data);
    const size_t src0_o = src0->nb[1];
    const size_t src1_o = src1 ? src1->nb[1] : src0->nb[1];

    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src0));
    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(dst));

    if (src1) {
        LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src1));
        LM_GGML_ASSERT(src0->type == src1->type);
    }

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src1 ? src0->ne[0] : src0->ne[0] / 2;
    const int nr = lm_ggml_nrows(src0);

    LM_GGML_ASSERT(dst->ne[0] == nc);
    LM_GGML_ASSERT(lm_ggml_nrows(dst) == nr);

    const int32_t swapped = lm_ggml_get_op_params_i32(dst, 1);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int i1 = ir0; i1 < ir1; i1++) {
        lm_ggml_fp16_t * src0_p = (lm_ggml_fp16_t *) (src0_d + i1*src0_o);
        lm_ggml_fp16_t * src1_p = (lm_ggml_fp16_t *) (src1_d + i1*src1_o);

        if (!src1) {
            src0_p += swapped ? nc : 0;
            src1_p += swapped ? 0 : nc;
        }

        lm_ggml_vec_geglu_f16(nc, (lm_ggml_fp16_t *) ((char *) dst->data + i1*(dst->nb[1])), src0_p, src1_p);

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const lm_ggml_fp16_t x = ((lm_ggml_fp16_t *) ((char *) dst->data + i1*( dst->nb[1])))[k];
            const float v = LM_GGML_FP16_TO_FP32(x);
            LM_GGML_UNUSED(v);
            assert(!isnan(v));
            assert(!isinf(v));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_geglu(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_geglu_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_geglu_f16(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_swiglu

static void lm_ggml_compute_forward_swiglu_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];
    char * src0_d = (char *) src0->data;
    char * src1_d = (char *) (src1 ? src1->data : src0->data);
    const size_t src0_o = src0->nb[1];
    const size_t src1_o = src1 ? src1->nb[1] : src0->nb[1];

    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src0));
    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(dst));

    if (src1) {
        LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src1));
        LM_GGML_ASSERT(src0->type == src1->type);
    }

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src1 ? src0->ne[0] : src0->ne[0] / 2;
    const int nr = lm_ggml_nrows(src0);

    LM_GGML_ASSERT(dst->ne[0] == nc);
    LM_GGML_ASSERT(lm_ggml_nrows(dst) == nr);

    const int32_t swapped = lm_ggml_get_op_params_i32(dst, 1);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int i1 = ir0; i1 < ir1; i1++) {
        float * src0_p = (float *) (src0_d + i1*src0_o);
        float * src1_p = (float *) (src1_d + i1*src1_o);

        if (!src1) {
            src0_p += swapped ? nc : 0;
            src1_p += swapped ? 0 : nc;
        }

        lm_ggml_vec_swiglu_f32(nc, (float *) ((char *) dst->data + i1*(dst->nb[1])), src0_p, src1_p);

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const float x = ((float *) ((char *) dst->data + i1*( dst->nb[1])))[k];
            LM_GGML_UNUSED(x);
            assert(!isnan(x));
            assert(!isinf(x));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_swiglu_f16(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];
    char * src0_d = (char *) src0->data;
    char * src1_d = (char *) (src1 ? src1->data : src0->data);
    const size_t src0_o = src0->nb[1];
    const size_t src1_o = src1 ? src1->nb[1] : src0->nb[1];

    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src0));
    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(dst));

    if (src1) {
        LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src1));
        LM_GGML_ASSERT(src0->type == src1->type);
    }

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src1 ? src0->ne[0] : src0->ne[0] / 2;
    const int nr = lm_ggml_nrows(src0);

    LM_GGML_ASSERT(dst->ne[0] == nc);
    LM_GGML_ASSERT(lm_ggml_nrows(dst) == nr);

    const int32_t swapped = lm_ggml_get_op_params_i32(dst, 1);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int i1 = ir0; i1 < ir1; i1++) {
        lm_ggml_fp16_t * src0_p = (lm_ggml_fp16_t *) (src0_d + i1*src0_o);
        lm_ggml_fp16_t * src1_p = (lm_ggml_fp16_t *) (src1_d + i1*src1_o);

        if (!src1) {
            src0_p += swapped ? nc : 0;
            src1_p += swapped ? 0 : nc;
        }

        lm_ggml_vec_swiglu_f16(nc, (lm_ggml_fp16_t *) ((char *) dst->data + i1*(dst->nb[1])), src0_p, src1_p);

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const lm_ggml_fp16_t x = ((lm_ggml_fp16_t *) ((char *) dst->data + i1*( dst->nb[1])))[k];
            const float v = LM_GGML_FP16_TO_FP32(x);
            LM_GGML_UNUSED(v);
            assert(!isnan(v));
            assert(!isinf(v));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_swiglu(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_swiglu_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_swiglu_f16(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_swiglu_oai

static void lm_ggml_compute_forward_swiglu_oai_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];
    char * src0_d = (char *) src0->data;
    char * src1_d = (char *) (src1 ? src1->data : src0->data);
    const size_t src0_o = src0->nb[1];
    const size_t src1_o = src1 ? src1->nb[1] : src0->nb[1];

    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src0));
    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(dst));

    if (src1) {
        LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src1));
        LM_GGML_ASSERT(src0->type == src1->type);
    }

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src1 ? src0->ne[0] : src0->ne[0] / 2;
    const int nr = lm_ggml_nrows(src0);

    LM_GGML_ASSERT(dst->ne[0] == nc);
    LM_GGML_ASSERT(lm_ggml_nrows(dst) == nr);

    const int32_t swapped = lm_ggml_get_op_params_i32(dst, 1);
    const float alpha = lm_ggml_get_op_params_f32(dst, 2);
    const float limit = lm_ggml_get_op_params_f32(dst, 3);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int i1 = ir0; i1 < ir1; i1++) {
        float * src0_p = (float *) (src0_d + i1*src0_o);
        float * src1_p = (float *) (src1_d + i1*src1_o);
        float * dst_p  = (float *) ((char *) dst->data + i1*(dst->nb[1]));

        if (!src1) {
            src0_p += swapped ? nc : 0;
            src1_p += swapped ? 0 : nc;
        }

        for (int k = 0; k < nc; k++) {
            const float x = std::min(src0_p[k], limit);
            const float y = std::clamp(src1_p[k], -limit, limit);
            const float out_glu = x / (1.f + expf(alpha * (-x)));
            dst_p[k] = out_glu * (y + 1.f);
        }

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const float x = dst_p[k];
            LM_GGML_UNUSED(x);
            assert(!isnan(x));
            assert(!isinf(x));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_swiglu_oai(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_swiglu_oai_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_geglu_erf

static void lm_ggml_compute_forward_geglu_erf_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];
    char * src0_d = (char *) src0->data;
    char * src1_d = (char *) (src1 ? src1->data : src0->data);
    const size_t src0_o = src0->nb[1];
    const size_t src1_o = src1 ? src1->nb[1] : src0->nb[1];

    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src0));
    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(dst));

    if (src1) {
        LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src1));
        LM_GGML_ASSERT(src0->type == src1->type);
    }

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src1 ? src0->ne[0] : src0->ne[0] / 2;
    const int nr = lm_ggml_nrows(src0);

    LM_GGML_ASSERT(dst->ne[0] == nc);
    LM_GGML_ASSERT(lm_ggml_nrows(dst) == nr);

    const int32_t swapped = lm_ggml_get_op_params_i32(dst, 1);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int i1 = ir0; i1 < ir1; i1++) {
        float * src0_p = (float *) (src0_d + i1*src0_o);
        float * src1_p = (float *) (src1_d + i1*src1_o);

        if (!src1) {
            src0_p += swapped ? nc : 0;
            src1_p += swapped ? 0 : nc;
        }

        lm_ggml_vec_geglu_erf_f32(nc, (float *) ((char *) dst->data + i1*(dst->nb[1])), src0_p, src1_p);

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const float x = ((float *) ((char *) dst->data + i1*( dst->nb[1])))[k];
            LM_GGML_UNUSED(x);
            assert(!isnan(x));
            assert(!isinf(x));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_geglu_erf_f16(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];
    char * src0_d = (char *) src0->data;
    char * src1_d = (char *) (src1 ? src1->data : src0->data);
    const size_t src0_o = src0->nb[1];
    const size_t src1_o = src1 ? src1->nb[1] : src0->nb[1];

    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src0));
    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(dst));

    if (src1) {
        LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src1));
        LM_GGML_ASSERT(src0->type == src1->type);
    }

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src1 ? src0->ne[0] : src0->ne[0] / 2;
    const int nr = lm_ggml_nrows(src0);

    LM_GGML_ASSERT(dst->ne[0] == nc);
    LM_GGML_ASSERT(lm_ggml_nrows(dst) == nr);

    const int32_t swapped = lm_ggml_get_op_params_i32(dst, 1);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int i1 = ir0; i1 < ir1; i1++) {
        lm_ggml_fp16_t * src0_p = (lm_ggml_fp16_t *) (src0_d + i1*src0_o);
        lm_ggml_fp16_t * src1_p = (lm_ggml_fp16_t *) (src1_d + i1*src1_o);

        if (!src1) {
            src0_p += swapped ? nc : 0;
            src1_p += swapped ? 0 : nc;
        }

        lm_ggml_vec_geglu_erf_f16(nc, (lm_ggml_fp16_t *) ((char *) dst->data + i1*(dst->nb[1])), src0_p, src1_p);

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const lm_ggml_fp16_t x = ((lm_ggml_fp16_t *) ((char *) dst->data + i1*( dst->nb[1])))[k];
            const float v = LM_GGML_FP16_TO_FP32(x);
            LM_GGML_UNUSED(v);
            assert(!isnan(v));
            assert(!isinf(v));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_geglu_erf(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_geglu_erf_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_geglu_erf_f16(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_geglu_quick

static void lm_ggml_compute_forward_geglu_quick_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];
    char * src0_d = (char *) src0->data;
    char * src1_d = (char *) (src1 ? src1->data : src0->data);
    const size_t src0_o = src0->nb[1];
    const size_t src1_o = src1 ? src1->nb[1] : src0->nb[1];

    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src0));
    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(dst));

    if (src1) {
        LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src1));
        LM_GGML_ASSERT(src0->type == src1->type);
    }

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src1 ? src0->ne[0] : src0->ne[0] / 2;
    const int nr = lm_ggml_nrows(src0);

    LM_GGML_ASSERT(dst->ne[0] == nc);
    LM_GGML_ASSERT(lm_ggml_nrows(dst) == nr);

    const int32_t swapped = lm_ggml_get_op_params_i32(dst, 1);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int i1 = ir0; i1 < ir1; i1++) {
        float * src0_p = (float *) (src0_d + i1*src0_o);
        float * src1_p = (float *) (src1_d + i1*src1_o);

        if (!src1) {
            src0_p += swapped ? nc : 0;
            src1_p += swapped ? 0 : nc;
        }

        lm_ggml_vec_geglu_quick_f32(nc, (float *) ((char *) dst->data + i1*(dst->nb[1])), src0_p, src1_p);

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const float x = ((float *) ((char *) dst->data + i1*( dst->nb[1])))[k];
            LM_GGML_UNUSED(x);
            assert(!isnan(x));
            assert(!isinf(x));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_geglu_quick_f16(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];
    char * src0_d = (char *) src0->data;
    char * src1_d = (char *) (src1 ? src1->data : src0->data);
    const size_t src0_o = src0->nb[1];
    const size_t src1_o = src1 ? src1->nb[1] : src0->nb[1];

    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src0));
    LM_GGML_ASSERT(lm_ggml_is_contiguous_1(dst));

    if (src1) {
        LM_GGML_ASSERT(lm_ggml_is_contiguous_1(src1));
        LM_GGML_ASSERT(src0->type == src1->type);
    }

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src1 ? src0->ne[0] : src0->ne[0] / 2;
    const int nr = lm_ggml_nrows(src0);

    LM_GGML_ASSERT(dst->ne[0] == nc);
    LM_GGML_ASSERT(lm_ggml_nrows(dst) == nr);

    const int32_t swapped = lm_ggml_get_op_params_i32(dst, 1);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int i1 = ir0; i1 < ir1; i1++) {
        lm_ggml_fp16_t * src0_p = (lm_ggml_fp16_t *) (src0_d + i1*src0_o);
        lm_ggml_fp16_t * src1_p = (lm_ggml_fp16_t *) (src1_d + i1*src1_o);

        if (!src1) {
            src0_p += swapped ? nc : 0;
            src1_p += swapped ? 0 : nc;
        }

        lm_ggml_vec_geglu_quick_f16(nc, (lm_ggml_fp16_t *) ((char *) dst->data + i1*(dst->nb[1])), src0_p, src1_p);

#ifndef NDEBUG
        for (int k = 0; k < nc; k++) {
            const lm_ggml_fp16_t x = ((lm_ggml_fp16_t *) ((char *) dst->data + i1*( dst->nb[1])))[k];
            const float v = LM_GGML_FP16_TO_FP32(x);
            LM_GGML_UNUSED(v);
            assert(!isnan(v));
            assert(!isinf(v));
        }
#endif // NDEBUG
    }
}

static void lm_ggml_compute_forward_geglu_quick(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_geglu_quick_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_geglu_quick_f16(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_norm

static void lm_ggml_compute_forward_norm_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, dst));

    LM_GGML_ASSERT(src0->nb[0] == sizeof(float));

    const int ith = params->ith;
    const int nth = params->nth;

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    float eps;
    memcpy(&eps, dst->op_params, sizeof(float));

    LM_GGML_ASSERT(eps >= 0.0f);

    for (int64_t i03 = 0; i03 < ne03; i03++) {
        for (int64_t i02 = 0; i02 < ne02; i02++) {
            for (int64_t i01 = ith; i01 < ne01; i01 += nth) {
                const float * x = (float *) ((char *) src0->data + i01*nb01 + i02*nb02 + i03*nb03);

                float sum = 0.0;
                lm_ggml_vec_sum_f32(ne00, &sum, x);
                float mean = sum/ne00;

                float * y = (float *) ((char *) dst->data + i01*nb1 + i02*nb2 + i03*nb3);
                float variance = 0;

#ifdef LM_GGML_USE_ACCELERATE
                mean = -mean;
                vDSP_vsadd(x, 1, &mean, y, 1, ne00);
                vDSP_measqv(y, 1, &variance, ne00);
#else
                variance = lm_ggml_vec_cvar_f32(ne00, y, x, mean);
#endif //LM_GGML_USE_ACCELERATE

                const float scale = 1.0f/sqrtf(variance + eps);
                lm_ggml_vec_scale_f32(ne00, y, scale);
            }
        }
    }
}

void lm_ggml_compute_forward_norm(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_norm_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_group_rms_norm

// fusion kinds that can be combined with the rms_norm computation in a single pass.
// extend this enum when adding new fused variants (e.g. FUSE_ADD, FUSE_MUL_ADD, ...).
enum lm_ggml_rms_norm_fuse_op {
    LM_GGML_RMS_NORM_FUSE_OP_NONE,
    LM_GGML_RMS_NORM_FUSE_OP_MUL,
};

template <lm_ggml_rms_norm_fuse_op FUSE_OP>
static void lm_ggml_compute_forward_rms_norm_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst_rms_norm,
        lm_ggml_tensor * dst_fused = nullptr) {

    const lm_ggml_tensor * src0 = dst_rms_norm->src[0];
    const lm_ggml_tensor * src1 = nullptr;
    lm_ggml_tensor       * dst  = dst_rms_norm;

    if constexpr (FUSE_OP == LM_GGML_RMS_NORM_FUSE_OP_MUL) {
        src1 = (dst_fused->src[0] == dst_rms_norm) ? dst_fused->src[1] : dst_fused->src[0];
        dst  = dst_fused;
    }

    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, dst));

    LM_GGML_ASSERT(src0->nb[0] == sizeof(float));

    const int ith = params->ith;
    const int nth = params->nth;

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    float eps;
    memcpy(&eps, dst_rms_norm->op_params, sizeof(float));
    LM_GGML_ASSERT(eps >= 0.0f);

    // TODO: optimize
    for (int64_t i03 = 0; i03 < ne03; i03++) {
        for (int64_t i02 = 0; i02 < ne02; i02++) {
            for (int64_t i01 = ith; i01 < ne01; i01 += nth) {
                const float * x = (float *) ((char *) src0->data + i01*nb01 + i02*nb02 + i03*nb03);

                lm_ggml_float sum = 0.0;
                // worth switching to explicit SIMD?
                for (int64_t i00 = 0; i00 < ne00; i00++) {
                    sum += (lm_ggml_float)(x[i00] * x[i00]);
                }

                const float mean  = sum/ne00;
                const float scale = 1.0f/sqrtf(mean + eps);

                // if you hit this, likely you got an inf somewhere earlier
                assert(scale > 0.0f);

                float * y = (float *) ((char *) dst->data + i01*nb1 + i02*nb2 + i03*nb3);

                if constexpr (FUSE_OP == LM_GGML_RMS_NORM_FUSE_OP_MUL) {
                    const int64_t i11 = i01 % ne11;
                    const int64_t i12 = i02 % ne12;
                    const int64_t i13 = i03 % ne13;
                    const float * w = (float *) ((char *) src1->data + i11*nb11 + i12*nb12 + i13*nb13);

                    for (int64_t i00 = 0; i00 < ne00; i00++) {
                        y[i00] = x[i00] * scale * w[i00];
                    }
                } else {
                    memcpy(y, x, ne00 * sizeof(float));
                    lm_ggml_vec_scale_f32(ne00, y, scale);
                }
            }
        }
    }
}

void lm_ggml_compute_forward_rms_norm(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_rms_norm_f32<LM_GGML_RMS_NORM_FUSE_OP_NONE>(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// Fused RMS_NORM + MUL: computes dst = rms_norm(src0) * src1 in a single pass.
// This avoids materializing the intermediate rms_norm result in memory.
void lm_ggml_compute_forward_rms_norm_mul_fused(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst_rms_norm,
        lm_ggml_tensor * dst_mul) {

    LM_GGML_ASSERT(dst_mul != nullptr);
    LM_GGML_ASSERT(dst_mul->src[0] == dst_rms_norm || dst_mul->src[1] == dst_rms_norm);

    const lm_ggml_tensor * src0 = dst_rms_norm->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_rms_norm_f32<LM_GGML_RMS_NORM_FUSE_OP_MUL>(params, dst_rms_norm, dst_mul);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

static void lm_ggml_compute_forward_rms_norm_back_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0]; // gradients from forward pass output
    const lm_ggml_tensor * src1 = dst->src[1]; // src1 from forward pass

    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, dst) && lm_ggml_are_same_shape(src0, src1));

    LM_GGML_ASSERT(src0->nb[0] == sizeof(float));
    LM_GGML_ASSERT(src1->nb[0] == sizeof(float));

    const int ith = params->ith;
    const int nth = params->nth;

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    float eps;
    memcpy(&eps, dst->op_params, sizeof(float));

    // TODO: optimize
    for (int64_t i03 = 0; i03 < ne03; i03++) {
        for (int64_t i02 = 0; i02 < ne02; i02++) {
            for (int64_t i01 = ith; i01 < ne01; i01 += nth) {
                // src1 is same shape as src0 => same indices
                const int64_t i11 = i01;
                const int64_t i12 = i02;
                const int64_t i13 = i03;

                const float * dz = (float *) ((char *) src0->data + i01*nb01 + i02*nb02 + i03*nb03);
                const float * x  = (float *) ((char *) src1->data + i11*nb11 + i12*nb12 + i13*nb13);

                lm_ggml_float sum_xx  = 0.0;
                lm_ggml_float sum_xdz = 0.0;

                for (int64_t i00 = 0; i00 < ne00; i00++) {
                    sum_xx  += (lm_ggml_float)(x[i00] * x[i00]);
                    sum_xdz += (lm_ggml_float)(x[i00] * dz[i00]);
                }

                //const float mean     = (float)(sum_xx)/ne00;
                const float mean_eps = (float)(sum_xx)/ne00 + eps;
                const float sum_eps  = (float)(sum_xx) + eps*ne00;
                //const float mean_xdz = (float)(sum_xdz)/ne00;
                // we could cache rms from forward pass to improve performance.
                // to do this implement lm_ggml_rms and compose lm_ggml_rms_norm using lm_ggml_rms.
                //const float rms      = sqrtf(mean_eps);
                const float rrms     = 1.0f / sqrtf(mean_eps);
                //const float scale    = -rrms/(ne00 * mean_eps); // -1/(n*rms**3)

                {
                    // z = rms_norm(x)
                    //
                    // rms_norm(src1) =
                    //     scale(
                    //         src1,
                    //         div(
                    //             1,
                    //             sqrt(
                    //                 add(
                    //                     scale(
                    //                         sum(
                    //                             sqr(
                    //                                 src1)),
                    //                         (1.0/N)),
                    //                     eps))));

                    // postorder:
                    // ## op    args         grad
                    // 00 param src1         grad[#00]
                    // 01 const 1
                    // 02 sqr   (#00)        grad[#02]
                    // 03 sum   (#02)        grad[#03]
                    // 04 const 1/N
                    // 05 scale (#03, #04)   grad[#05]
                    // 06 const eps
                    // 07 add   (#05, #06)   grad[#07]
                    // 08 sqrt  (#07)        grad[#08]
                    // 09 div   (#01,#08)    grad[#09]
                    // 10 scale (#00,#09)    grad[#10]
                    //
                    // backward pass, given grad[#10]
                    // #10: scale
                    // grad[#00] += scale(grad[#10],#09)
                    // grad[#09] += sum(mul(grad[#10],#00))
                    // #09: div
                    // grad[#08] += neg(mul(grad[#09], div(#09,#08)))
                    // #08: sqrt
                    // grad[#07] += mul(grad[#08], div(0.5, #08))
                    // #07: add
                    // grad[#05] += grad[#07]
                    // #05: scale
                    // grad[#03] += scale(grad[#05],#04)
                    // #03: sum
                    // grad[#02] += repeat(grad[#03], #02)
                    // #02:
                    // grad[#00] += scale(mul(#00, grad[#02]), 2.0)
                    //
                    // substitute and simplify:
                    // grad[#00] = scale(grad(#10), #09) + scale(mul(#00, grad[#02]), 2.0)
                    // grad[#02] = repeat(grad[#03], #02)
                    // grad[#02] = repeat(scale(grad[#05],#04), #02)
                    // grad[#02] = repeat(scale(grad[#07],#04), #02)
                    // grad[#02] = repeat(scale(mul(grad[#08], div(0.5, #08)),#04), #02)
                    // grad[#02] = repeat(scale(mul(neg(mul(grad[#09], div(#09,#08))), div(0.5, #08)),#04), #02)
                    // grad[#02] = repeat(scale(mul(neg(mul(sum(mul(grad[#10],#00)), div(#09,#08))), div(0.5, #08)),#04), #02)
                    // grad[#02] = repeat(-(sum(mul(grad[#10],#00)) * div(#09,#08) * div(0.5, #08) * (1/N)), #02)
                    // grad[#02] = repeat(-(sum(mul(grad[#10],#00)) * div(div(#01,#08),#08) * div(0.5, #08) * (1/N)), #02)
                    // grad[#02] = repeat(-(sum(mul(grad[#10],#00)) * div(1,#08*#08) * div(0.5, #08) * (1/N)), #02)
                    // grad[#02] = repeat(-(sum(mul(grad[#10],#00)) * div(1,#07) * div(0.5, #08) * (1/N)), #02)
                    // grad[#00] = scale(grad(#10), #09) + scale(mul(#00, grad[#02]), 2.0)
                    // grad[#00] = scale(grad(#10), #09) + scale(mul(#00, repeat(-(sum(mul(grad[#10],#00)) * div(1,#07) * div(0.5, #08) * (1/N)), #02)), 2.0)
                    // grad[#00] = scale(grad(#10), #09) + scale(scale(#00, -(sum(mul(grad[#10],#00)) * div(1,#07) * div(0.5, #08) * (1/N))), 2.0)
                    // grad[#00] = scale(grad(#10), #09) + scale(#00, -(sum(mul(grad[#10],#00)) * div(1,#07) * div(1,#08) * (1/N)))
                    // grad[#00] = scale(grad(#10), #09) + scale(#00, sum(mul(grad[#10],#00)) * div(1,#07*#08) * (-1/N))
                    // grad[#00] = scale(grad(#10), #09) + scale(#00, sum(mul(grad[#10],#00)) * div(1,#07*#08) * (-1/N))
                    // grad[#00] = scale(grad(#10), #09) + scale(#00, sum(mul(grad[#10],#00)) * div(1,mean_eps*rms) * (-1/N))
                    // grad[#00] = scale(grad(#10), #09) + scale(#00, sum(mul(grad[#10],#00)) * div(-1,rms*N*mean_eps))
                    // grad[#00] = scale(grad(#10), #09) + scale(#00, sum(mul(grad[#10],#00)) * div(-1,rms*N*(sum_xx/N+eps)))
                    // grad[#00] = scale(grad(#10), #09) + scale(#00, sum(mul(grad[#10],#00)) * div(-1,rms*N*sum_xx+rms*N*eps))
                    // grad[#00] = scale(dz, rrms) + scale(x, sum(mul(dz,x)) * div(-1,rms*N*mean_eps))
                    // grad[#00] = scale(dz, rrms) + scale(x, sum_xdz * div(-1,rms*N*mean_eps))
                    // a = b*c + d*e
                    // a = b*c*f/f + d*e*f/f
                    // a = (b*c*f + d*e*f)*(1/f)
                    // a = (b*c*(1/c) + d*e*(1/c))*(1/(1/c))
                    // a = (b + d*e/c)*c
                    // b = dz, c = rrms, d = x, e = sum_xdz * div(-1,rms*N*mean_eps)
                    // a = (dz + x*sum_xdz * div(-1,rms*N*mean_eps)/rrms)*rrms
                    // a = (dz + x*sum_xdz * div(-1,rms*N*mean_eps)*rms)*rrms
                    // a = (dz + x*sum_xdz * div(-rms,rms*N*mean_eps))*rrms
                    // a = (dz + x*sum_xdz * div(-1,N*mean_eps))*rrms
                    // a = (dz + x*div(-sum_xdz,N*mean_eps))*rrms
                    // a = (dz + x*div(-mean_xdz,mean_eps))*rrms
                    // grad[#00] = scale(dz + scale(x, div(-mean_xdz,mean_eps)),rrms)
                    // grad[#00] = scale(dz + scale(x, -mean_xdz/mean_eps),rrms)
                    // dx = scale(dz + scale(x, -mean_xdz/mean_eps),rrms)
                }
                // dx = scale(dz + scale(x, -mean_xdz/mean_eps),rrms)
                // post-order:
                // dx := x
                // dx := scale(dx,-mean_xdz/mean_eps)
                // dx := add(dx, dz)
                // dx := scale(dx, rrms)
                float * dx = (float *) ((char *) dst->data + i01*nb1 + i02*nb2 + i03*nb3);

                // dx[i00] = (dz + x*(-sum_xdz/sum_eps)) * rrms
                // note: https://github.com/ggml-org/ggml/issues/1491
                const float scale_x = (float) (-sum_xdz) / sum_eps;
                for (int64_t i00 = 0; i00 < ne00; i00++) {
                    dx[i00] = (dz[i00] + x[i00] * scale_x) * rrms;
                }
            }
        }
    }
}

void lm_ggml_compute_forward_rms_norm_back(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_rms_norm_back_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_group_norm

static void lm_ggml_compute_forward_group_norm_f32(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, dst));

    LM_GGML_ASSERT(src0->nb[0] == sizeof(float));

    const int ith = params->ith;
    const int nth = params->nth;

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    // TODO: optimize

    float eps;
    memcpy(&eps, dst->op_params + 1, sizeof(float));

    int n_channels = src0->ne[2];
    int n_groups = dst->op_params[0];
    int n_channels_per_group = (n_channels + n_groups - 1) / n_groups;
    for (int i = ith; i < n_groups; i += nth) {
        int start = i * n_channels_per_group;
        int end = start + n_channels_per_group;
        if (end > n_channels) {
            end = n_channels;
        }
        int step = end - start;

        for (int64_t i03 = 0; i03 < ne03; i03++) {
            lm_ggml_float sum = 0.0;
            for (int64_t i02 = start; i02 < end; i02++) {
                for (int64_t i01 = 0; i01 < ne01; i01++) {
                    const float * x = (float *)((char *) src0->data + i01 * nb01 + i02 * nb02 + i03 * nb03);

                    lm_ggml_float sumr = 0.0;
                    for (int64_t i00 = 0; i00 < ne00; i00++) {
                        sumr += (lm_ggml_float)x[i00];
                    }
                    sum += sumr;
                }
            }
            const float mean = sum / (ne00 * ne01 * step);

            lm_ggml_float sum2 = 0.0;
            for (int64_t i02 = start; i02 < end; i02++) {
                for (int64_t i01 = 0; i01 < ne01; i01++) {
                    const float * x = (float *)((char *) src0->data + i01 * nb01 + i02 * nb02 + i03 * nb03);

                    float * y = (float *)((char *) dst->data + i01 * nb1 + i02 * nb2 + i03 * nb3);

                    lm_ggml_float sumr = 0.0;
                    for (int64_t i00 = 0; i00 < ne00; i00++) {
                        float v = x[i00] - mean;
                        y[i00] = v;
                        sumr += (lm_ggml_float)(v * v);
                    }
                    sum2 += sumr;
                }
            }
            const float variance = sum2 / (ne00 * ne01 * step);
            const float scale = 1.0f / sqrtf(variance + eps);

            for (int64_t i02 = start; i02 < end; i02++) {
                for (int64_t i01 = 0; i01 < ne01; i01++) {
                    float * y = (float *)((char *) dst->data + i01 * nb1 + i02 * nb2 + i03 * nb3);
                    lm_ggml_vec_scale_f32(ne00, y, scale);
                }
            }
        }
    }
}

void lm_ggml_compute_forward_group_norm(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_group_norm_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_l2_norm

static void lm_ggml_compute_forward_l2_norm_f32(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, dst));

    LM_GGML_ASSERT(src0->nb[0] == sizeof(float));

    const int ith = params->ith;
    const int nth = params->nth;

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    float eps;
    memcpy(&eps, dst->op_params, sizeof(float));

    LM_GGML_ASSERT(eps >= 0.0f);

    // TODO: optimize
    for (int64_t i03 = 0; i03 < ne03; i03++) {
        for (int64_t i02 = 0; i02 < ne02; i02++) {
            for (int64_t i01 = ith; i01 < ne01; i01 += nth) {
                const float * x = (float *) ((char *) src0->data + i01*nb01 + i02*nb02 + i03*nb03);

                lm_ggml_float sum = 0.0;
                for (int64_t i00 = 0; i00 < ne00; i00++) {
                    sum += (lm_ggml_float)(x[i00] * x[i00]);
                }

                float * y = (float *) ((char *) dst->data + i01*nb1 + i02*nb2 + i03*nb3);

                memcpy(y, x, ne00 * sizeof(float));

                const float scale = 1.0f/fmaxf(sqrtf(sum), eps);

                lm_ggml_vec_scale_f32(ne00, y, scale);
            }
        }
    }
}

void lm_ggml_compute_forward_l2_norm(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_l2_norm_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_out_prod

static void lm_ggml_compute_forward_out_prod_f32(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    LM_GGML_ASSERT(dst->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F32);

    const int ith = params->ith;
    const int nth = params->nth;

    LM_GGML_ASSERT(ne0 == ne00);
    LM_GGML_ASSERT(ne1 == ne10);
    LM_GGML_ASSERT(ne2 == ne12);
    LM_GGML_ASSERT(ne3 == ne13);

    LM_GGML_ASSERT(ne2 % ne02 == 0);
    LM_GGML_ASSERT(ne3 % ne03 == 0);

    // we don't support permuted src0 or src1
    LM_GGML_ASSERT(nb00 == sizeof(float));

    // dst cannot be transposed or permuted
    LM_GGML_ASSERT(nb0 == sizeof(float));
    // LM_GGML_ASSERT(nb0 <= nb1);
    // LM_GGML_ASSERT(nb1 <= nb2);
    // LM_GGML_ASSERT(nb2 <= nb3);

    // nb01 >= nb00 - src0 is not transposed
    //   compute by src0 rows

    if (ith == 0) {
        lm_ggml_vec_set_f32(ne0*ne1*ne2*ne3, (float *)dst->data, 0);
    }
    lm_ggml_barrier(params->threadpool);

    // dst[:,:,:,:] = 0
    // for i2,i3:
    //   for i1:
    //     for i01:
    //       for i0:
    //         dst[i0,i1,i2,i3] += src0[i0,i01,i2,i3] * src1[i1,i01,i2,i3]

    // parallelize by last three dimensions

    // total rows in dst
    const int64_t nr = ne1*ne2*ne3;

    // rows per thread
    const int64_t dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int64_t ir0 = dr*ith;
    const int64_t ir1 = MIN(ir0 + dr, nr);

    // block-tiling attempt
    const int64_t blck_0 = MAX(LM_GGML_VEC_MAD_UNROLL, 32);
    const int64_t blck_1 = 16;

    // dps == dst per src0, used for group query attention
    const int64_t dps2 = ne2 / ne02;
    const int64_t dps3 = ne3 / ne03;

    for (int64_t bir = ir0; bir < ir1; bir += blck_1) {
        const int64_t bir1 = MIN(bir + blck_1, ir1);
        for (int64_t bi01 = 0; bi01 < ne01; bi01 += blck_0) {
            const int64_t bne01 = MIN(bi01 + blck_0, ne01);
            for (int64_t ir = bir; ir < bir1; ++ir) {
                // dst indices
                const int64_t i3 = ir/(ne2*ne1);
                const int64_t i2 = (ir - i3*ne2*ne1)/ne1;
                const int64_t i1 = (ir - i3*ne2*ne1 - i2*ne1);

                const int64_t i02 = i2 / dps2;
                const int64_t i03 = i3 / dps3;

                //const int64_t i10 = i1;
                const int64_t i12 = i2;
                const int64_t i13 = i3;

#if LM_GGML_VEC_MAD_UNROLL > 2
                const int64_t bne01_unroll = bne01 - (bne01 % LM_GGML_VEC_MAD_UNROLL);
                for (int64_t i01 = bi01; i01 < bne01_unroll; i01 += LM_GGML_VEC_MAD_UNROLL) {
                    const int64_t i11 = i01;

                    float * s0 = (float *) ((char *) src0->data + (          i01*nb01 + i02*nb02 + i03*nb03));
                    float * s1 = (float *) ((char *) src1->data + (i1*nb10 + i11*nb11 + i12*nb12 + i13*nb13));
                    float * d  = (float *) ((char *)  dst->data + (          i1*nb1   + i2*nb2   + i3*nb3));

                    lm_ggml_vec_mad_f32_unroll(ne0, nb01, nb11, d, s0, s1);
                }
                for (int64_t i01 = bne01_unroll; i01 < bne01; ++i01) {
                    const int64_t i11 = i01;

                    float * s0 = (float *) ((char *) src0->data + (          i01*nb01 + i02*nb02 + i03*nb03));
                    float * s1 = (float *) ((char *) src1->data + (i1*nb10 + i11*nb11 + i12*nb12 + i13*nb13));
                    float * d  = (float *) ((char *)  dst->data + (          i1*nb1   + i2*nb2   + i3*nb3));

                    lm_ggml_vec_mad_f32(ne0, d, s0, *s1);
                }
#else
                for (int64_t i01 = bi01; i01 < bne01; ++i01) {
                    const int64_t i11 = i01;

                    float * s0 = (float *) ((char *) src0->data + (          i01*nb01 + i02*nb02 + i03*nb03));
                    float * s1 = (float *) ((char *) src1->data + (i1*nb10 + i11*nb11 + i12*nb12 + i13*nb13));
                    float * d  = (float *) ((char *)  dst->data + (          i1*nb1 + i2*nb2 + i3*nb3));

                    lm_ggml_vec_mad_f32(ne0, d, s0, *s1);
                }
#endif
            }
        }
    }
}

static void lm_ggml_compute_forward_out_prod_q_f32(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_TENSOR_BINARY_OP_LOCALS;

    const int ith = params->ith;
    const int nth = params->nth;

    const lm_ggml_type type = src0->type;
    lm_ggml_to_float_t const dequantize_row_q = lm_ggml_get_type_traits(type)->to_float;

    LM_GGML_ASSERT(ne02 == ne12);
    LM_GGML_ASSERT(ne03 == ne13);
    LM_GGML_ASSERT(ne2  == ne12);
    LM_GGML_ASSERT(ne3  == ne13);

    // we don't support permuted src0 dim0
    LM_GGML_ASSERT(nb00 == lm_ggml_type_size(type));

    // dst dim0 cannot be transposed or permuted
    LM_GGML_ASSERT(nb0 == sizeof(float));
    // LM_GGML_ASSERT(nb0 <= nb1);
    // LM_GGML_ASSERT(nb1 <= nb2);
    // LM_GGML_ASSERT(nb2 <= nb3);

    LM_GGML_ASSERT(ne0 == ne00);
    LM_GGML_ASSERT(ne1 == ne10);
    LM_GGML_ASSERT(ne2 == ne02);
    LM_GGML_ASSERT(ne3 == ne03);

    // nb01 >= nb00 - src0 is not transposed
    //   compute by src0 rows

    if (ith == 0) {
        lm_ggml_vec_set_f32(ne0*ne1*ne2*ne3, (float *)dst->data, 0);
    }
    lm_ggml_barrier(params->threadpool);

    // parallelize by last three dimensions

    // total rows in dst
    const int64_t nr = ne1*ne2*ne3;

    // rows per thread
    const int64_t dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int64_t ir0 = dr*ith;
    const int64_t ir1 = MIN(ir0 + dr, nr);

    // dst[:,:,:,:] = 0
    // for i2,i3:
    //   for i1:
    //     for i01:
    //       for i0:
    //         dst[i0,i1,i2,i3] += src0[i0,i01,i2,i3] * src1[i1,i01,i2,i3]

    float * wdata = (float *) params->wdata + (ne0 + CACHE_LINE_SIZE_F32) * ith;

    for (int64_t ir = ir0; ir < ir1; ++ir) {
        // dst indices
        const int64_t i3 = ir/(ne2*ne1);
        const int64_t i2 = (ir - i3*ne2*ne1)/ne1;
        const int64_t i1 = (ir - i3*ne2*ne1 - i2*ne1);

        const int64_t i02 = i2;
        const int64_t i03 = i3;

        //const int64_t i10 = i1;
        const int64_t i12 = i2;
        const int64_t i13 = i3;

        for (int64_t i01 = 0; i01 < ne01; ++i01) {
            const int64_t i11 = i01;

            float * s0 = (float *) ((char *) src0->data + (          i01*nb01 + i02*nb02 + i03*nb03));
            float * s1 = (float *) ((char *) src1->data + (i1*nb10 + i11*nb11 + i12*nb12 + i13*nb13));
            float * d  = (float *) ((char *)  dst->data + (          i1*nb1 + i2*nb2 + i3*nb3));

            dequantize_row_q(s0, wdata, ne0);
            lm_ggml_vec_mad_f32(ne0, d, wdata, *s1);
        }
    }
}

void lm_ggml_compute_forward_out_prod(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_Q1_0:
        case LM_GGML_TYPE_Q4_0:
        case LM_GGML_TYPE_Q4_1:
        case LM_GGML_TYPE_Q5_0:
        case LM_GGML_TYPE_Q5_1:
        case LM_GGML_TYPE_Q8_0:
        case LM_GGML_TYPE_MXFP4:
        case LM_GGML_TYPE_NVFP4:
        case LM_GGML_TYPE_Q2_K:
        case LM_GGML_TYPE_Q3_K:
        case LM_GGML_TYPE_Q4_K:
        case LM_GGML_TYPE_Q5_K:
        case LM_GGML_TYPE_Q6_K:
        case LM_GGML_TYPE_TQ1_0:
        case LM_GGML_TYPE_TQ2_0:
        case LM_GGML_TYPE_IQ2_XXS:
        case LM_GGML_TYPE_IQ2_XS:
        case LM_GGML_TYPE_IQ3_XXS:
        case LM_GGML_TYPE_IQ1_S:
        case LM_GGML_TYPE_IQ1_M:
        case LM_GGML_TYPE_IQ4_NL:
        case LM_GGML_TYPE_IQ4_XS:
        case LM_GGML_TYPE_IQ3_S:
        case LM_GGML_TYPE_IQ2_S:
            {
                lm_ggml_compute_forward_out_prod_q_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
            {
                LM_GGML_ABORT("fatal error"); // todo
                // lm_ggml_compute_forward_out_prod_f16_f32(params, dst);
            }
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_out_prod_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_scale

static void lm_ggml_compute_forward_scale_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    LM_GGML_ASSERT(lm_ggml_is_contiguous(src0));
    LM_GGML_ASSERT(lm_ggml_is_contiguous(dst));
    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, dst));

    float s; // scale factor
    float b; // bias

    memcpy(&s, (float *) dst->op_params + 0, sizeof(float));
    memcpy(&b, (float *) dst->op_params + 1, sizeof(float));

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src0->ne[0];
    const int nr = lm_ggml_nrows(src0);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    const size_t nb01 = src0->nb[1];

    const size_t nb1 = dst->nb[1];

    if (b == 0.0f) {
        for (int i1 = ir0; i1 < ir1; i1++) {
            if (dst->data != src0->data) {
                // src0 is same shape as dst => same indices
                // TODO: add x parameter to lm_ggml_vec_scale_f32 and remove this memcpy
                memcpy((char *)dst->data + i1*nb1, (char *)src0->data + i1*nb01, nc * sizeof(float));
            }
            lm_ggml_vec_scale_f32(nc, (float *) ((char *) dst->data + i1*nb1), s);
        }
    } else {
        for (int i1 = ir0; i1 < ir1; i1++) {
            lm_ggml_vec_mad1_f32(nc,
                (float *) ((char *) dst->data  + i1*nb1),
                (float *) ((char *) src0->data + i1*nb1),
                s, b);
        }
    }
}

void lm_ggml_compute_forward_scale(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_scale_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_set

static void lm_ggml_compute_forward_set_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, dst));
    LM_GGML_ASSERT(lm_ggml_is_contiguous(dst) && lm_ggml_is_contiguous(src0));

    // view src0 and dst with these strides and data offset inbytes during set
    // nb0 is implicitly element_size because src0 and dst are contiguous
    size_t nb1     = ((int32_t *) dst->op_params)[0];
    size_t nb2     = ((int32_t *) dst->op_params)[1];
    size_t nb3     = ((int32_t *) dst->op_params)[2];
    size_t offset  = ((int32_t *) dst->op_params)[3];
    bool   inplace = (bool) ((int32_t *) dst->op_params)[4];

    if (!inplace) {
        if (params->ith == 0) {
            // memcpy needs to be synchronized across threads to avoid race conditions.
            // => do it in INIT phase
            memcpy(
                ((char *)  dst->data),
                ((char *) src0->data),
                lm_ggml_nbytes(dst));
        }
        lm_ggml_barrier(params->threadpool);
    }

    const int ith = params->ith;
    const int nth = params->nth;

    const int nr = lm_ggml_nrows(src1);
    const int nc = src1->ne[0];

    LM_GGML_TENSOR_LOCALS(int64_t, ne1, src1, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb1, src1, nb)

    // src0 and dst as viewed during set
    const size_t nb0 = lm_ggml_element_size(src0);

    const int im0 = (ne10 == 0 ? 0 : ne10-1);
    const int im1 = (ne11 == 0 ? 0 : ne11-1);
    const int im2 = (ne12 == 0 ? 0 : ne12-1);
    const int im3 = (ne13 == 0 ? 0 : ne13-1);

    LM_GGML_ASSERT(offset + im0*nb0  + im1*nb1  + im2*nb2  + im3*nb3  <= lm_ggml_nbytes(dst));

    LM_GGML_ASSERT(nb10 == sizeof(float));

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int ir = ir0; ir < ir1; ++ir) {
        // src0 and dst are viewed with shape of src1 and offset
        // => same indices
        const int i3 = ir/(ne12*ne11);
        const int i2 = (ir - i3*ne12*ne11)/ne11;
        const int i1 = (ir - i3*ne12*ne11 - i2*ne11);

        lm_ggml_vec_cpy_f32(nc,
                (float *) ((char *)  dst->data + i3*nb3  + i2*nb2  + i1*nb1  + offset),
                (float *) ((char *) src1->data + i3*nb13 + i2*nb12 + i1*nb11));
    }
}

static void lm_ggml_compute_forward_set_i32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, dst));
    LM_GGML_ASSERT(lm_ggml_is_contiguous(dst) && lm_ggml_is_contiguous(src0));

    // view src0 and dst with these strides and data offset inbytes during set
    // nb0 is implicitly element_size because src0 and dst are contiguous
    size_t nb1     = ((int32_t *) dst->op_params)[0];
    size_t nb2     = ((int32_t *) dst->op_params)[1];
    size_t nb3     = ((int32_t *) dst->op_params)[2];
    size_t offset  = ((int32_t *) dst->op_params)[3];
    bool   inplace = (bool) ((int32_t *) dst->op_params)[4];

    if (!inplace) {
        if (params->ith == 0) {
            // memcpy needs to be synchronized across threads to avoid race conditions.
            // => do it in INIT phase
            memcpy(
                ((char *)  dst->data),
                ((char *) src0->data),
                lm_ggml_nbytes(dst));
        }
        lm_ggml_barrier(params->threadpool);
    }

    const int ith = params->ith;
    const int nth = params->nth;

    const int nr = lm_ggml_nrows(src1);
    const int nc = src1->ne[0];

    LM_GGML_TENSOR_LOCALS(int64_t, ne1, src1, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb1, src1, nb)

    // src0 and dst as viewed during set
    const size_t nb0 = lm_ggml_element_size(src0);

    const int im0 = (ne10 == 0 ? 0 : ne10-1);
    const int im1 = (ne11 == 0 ? 0 : ne11-1);
    const int im2 = (ne12 == 0 ? 0 : ne12-1);
    const int im3 = (ne13 == 0 ? 0 : ne13-1);

    LM_GGML_ASSERT(offset + im0*nb0  + im1*nb1  + im2*nb2  + im3*nb3  <= lm_ggml_nbytes(dst));

    LM_GGML_ASSERT(nb10 == sizeof(int32_t));

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int ir = ir0; ir < ir1; ++ir) {
        // src0 and dst are viewed with shape of src1 and offset
        // => same indices
        const int i3 = ir/(ne12*ne11);
        const int i2 = (ir - i3*ne12*ne11)/ne11;
        const int i1 = (ir - i3*ne12*ne11 - i2*ne11);

        lm_ggml_vec_cpy_i32(nc,
                (int32_t *) ((char *)  dst->data + i3*nb3  + i2*nb2  + i1*nb1  + offset),
                (int32_t *) ((char *) src1->data + i3*nb13 + i2*nb12 + i1*nb11));
    }
}

void lm_ggml_compute_forward_set(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_set_f32(params, dst);
            } break;
        case LM_GGML_TYPE_I32:
            {
                lm_ggml_compute_forward_set_i32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
        case LM_GGML_TYPE_BF16:
        case LM_GGML_TYPE_Q1_0:
        case LM_GGML_TYPE_Q4_0:
        case LM_GGML_TYPE_Q4_1:
        case LM_GGML_TYPE_Q5_0:
        case LM_GGML_TYPE_Q5_1:
        case LM_GGML_TYPE_Q8_0:
        case LM_GGML_TYPE_Q8_1:
        case LM_GGML_TYPE_MXFP4:
        case LM_GGML_TYPE_NVFP4:
        case LM_GGML_TYPE_Q2_K:
        case LM_GGML_TYPE_Q3_K:
        case LM_GGML_TYPE_Q4_K:
        case LM_GGML_TYPE_Q5_K:
        case LM_GGML_TYPE_Q6_K:
        case LM_GGML_TYPE_TQ1_0:
        case LM_GGML_TYPE_TQ2_0:
        case LM_GGML_TYPE_IQ2_XXS:
        case LM_GGML_TYPE_IQ2_XS:
        case LM_GGML_TYPE_IQ3_XXS:
        case LM_GGML_TYPE_IQ1_S:
        case LM_GGML_TYPE_IQ1_M:
        case LM_GGML_TYPE_IQ4_NL:
        case LM_GGML_TYPE_IQ4_XS:
        case LM_GGML_TYPE_IQ3_S:
        case LM_GGML_TYPE_IQ2_S:
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_cpy

void lm_ggml_compute_forward_cpy(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {
    lm_ggml_compute_forward_dup(params, dst);
}

// lm_ggml_compute_forward_cont

void lm_ggml_compute_forward_cont(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {
    lm_ggml_compute_forward_dup(params, dst);
}

// lm_ggml_compute_forward_get_rows

static void lm_ggml_compute_forward_get_rows_q(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    const int64_t nc = ne00;
    const int64_t nr = lm_ggml_nelements(src1);

    const lm_ggml_type type = src0->type;
    lm_ggml_to_float_t const dequantize_row_q = lm_ggml_get_type_traits(type)->to_float;

    assert(ne0  == nc);
    assert(ne02 == ne11);
    assert(nb00 == lm_ggml_type_size(type));
    assert(lm_ggml_nrows(dst) == nr);

    const int ith = params->ith;
    const int nth = params->nth;

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int64_t i = ir0; i < ir1; ++i) {
        const int64_t i12 = i/(ne11*ne10);
        const int64_t i11 = (i - i12*ne11*ne10)/ne10;
        const int64_t i10 = (i - i12*ne11*ne10 - i11*ne10);
        const int64_t i01 = *(int32_t *) ((char *) src1->data + i10*nb10 + i11*nb11 + i12*nb12);

        LM_GGML_ASSERT(i01 >= 0 && i01 < ne01);

        dequantize_row_q(
                (const void *) ((char *) src0->data + i01*nb01 + i11*nb02 + i12*nb03),
                     (float *) ((char *)  dst->data + i10*nb1  + i11*nb2  + i12*nb3), nc);
    }
}

static void lm_ggml_compute_forward_get_rows_f16(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    const int64_t nc = ne00;
    const int64_t nr = lm_ggml_nelements(src1);

    assert(ne0  == nc);
    assert(ne02 == ne11);
    assert(nb00 == sizeof(lm_ggml_fp16_t));
    assert(lm_ggml_nrows(dst) == nr);

    const int ith = params->ith;
    const int nth = params->nth;

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int64_t i = ir0; i < ir1; ++i) {
        const int64_t i12 = i/(ne11*ne10);
        const int64_t i11 = (i - i12*ne11*ne10)/ne10;
        const int64_t i10 = (i - i12*ne11*ne10 - i11*ne10);
        const int64_t i01 = *(int32_t *) ((char *) src1->data + i10*nb10 + i11*nb11 + i12*nb12);

        LM_GGML_ASSERT(i01 >= 0 && i01 < ne01);

        lm_ggml_cpu_fp16_to_fp32(
            (const lm_ggml_fp16_t*) ((char *) src0->data + i01*nb01 + i11*nb02 + i12*nb03),
                       (float *) ((char *)  dst->data + i10*nb1  + i11*nb2  + i12*nb3), nc);
    }
}

static void lm_ggml_compute_forward_get_rows_bf16(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    const int64_t nc = ne00;
    const int64_t nr = lm_ggml_nelements(src1);

    assert(ne0  == nc);
    assert(ne02 == ne11);
    assert(nb00 == sizeof(lm_ggml_bf16_t));
    assert(lm_ggml_nrows(dst) == nr);

    const int ith = params->ith;
    const int nth = params->nth;

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int64_t i = ir0; i < ir1; ++i) {
        const int64_t i12 = i/(ne11*ne10);
        const int64_t i11 = (i - i12*ne11*ne10)/ne10;
        const int64_t i10 = (i - i12*ne11*ne10 - i11*ne10);
        const int64_t i01 = *(int32_t *) ((char *) src1->data + i10*nb10 + i11*nb11 + i12*nb12);

        LM_GGML_ASSERT(i01 >= 0 && i01 < ne01);

        lm_ggml_cpu_bf16_to_fp32(
            (const lm_ggml_bf16_t *) ((char *) src0->data + i01*nb01 + i11*nb02 + i12*nb03),
                        (float *) ((char *)  dst->data + i10*nb1  + i11*nb2  + i12*nb3), nc);
    }
}

static void lm_ggml_compute_forward_get_rows_f32(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    const int64_t nc = ne00;
    const int64_t nr = lm_ggml_nelements(src1);

    assert(ne0  == nc);
    assert(ne02 == ne11);
    assert(nb00 == sizeof(float));
    assert(lm_ggml_nrows(dst) == nr);

    const int ith = params->ith;
    const int nth = params->nth;

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int64_t i = ir0; i < ir1; ++i) {
        const int64_t i12 = i/(ne11*ne10);
        const int64_t i11 = (i - i12*ne11*ne10)/ne10;
        const int64_t i10 = (i - i12*ne11*ne10 - i11*ne10);
        const int64_t i01 = *(int32_t *) ((char *) src1->data + i10*nb10 + i11*nb11 + i12*nb12);

        LM_GGML_ASSERT(i01 >= 0 && i01 < ne01);

        lm_ggml_vec_cpy_f32(nc,
                (float *) ((char *)  dst->data + i10*nb1  + i11*nb2  + i12*nb3),
                (float *) ((char *) src0->data + i01*nb01 + i11*nb02 + i12*nb03));
    }
}

void lm_ggml_compute_forward_get_rows(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_Q1_0:
        case LM_GGML_TYPE_Q4_0:
        case LM_GGML_TYPE_Q4_1:
        case LM_GGML_TYPE_Q5_0:
        case LM_GGML_TYPE_Q5_1:
        case LM_GGML_TYPE_Q8_0:
        case LM_GGML_TYPE_Q8_1:
        case LM_GGML_TYPE_MXFP4:
        case LM_GGML_TYPE_NVFP4:
        case LM_GGML_TYPE_Q2_K:
        case LM_GGML_TYPE_Q3_K:
        case LM_GGML_TYPE_Q4_K:
        case LM_GGML_TYPE_Q5_K:
        case LM_GGML_TYPE_Q6_K:
        case LM_GGML_TYPE_TQ1_0:
        case LM_GGML_TYPE_TQ2_0:
        case LM_GGML_TYPE_IQ2_XXS:
        case LM_GGML_TYPE_IQ2_XS:
        case LM_GGML_TYPE_IQ3_XXS:
        case LM_GGML_TYPE_IQ1_S:
        case LM_GGML_TYPE_IQ1_M:
        case LM_GGML_TYPE_IQ4_NL:
        case LM_GGML_TYPE_IQ4_XS:
        case LM_GGML_TYPE_IQ3_S:
        case LM_GGML_TYPE_IQ2_S:
            {
                lm_ggml_compute_forward_get_rows_q(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_get_rows_f16(params, dst);
            } break;
        case LM_GGML_TYPE_BF16:
            {
                lm_ggml_compute_forward_get_rows_bf16(params, dst);
            } break;
        case LM_GGML_TYPE_F32:
        case LM_GGML_TYPE_I32:
            {
                lm_ggml_compute_forward_get_rows_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }

    //static bool first = true;
    //printf("ne0 = %d, ne1 = %d, ne2 = %d\n", dst->ne[0], dst->ne[1], dst->ne[2]);
    //if (first) {
    //    first = false;
    //} else {
    //    for (int k = 0; k < dst->ne[1]; ++k) {
    //        for (int j = 0; j < dst->ne[0]/16; ++j) {
    //            for (int i = 0; i < 16; ++i) {
    //                printf("%8.4f ", ((float *) dst->data)[k*dst->ne[0] + j*16 + i]);
    //            }
    //            printf("\n");
    //        }
    //        printf("\n");
    //    }
    //    printf("\n");
    //    exit(0);
    //}
}

template<typename idx_t>
static void lm_ggml_compute_forward_set_rows_f32(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    const int64_t nc = ne00;
    const int64_t nr = ne01;

    assert(ne0  == nc);
    assert(ne2  == ne02);
    assert(ne3  == ne03);
    assert(src0->type == LM_GGML_TYPE_F32);
    assert(ne02 % ne11 == 0);
    assert(ne03 % ne12 == 0);

    const int ith = params->ith;
    const int nth = params->nth;

    // rows per thread
    const int64_t dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int64_t ir0 = dr*ith;
    const int64_t ir1 = std::min(ir0 + dr, nr);

    lm_ggml_from_float_t const from_float = lm_ggml_get_type_traits_cpu(dst->type)->from_float;

    for (int64_t i03 = 0; i03 < ne03; ++i03) {
        for (int64_t i02 = 0; i02 < ne02; ++i02) {
            for (int64_t i = ir0; i < ir1; ++i) {
                const int64_t i12 = i03%ne12;
                const int64_t i11 = i02%ne11;
                const int64_t i10 = i;

                const int64_t i1 = *(idx_t *) ((char *) src1->data + i10*nb10 + i11*nb11 + i12*nb12);

                LM_GGML_ASSERT(i1 >= 0 && i1 < ne1);

                from_float(
                        (const float *) ((char *) src0->data +  i*nb01 + i02*nb02 + i03*nb03),
                                        ((char *)  dst->data + i1*nb1  + i02*nb2  + i03*nb3), nc);
            }
        }
    }
}

void lm_ggml_compute_forward_set_rows(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                if (src1->type == LM_GGML_TYPE_I64) {
                    lm_ggml_compute_forward_set_rows_f32<int64_t>(params, dst);
                } else if (src1->type == LM_GGML_TYPE_I32) {
                    lm_ggml_compute_forward_set_rows_f32<int32_t>(params, dst);
                } else {
                    LM_GGML_ABORT("src1->type = %d (%s) not supported", src1->type, lm_ggml_type_name(src1->type));
                }
            } break;
        default:
            {
                LM_GGML_ABORT("src0->type = %d (%s) not supported", src0->type, lm_ggml_type_name(src0->type));
            }
    }
}

// lm_ggml_compute_forward_get_rows_back

static void lm_ggml_compute_forward_get_rows_back_f32_f16(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    if (params->ith != 0) {
        return;
    }

    LM_GGML_ASSERT(lm_ggml_is_contiguous(dst));

    // lm_ggml_compute_forward_dup_same_cont(params, opt0, dst);

    memset(dst->data, 0, lm_ggml_nbytes(dst));

    const int nc = src0->ne[0];
    const int nr = lm_ggml_nelements(src1);

    LM_GGML_ASSERT( dst->ne[0] == nc);
    LM_GGML_ASSERT(src0->nb[0] == sizeof(lm_ggml_fp16_t));

    for (int i = 0; i < nr; ++i) {
        const int r = ((int32_t *) src1->data)[i];

        for (int j = 0; j < nc; ++j) {
            lm_ggml_fp16_t v = ((lm_ggml_fp16_t *) ((char *) src0->data + i*src0->nb[1]))[j];
            ((float *) ((char *) dst->data + r*dst->nb[1]))[j] += LM_GGML_CPU_FP16_TO_FP32(v);
        }
    }
}

static void lm_ggml_compute_forward_get_rows_back_f32(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    if (params->ith != 0) {
        return;
    }

    LM_GGML_ASSERT(lm_ggml_is_contiguous(dst));

    // lm_ggml_compute_forward_dup_same_cont(params, opt0, dst);

    memset(dst->data, 0, lm_ggml_nbytes(dst));

    const int nc = src0->ne[0];
    const int nr = lm_ggml_nelements(src1);

    LM_GGML_ASSERT( dst->ne[0] == nc);
    LM_GGML_ASSERT(src0->nb[0] == sizeof(float));

    for (int i = 0; i < nr; ++i) {
        const int r = ((int32_t *) src1->data)[i];

        lm_ggml_vec_add_f32(nc,
                (float *) ((char *)  dst->data + r*dst->nb[1]),
                (float *) ((char *)  dst->data + r*dst->nb[1]),
                (float *) ((char *) src0->data + i*src0->nb[1]));
    }
}

void lm_ggml_compute_forward_get_rows_back(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_get_rows_back_f32_f16(params, dst);
            } break;
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_get_rows_back_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }

    //static bool first = true;
    //printf("ne0 = %d, ne1 = %d, ne2 = %d\n", dst->ne[0], dst->ne[1], dst->ne[2]);
    //if (first) {
    //    first = false;
    //} else {
    //    for (int k = 0; k < dst->ne[1]; ++k) {
    //        for (int j = 0; j < dst->ne[0]/16; ++j) {
    //            for (int i = 0; i < 16; ++i) {
    //                printf("%8.4f ", ((float *) dst->data)[k*dst->ne[0] + j*16 + i]);
    //            }
    //            printf("\n");
    //        }
    //        printf("\n");
    //    }
    //    printf("\n");
    //    exit(0);
    //}
}

// lm_ggml_compute_forward_diag

static void lm_ggml_compute_forward_diag_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    if (params->ith != 0) {
        return;
    }

    // TODO: handle transposed/permuted matrices

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    LM_GGML_ASSERT(ne00 == ne0);
    LM_GGML_ASSERT(ne00 == ne1);
    LM_GGML_ASSERT(ne01 == 1);
    LM_GGML_ASSERT(ne02 == ne2);
    LM_GGML_ASSERT(ne03 == ne3);

    LM_GGML_ASSERT(nb00 == sizeof(float));
    LM_GGML_ASSERT(nb0  == sizeof(float));

    for (int i3 = 0; i3 < ne3; i3++) {
        for (int i2 = 0; i2 < ne2; i2++) {
            for (int i1 = 0; i1 < ne1; i1++) {
                float * d = (float *)((char *)  dst->data + i3*nb3  + i2*nb2 + i1*nb1);
                float * s = (float *)((char *) src0->data + i3*nb03 + i2*nb02);
                for (int i0 = 0; i0 < i1; i0++) {
                    d[i0] = 0;
                }
                d[i1] = s[i1];
                for (int i0 = i1+1; i0 < ne0; i0++) {
                    d[i0] = 0;
                }
            }
        }
    }
}

void lm_ggml_compute_forward_diag(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_diag_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_diag_mask_inf

static void lm_ggml_compute_forward_diag_mask_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst,
        const float value) {

    const lm_ggml_tensor * src0 = dst->src[0];

    const int ith = params->ith;
    const int nth = params->nth;

    const int  n_past  = ((int32_t *) dst->op_params)[0];
    const bool inplace = src0->data == dst->data;

    LM_GGML_ASSERT(n_past >= 0);

    if (!inplace) {
        if (ith == 0) {
            // memcpy needs to be synchronized across threads to avoid race conditions.
            // => do it in INIT phase
            LM_GGML_ASSERT(lm_ggml_nelements(dst) == lm_ggml_nelements(src0));
            LM_GGML_ASSERT(lm_ggml_is_contiguous(dst) && lm_ggml_is_contiguous(src0));
            memcpy(
                ((char *)  dst->data),
                ((char *) src0->data),
                lm_ggml_nbytes(dst));
        }
        lm_ggml_barrier(params->threadpool);
    }

    // TODO: handle transposed/permuted matrices

    const int n  = lm_ggml_nrows(src0);
    const int nc = src0->ne[0];
    const int nr = src0->ne[1];
    const int nz = n/nr;

    LM_GGML_ASSERT( dst->nb[0] == sizeof(float));
    LM_GGML_ASSERT(src0->nb[0] == sizeof(float));

    for (int k = 0; k < nz; k++) {
        for (int j = ith; j < nr; j += nth) {
            for (int i = n_past; i < nc; i++) {
                if (i > n_past + j) {
                    *(float *)((char *) dst->data + k*dst->nb[2] + j*dst->nb[1] + i*dst->nb[0]) = value;
                }
            }
        }
    }
}

void lm_ggml_compute_forward_diag_mask_inf(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_diag_mask_f32(params, dst, -INFINITY);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

void lm_ggml_compute_forward_diag_mask_zero(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_diag_mask_f32(params, dst, 0);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_soft_max

static void lm_ggml_compute_forward_soft_max_f32(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];
    const lm_ggml_tensor * src2 = dst->src[2];

    assert(lm_ggml_is_contiguous(dst));
    assert(lm_ggml_are_same_shape(src0, dst));

    float scale    = 1.0f;
    float max_bias = 0.0f;

    memcpy(&scale,    (float *) dst->op_params + 0, sizeof(float));
    memcpy(&max_bias, (float *) dst->op_params + 1, sizeof(float));

    const int ith = params->ith;
    const int nth = params->nth;

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    const int64_t nb11 = src1 ? src1->nb[1] : 1;
    const int64_t nb12 = src1 ? src1->nb[2] : 1;
    const int64_t nb13 = src1 ? src1->nb[3] : 1;

    const int64_t ne12 = src1 ? src1->ne[2] : 1;
    const int64_t ne13 = src1 ? src1->ne[3] : 1;

    // TODO: is this supposed to be ceil instead of floor?
    //       https://huggingface.co/mosaicml/mpt-7b/blob/main/attention.py#L370
    const uint32_t n_head      = ne02;
    const uint32_t n_head_log2 = 1u << (uint32_t) floor(log2(n_head));

    const float m0 = powf(2.0f, -(max_bias       ) / n_head_log2);
    const float m1 = powf(2.0f, -(max_bias / 2.0f) / n_head_log2);

    float * wp = (float *) params->wdata + (ne00 + CACHE_LINE_SIZE_F32) * ith;

    const bool use_f16 = (src1 && src1->type == LM_GGML_TYPE_F16);

    // sinks
    const float * sk = src2 ? (float *)((char *) src2->data) : nullptr;

    for (int64_t i03 = 0; i03 < ne03; i03++) {
        for (int64_t i02 = 0; i02 < ne02; i02++) {
            for (int64_t i01 = ith; i01 < ne01; i01 += nth) {
                const int64_t i11 = i01;
                const int64_t i12 = i02%ne12;
                const int64_t i13 = i03%ne13;

                // ALiBi
                const uint32_t h = i02; // head
                const float slope = (max_bias > 0.0f) ? h < n_head_log2 ? powf(m0, h + 1) : powf(m1, 2*(h - n_head_log2) + 1) : 1.0f;

                float * sp = (float *)((char *) src0->data + i01*nb01 + i02*nb02 + i03*nb03);
                float * dp = (float *)((char *)  dst->data + i01*nb1  + i02*nb2  + i03*nb3);

                // broadcast the mask across rows
                lm_ggml_fp16_t * mp_f16 = src1 ? (lm_ggml_fp16_t *)((char *) src1->data + i11*nb11 + i12*nb12 + i13*nb13) : NULL;
                float       * mp_f32 = src1 ? (float       *)((char *) src1->data + i11*nb11 + i12*nb12 + i13*nb13) : NULL;

                lm_ggml_vec_cpy_f32  (ne00, wp, sp);
                lm_ggml_vec_scale_f32(ne00, wp, scale);
                if (mp_f32) {
                    if (use_f16) {
                        for (int i = 0; i < ne00; ++i) {
                            wp[i] += slope*LM_GGML_CPU_FP16_TO_FP32(mp_f16[i]);
                        }
                    } else {
                        for (int i = 0; i < ne00; ++i) {
                            wp[i] += slope*mp_f32[i];
                        }
                    }
                }

#ifndef NDEBUG
                for (int i = 0; i < ne00; ++i) {
                    //printf("p[%d] = %f\n", i, p[i]);
                    assert(!isnan(wp[i]));
                }
#endif // NDEBUG

                float max = -INFINITY;
                lm_ggml_vec_max_f32(ne00, &max, wp);

                // if we have sinks, make a correction as if they were included in the softmax
                if (sk) {
                    max = MAX(max, sk[i02]);
                }

                lm_ggml_float sum = lm_ggml_vec_soft_max_f32(ne00, dp, wp, max);
                assert(sum > 0.0);

                if (sk) {
                    sum += (lm_ggml_float) expf(sk[i02] - max);
                }

                sum = 1.0/sum;
                lm_ggml_vec_scale_f32(ne00, dp, sum);

#ifndef NDEBUG
                for (int i = 0; i < ne00; ++i) {
                    assert(!isnan(dp[i]));
                    assert(!isinf(dp[i]));
                }
#endif // NDEBUG
            }
        }
    }
}

void lm_ggml_compute_forward_soft_max(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_soft_max_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}


// lm_ggml_compute_forward_soft_max_ext_back

static void lm_ggml_compute_forward_soft_max_ext_back_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(lm_ggml_is_contiguous(src0));
    LM_GGML_ASSERT(lm_ggml_is_contiguous(src1));
    LM_GGML_ASSERT(lm_ggml_is_contiguous(dst));
    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, dst));
    LM_GGML_ASSERT(lm_ggml_are_same_shape(src1, dst));

    float scale    = 1.0f;
    float max_bias = 0.0f;

    memcpy(&scale,    (const float *) dst->op_params + 0, sizeof(float));
    memcpy(&max_bias, (const float *) dst->op_params + 1, sizeof(float));

    LM_GGML_ASSERT(max_bias == 0.0f);

    // TODO: handle transposed/permuted matrices

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc = src0->ne[0];
    const int nr = lm_ggml_nrows(src0);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    for (int i1 = ir0; i1 < ir1; i1++) {
        float *dy = (float *)((char *) src0->data + i1*src0->nb[1]);
        float *y  = (float *)((char *) src1->data + i1*src1->nb[1]);
        float *dx = (float *)((char *) dst->data  + i1*dst->nb[1]);

#ifndef NDEBUG
        for (int i = 0; i < nc; ++i) {
            //printf("p[%d] = %f\n", i, p[i]);
            assert(!isnan(dy[i]));
            assert(!isnan(y[i]));
        }
#endif // NDEBUG
        // Jii = yi - yi*yi
        // Jij = -yi*yj
        // J = diag(y)-y.T*y
        // dx = J * dy
        // dxk = sum_i(Jki * dyi)
        // dxk = sum_i(-yk*yi * dyi) - (-yk*yk)*dyk + (yk - yk*yk)*dyk
        // dxk = sum_i(-yk*yi * dyi) + yk*yk*dyk + yk*dyk - yk*yk*dyk
        // dxk = sum_i(-yk*yi * dyi) + yk*dyk
        // dxk = -yk * sum_i(yi * dyi) + yk*dyk
        // dxk = -yk * dot(y, dy) + yk*dyk
        // dxk = yk * (- dot(y, dy) + dyk)
        // dxk = yk * (dyk - dot(y, dy))
        //
        // post-order:
        // dot_y_dy := dot(y, dy)
        // dx := dy
        // dx := dx - dot_y_dy
        // dx := dx * y

        // linear runtime, no additional memory
        float dot_y_dy = 0;
        lm_ggml_vec_dot_f32  (nc, &dot_y_dy, 0, y, 0, dy, 0, 1);
        lm_ggml_vec_cpy_f32  (nc, dx, dy);
        lm_ggml_vec_acc1_f32 (nc, dx, -dot_y_dy);
        lm_ggml_vec_mul_f32  (nc, dx, dx, y);
        lm_ggml_vec_scale_f32(nc, dx, scale);

#ifndef NDEBUG
        for (int i = 0; i < nc; ++i) {
            assert(!isnan(dx[i]));
            assert(!isinf(dx[i]));
        }
#endif // NDEBUG
    }
}

void lm_ggml_compute_forward_soft_max_ext_back(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_soft_max_ext_back_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_clamp

static void lm_ggml_compute_forward_clamp_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    float min;
    float max;
    memcpy(&min, (float *) dst->op_params + 0, sizeof(float));
    memcpy(&max, (float *) dst->op_params + 1, sizeof(float));

    const int ith = params->ith;
    const int nth = params->nth;

    const int n  = lm_ggml_nrows(src0);
    const int nc = src0->ne[0];

    const size_t nb00 = src0->nb[0];
    const size_t nb01 = src0->nb[1];

    const size_t nb0 = dst->nb[0];
    const size_t nb1 = dst->nb[1];

    LM_GGML_ASSERT( nb0 == sizeof(float));
    LM_GGML_ASSERT(nb00 == sizeof(float));

    for (int j = ith; j < n; j += nth) {
        float * dst_ptr  = (float *) ((char *)  dst->data + j*nb1);
        float * src0_ptr = (float *) ((char *) src0->data + j*nb01);

        for (int i = 0; i < nc; i++) {
            dst_ptr[i] = MAX(MIN(src0_ptr[i], max), min);
        }
    }
}

static void lm_ggml_compute_forward_clamp_f16(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    float min;
    float max;
    memcpy(&min, (float *) dst->op_params + 0, sizeof(float));
    memcpy(&max, (float *) dst->op_params + 1, sizeof(float));

    const int ith = params->ith;
    const int nth = params->nth;

    const int n  = lm_ggml_nrows(src0);
    const int nc = src0->ne[0];

    const size_t nb00 = src0->nb[0];
    const size_t nb01 = src0->nb[1];

    const size_t nb0 = dst->nb[0];
    const size_t nb1 = dst->nb[1];

    LM_GGML_ASSERT( nb0 == sizeof(lm_ggml_fp16_t));
    LM_GGML_ASSERT(nb00 == sizeof(lm_ggml_fp16_t));

    for (int j = ith; j < n; j += nth) {
        lm_ggml_fp16_t * dst_ptr  = (lm_ggml_fp16_t *) ((char *)  dst->data + j*nb1);
        lm_ggml_fp16_t * src0_ptr = (lm_ggml_fp16_t *) ((char *) src0->data + j*nb01);

        for (int i = 0; i < nc; i++) {
            float v = LM_GGML_CPU_FP16_TO_FP32(src0_ptr[i]);
            dst_ptr[i] = LM_GGML_CPU_FP32_TO_FP16(MAX(MIN(v, max), min));
        }
    }
}

void lm_ggml_compute_forward_clamp(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_clamp_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_clamp_f16(params, dst);
            } break;
        case LM_GGML_TYPE_BF16:
        case LM_GGML_TYPE_Q1_0:
        case LM_GGML_TYPE_Q4_0:
        case LM_GGML_TYPE_Q4_1:
        case LM_GGML_TYPE_Q5_0:
        case LM_GGML_TYPE_Q5_1:
        case LM_GGML_TYPE_Q8_0:
        case LM_GGML_TYPE_Q8_1:
        case LM_GGML_TYPE_MXFP4:
        case LM_GGML_TYPE_NVFP4:
        case LM_GGML_TYPE_Q2_K:
        case LM_GGML_TYPE_Q3_K:
        case LM_GGML_TYPE_Q4_K:
        case LM_GGML_TYPE_Q5_K:
        case LM_GGML_TYPE_Q6_K:
        case LM_GGML_TYPE_TQ1_0:
        case LM_GGML_TYPE_TQ2_0:
        case LM_GGML_TYPE_IQ2_XXS:
        case LM_GGML_TYPE_IQ2_XS:
        case LM_GGML_TYPE_IQ3_XXS:
        case LM_GGML_TYPE_IQ1_S:
        case LM_GGML_TYPE_IQ1_M:
        case LM_GGML_TYPE_IQ4_NL:
        case LM_GGML_TYPE_IQ4_XS:
        case LM_GGML_TYPE_IQ3_S:
        case LM_GGML_TYPE_IQ2_S:
        case LM_GGML_TYPE_Q8_K:
        case LM_GGML_TYPE_I8:
        case LM_GGML_TYPE_I16:
        case LM_GGML_TYPE_I32:
        case LM_GGML_TYPE_I64:
        case LM_GGML_TYPE_F64:
        case LM_GGML_TYPE_COUNT:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_rope

static float rope_yarn_ramp(const float low, const float high, const int i0) {
    const float y = (i0 / 2 - low) / MAX(0.001f, high - low);
    return 1 - MIN(1, MAX(0, y));
}

// YaRN algorithm based on LlamaYaRNScaledRotaryEmbedding.py from https://github.com/jquesnelle/yarn
// MIT licensed. Copyright (c) 2023 Jeffrey Quesnelle and Bowen Peng.
static void rope_yarn(
    float theta_extrap, float freq_scale, float corr_dims[2], int64_t i0, float ext_factor, float mscale,
    float * cos_theta, float * sin_theta) {
    // Get n-d rotational scaling corrected for extrapolation
    float theta_interp = freq_scale * theta_extrap;
    float theta = theta_interp;
    if (ext_factor != 0.0f) {
        float ramp_mix = rope_yarn_ramp(corr_dims[0], corr_dims[1], i0) * ext_factor;
        theta = theta_interp * (1 - ramp_mix) + theta_extrap * ramp_mix;

        // Get n-d magnitude scaling corrected for interpolation
        mscale *= 1.0f + 0.1f * logf(1.0f / freq_scale);
    }
    *cos_theta = cosf(theta) * mscale;
    *sin_theta = sinf(theta) * mscale;
}

static void lm_ggml_rope_cache_init(
     float theta_base, float freq_scale, const float * freq_factors, float corr_dims[2], int64_t ne0, float ext_factor, float mscale,
     float * cache, float sin_sign, float theta_scale) {
    // ref: https://github.com/jquesnelle/yarn/blob/master/scaled_rope/LlamaYaRNScaledRotaryEmbedding.py
    float theta = theta_base;
    for (int64_t i0 = 0; i0 < ne0; i0 += 2) {
        const float ff = freq_factors ? freq_factors[i0/2] : 1.0f;
        rope_yarn(
            theta/ff, freq_scale, corr_dims, i0, ext_factor, mscale, &cache[i0 + 0], &cache[i0 + 1]
        );
        cache[i0 + 1] *= sin_sign;

        theta *= theta_scale;
    }
}

static void lm_ggml_mrope_cache_init(
     float theta_base_t, float theta_base_h, float theta_base_w, float theta_base_e, int sections[4], bool is_imrope, bool indep_sects,
     float freq_scale, const float * freq_factors, float corr_dims[2], int64_t ne0, float ext_factor, float mscale,
     float * cache, float sin_sign, float theta_scale) {
    // ref: https://github.com/jquesnelle/yarn/blob/master/scaled_rope/LlamaYaRNScaledRotaryEmbedding.py
    float theta_t = theta_base_t;
    float theta_h = theta_base_h;
    float theta_w = theta_base_w;
    float theta_e = theta_base_e;  // extra position id for vision encoder
    int sect_dims = sections[0] + sections[1] + sections[2] + sections[3];
    int sec_w = sections[1] + sections[0];
    int sec_e = sections[2] + sec_w;
    LM_GGML_ASSERT(sect_dims <= ne0);

    for (int64_t i0 = 0; i0 < ne0; i0 += 2) {
        const float ff = freq_factors ? freq_factors[i0/2] : 1.0f;

        int sector = (i0 / 2) % sect_dims;
        if (indep_sects) {
            // compute theta independently for each dim sections
            // (i.e. reset corresponding theta when `i0` go from one section to another)
            if (sector == 0) {
                theta_t = theta_base_t;
            }
            else if (sector == sections[0]) {
                theta_h = theta_base_h;;
            }
            else if (sector == sec_w) {
                theta_w = theta_base_w;
            }
            else if (sector == sec_e) {
                theta_e = theta_base_e;
            }
        }

        float theta = theta_t;
        if (is_imrope) { // qwen3vl apply interleaved mrope
            if (sector % 3 == 1 && sector < 3 * sections[1]) {
                theta = theta_h;
            } else if (sector % 3 == 2 && sector < 3 * sections[2]) {
                theta = theta_w;
            } else if (sector % 3 == 0 && sector < 3 * sections[0]) {
                theta = theta_t;
            } else {
                theta = theta_e;
            }
        } else {
            if (sector >= sections[0] && sector < sec_w) {
                theta = theta_h;
            }
            else if (sector >= sec_w && sector < sec_w + sections[2]) {
                theta = theta_w;
            }
            else if (sector >= sec_w + sections[2]) {
                theta = theta_e;
            }
        }

        rope_yarn(
            theta/ff, freq_scale, corr_dims, i0, ext_factor, mscale, &cache[i0 + 0], &cache[i0 + 1]
        );
        cache[i0 + 1] *= sin_sign;

        theta_t *= theta_scale;
        theta_w *= theta_scale;
        theta_h *= theta_scale;
        theta_e *= theta_scale;
    }
}


template<typename T>
static void rotate_pairs(const int64_t n, const int64_t n_offset, const float * cache, const T * src_data, T * dst_data, const int scale = 2) {
  for (int64_t i0 = 0; i0 < n; i0 += 2) {
    const int64_t ic = i0/scale; // hack for LM_GGML_ROPE_TYPE_NORMAL, where we need ic = i0; for all other cases, ic = i0/2

    const float cos_theta = cache[i0 + 0];
    const float sin_theta = cache[i0 + 1];

    const T * const src = src_data + ic;
    T * dst             = dst_data + ic;

    const float x0 = type_conversion_table<T>::to_f32(src[0]);
    const float x1 = type_conversion_table<T>::to_f32(src[n_offset]);

    dst[0]        = type_conversion_table<T>::from_f32(x0*cos_theta - x1*sin_theta);
    dst[n_offset] = type_conversion_table<T>::from_f32(x0*sin_theta + x1*cos_theta);
  }
}

template<typename T> //float or lm_ggml_fp16_t
static void lm_ggml_compute_forward_rope_flt(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst,
        const bool forward) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];
    const lm_ggml_tensor * src2 = dst->src[2];

    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_F32 || src0->type == LM_GGML_TYPE_F16);
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_I32);

    float freq_base, freq_scale, ext_factor, attn_factor, beta_fast, beta_slow;
    int sections[4];

    //const int n_past     = ((int32_t *) dst->op_params)[0];
    const int n_dims     = ((int32_t *) dst->op_params)[1];
    const int mode       = ((int32_t *) dst->op_params)[2];
    //const int n_ctx      = ((int32_t *) dst->op_params)[3];
    const int n_ctx_orig = ((int32_t *) dst->op_params)[4];

    memcpy(&freq_base,   (int32_t *) dst->op_params +  5, sizeof(float));
    memcpy(&freq_scale,  (int32_t *) dst->op_params +  6, sizeof(float));
    memcpy(&ext_factor,  (int32_t *) dst->op_params +  7, sizeof(float));
    memcpy(&attn_factor, (int32_t *) dst->op_params +  8, sizeof(float));
    memcpy(&beta_fast,   (int32_t *) dst->op_params +  9, sizeof(float));
    memcpy(&beta_slow,   (int32_t *) dst->op_params + 10, sizeof(float));
    memcpy(&sections,    (int32_t *) dst->op_params + 11, sizeof(int)*4);

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    //printf("ne0: %d, ne1: %d, ne2: %d, ne3: %d\n", ne0, ne1, ne2, ne3);
    //printf("n_past = %d, ne2 = %d\n", n_past, ne2);

    LM_GGML_ASSERT(nb0 == nb00);
    LM_GGML_ASSERT(nb0 == sizeof(T));

    const int ith = params->ith;
    const int nth = params->nth;

    const int nr = lm_ggml_nrows(dst);

    LM_GGML_ASSERT(n_dims <= ne0);
    LM_GGML_ASSERT(n_dims % 2 == 0);

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    // row index used to determine which thread to use
    int ir = 0;

    const float theta_scale = powf(freq_base, -2.0f/n_dims);

    float corr_dims[2];
    lm_ggml_rope_yarn_corr_dims(n_dims, n_ctx_orig, freq_base, beta_fast, beta_slow, corr_dims);

    const bool is_imrope = mode == LM_GGML_ROPE_TYPE_IMROPE; // qwen3vl apply interleaved mrope
    const bool mrope_used = mode & LM_GGML_ROPE_TYPE_MROPE;  // lm_ggml_rope_multi, note: also true for vision (24 & 8 == true) and for imrope
    const bool is_vision = mode == LM_GGML_ROPE_TYPE_VISION;

    if (mrope_used) {
        LM_GGML_ASSERT(sections[0] > 0 || sections[1] > 0 || sections[2] > 0);
    }

    if (is_vision) {
        LM_GGML_ASSERT(n_dims == ne0/2);
    }

    const float * freq_factors = NULL;
    if (src2 != NULL) {
        LM_GGML_ASSERT(src2->type == LM_GGML_TYPE_F32);
        LM_GGML_ASSERT(src2->ne[0] >= n_dims / 2);
        freq_factors = (const float *) src2->data;
    }

    // backward process uses inverse rotation by cos and sin.
    // cos and sin build a rotation matrix, where the inverse is the transpose.
    // this essentially just switches the sign of sin.
    const float sin_sign = forward ? 1.0f : -1.0f;

    const int32_t * pos = (const int32_t *) src1->data;

    int64_t last_i2 = -1;

    for (int64_t i3 = 0; i3 < ne3; i3++) { // batch
        for (int64_t i2 = 0; i2 < ne2; i2++) { // seq-len
            for (int64_t i1 = 0; i1 < ne1; i1++) { // attn-heads
                if (ir++ < ir0) continue; // skip rows mapped to other threads
                if (ir   > ir1) break;

                float * cache = (float *) params->wdata + (ne0 + CACHE_LINE_SIZE_F32)*ith;
                if (last_i2 != i2) {
                    if (!mrope_used) {
                        const int64_t p = pos[i2];
                        lm_ggml_rope_cache_init(p, freq_scale, freq_factors, corr_dims, ne0, ext_factor, attn_factor, cache, sin_sign, theta_scale);
                    }
                    else {
                        const int64_t p_t = pos[i2];
                        const int64_t p_h = pos[i2 + ne2];
                        const int64_t p_w = pos[i2 + ne2 * 2];
                        const int64_t p_e = pos[i2 + ne2 * 3];
                        lm_ggml_mrope_cache_init(
                            p_t, p_h, p_w, p_e, sections, is_imrope, is_vision,
                            freq_scale, freq_factors, corr_dims, ne0, ext_factor, attn_factor, cache, sin_sign, theta_scale);
                    }

                    last_i2 = i2;
                }

                T * src = (T *)((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01);
                T * dst_data  = (T *)((char *)  dst->data + i3*nb3  + i2*nb2  + i1*nb1);

                switch (mode) {
                    case LM_GGML_ROPE_TYPE_NORMAL:
                        rotate_pairs<T>(n_dims, 1, cache, src, dst_data, 1);
                        break;
                    case LM_GGML_ROPE_TYPE_NEOX:
                    case LM_GGML_ROPE_TYPE_MROPE:
                    case LM_GGML_ROPE_TYPE_IMROPE:
                        rotate_pairs<T>(n_dims, n_dims/2, cache, src, dst_data);
                        break;
                    case LM_GGML_ROPE_TYPE_VISION:
                        rotate_pairs<T>(ne0, n_dims, cache, src, dst_data);
                        break;
                    default:
                        LM_GGML_ABORT("rope type not supported");
                }

                if (!is_vision) {
                    // fill the remain channels with data from src tensor
                    for (int64_t i0 = n_dims; i0 < ne0; i0 += 2) {
                        const T * const src = (T *)((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01 + i0*nb00);
                        T * dst_data  = (T *)((char *)  dst->data + i3*nb3  + i2*nb2  + i1*nb1  + i0*nb0);

                        dst_data[0] = src[0];
                        dst_data[1] = src[1];
                    }
                }
            } //attn-heads
        }
    }
}

void lm_ggml_compute_forward_rope(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_rope_flt<lm_ggml_fp16_t>(params, dst, true);
            } break;
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_rope_flt<float>(params, dst, true);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_rope_back

void lm_ggml_compute_forward_rope_back(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_rope_flt<lm_ggml_fp16_t>(params, dst, false);
            } break;
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_rope_flt<float>(params, dst, false);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_conv_transpose_1d

static void lm_ggml_compute_forward_conv_transpose_1d_f16_f32(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_F16);
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT( dst->type == LM_GGML_TYPE_F32);

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    const int ith = params->ith;
    const int nth = params->nth;

    const int nk = ne00*ne01*ne02;

    LM_GGML_ASSERT(nb00 == sizeof(lm_ggml_fp16_t));
    LM_GGML_ASSERT(nb10 == sizeof(float));

    if (ith == 0) {
        memset(params->wdata, 0, params->wsize);

        // permute kernel data (src0) from (K x Cout x Cin) to (Cin x K x Cout)
        {
            lm_ggml_fp16_t * const wdata = (lm_ggml_fp16_t *) params->wdata + 0;

            for (int64_t i02 = 0; i02 < ne02; i02++) {
                for (int64_t i01 = 0; i01 < ne01; i01++) {
                    const lm_ggml_fp16_t * const src = (lm_ggml_fp16_t *)((char *) src0->data + i02*nb02 + i01*nb01);
                    lm_ggml_fp16_t * dst_data = wdata + i01*ne00*ne02;
                    for (int64_t i00 = 0; i00 < ne00; i00++) {
                        dst_data[i00*ne02 + i02] = src[i00];
                    }
                }
            }
        }

        // permute source data (src1) from (L x Cin) to (Cin x L)
        {
            lm_ggml_fp16_t * const wdata = (lm_ggml_fp16_t *) params->wdata + nk;
            lm_ggml_fp16_t * dst_data = wdata;

            for (int64_t i11 = 0; i11 < ne11; i11++) {
                const float * const src = (float *)((char *) src1->data + i11*nb11);
                for (int64_t i10 = 0; i10 < ne10; i10++) {
                    dst_data[i10*ne11 + i11] = LM_GGML_CPU_FP32_TO_FP16(src[i10]);
                }
            }
        }

        // need to zero dst since we are accumulating into it
        memset(dst->data, 0, lm_ggml_nbytes(dst));
    }
    lm_ggml_barrier(params->threadpool);

    const int32_t s0 = ((const int32_t*)(dst->op_params))[0];

    // total rows in dst
    const int nr = ne1;

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    lm_ggml_fp16_t * const wdata     = (lm_ggml_fp16_t *) params->wdata + 0;
    lm_ggml_fp16_t * const wdata_src = wdata + nk;

    for (int i1 = ir0; i1 < ir1; i1++) {
        float * dst_data = (float *)((char *) dst->data + i1*nb1);
        lm_ggml_fp16_t * wdata_kernel = wdata + i1*ne02*ne00;
        for (int i10 = 0; i10 < ne10; i10++) {
            const int i1n = i10*ne11;
            for (int i00 = 0; i00 < ne00; i00++) {
                float v = 0;
                lm_ggml_vec_dot_f16(ne02, &v, 0,
                        (lm_ggml_fp16_t *)    wdata_src + i1n, 0,
                        (lm_ggml_fp16_t *) wdata_kernel + i00*ne02, 0, 1);
                dst_data[i10*s0 + i00] += v;
            }
        }
    }
}

static void lm_ggml_compute_forward_conv_transpose_1d_f32(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT( dst->type == LM_GGML_TYPE_F32);

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    const int ith = params->ith;
    const int nth = params->nth;

    const int nk = ne00*ne01*ne02;

    LM_GGML_ASSERT(nb00 == sizeof(float));
    LM_GGML_ASSERT(nb10 == sizeof(float));

    if (ith == 0) {
        memset(params->wdata, 0, params->wsize);

        // prepare kernel data (src0) from (K x Cout x Cin) to (Cin x K x Cout)
        {
            float * const wdata = (float *) params->wdata + 0;

            for (int64_t i02 = 0; i02 < ne02; i02++) {
                for (int64_t i01 = 0; i01 < ne01; i01++) {
                    const float * const src = (float *)((char *) src0->data + i02*nb02 + i01*nb01);
                    float * dst_data = wdata + i01*ne00*ne02;
                    for (int64_t i00 = 0; i00 < ne00; i00++) {
                        dst_data[i00*ne02 + i02] = src[i00];
                    }
                }
            }
        }

        // prepare source data (src1)
        {
            float * const wdata = (float *) params->wdata + nk;
            float * dst_data = wdata;

            for (int64_t i11 = 0; i11 < ne11; i11++) {
                const float * const src = (float *)((char *) src1->data + i11*nb11);
                for (int64_t i10 = 0; i10 < ne10; i10++) {
                    dst_data[i10*ne11 + i11] = src[i10];
                }
            }
        }

        // need to zero dst since we are accumulating into it
        memset(dst->data, 0, lm_ggml_nbytes(dst));
    }
    lm_ggml_barrier(params->threadpool);

    const int32_t s0 = ((const int32_t*)(dst->op_params))[0];

    // total rows in dst
    const int nr = ne1;

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    float * const wdata     = (float *) params->wdata + 0;
    float * const wdata_src = wdata + nk;

    for (int i1 = ir0; i1 < ir1; i1++) {
        float * dst_data = (float *)((char *) dst->data + i1*nb1);
        float * wdata_kernel = wdata + i1*ne02*ne00;
        for (int i10 = 0; i10 < ne10; i10++) {
            const int i1n = i10*ne11;
            for (int i00 = 0; i00 < ne00; i00++) {
                float v = 0;
                lm_ggml_vec_dot_f32(ne02, &v, 0,
                        wdata_src + i1n, 0,
                        wdata_kernel + i00*ne02, 0, 1);
                dst_data[i10*s0 + i00] += v;
            }
        }
    }
}

void lm_ggml_compute_forward_conv_transpose_1d(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_conv_transpose_1d_f16_f32(params, dst);
            } break;
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_conv_transpose_1d_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_im2col_f32
// src0: kernel [OC, IC, KH, KW]
// src1: image [N, IC, IH, IW]
// dst:  result [N, OH, OW, IC*KH*KW]
static void lm_ggml_compute_forward_im2col_f32(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT( dst->type == LM_GGML_TYPE_F32);

    LM_GGML_TENSOR_BINARY_OP_LOCALS;

    const int32_t s0 = ((const int32_t *)(dst->op_params))[0];
    const int32_t s1 = ((const int32_t *)(dst->op_params))[1];
    const int32_t p0 = ((const int32_t *)(dst->op_params))[2];
    const int32_t p1 = ((const int32_t *)(dst->op_params))[3];
    const int32_t d0 = ((const int32_t *)(dst->op_params))[4];
    const int32_t d1 = ((const int32_t *)(dst->op_params))[5];
    const bool is_2D = ((const int32_t *)(dst->op_params))[6] == 1;

    const int ith = params->ith;
    const int nth = params->nth;

    const int64_t N  = is_2D ? ne13 : ne12;
    const int64_t IC = is_2D ? ne12 : ne11;
    const int64_t IH = is_2D ? ne11 : 1;
    const int64_t IW = ne10;

    const int64_t KH = is_2D ? ne01 : 1;
    const int64_t KW = ne00;

    const int64_t OH = is_2D ? ne2 : 1;
    const int64_t OW = ne1;

    int ofs0 = is_2D ? nb13 : nb12;
    int ofs1 = is_2D ? nb12 : nb11;

    LM_GGML_ASSERT(nb10 == sizeof(float));

    // im2col: [N, IC, IH, IW] => [N, OH, OW, IC*KH*KW]
    {
        float * const wdata = (float *) dst->data;

        for (int64_t in = 0; in < N; in++) {
            for (int64_t ioh = 0; ioh < OH; ioh++) { // 1
                for (int64_t iow = 0; iow < OW; iow++) {
                    for (int64_t iic = ith; iic < IC; iic += nth) {

                        // micro kernel
                        float * dst_data = wdata + (in*OH*OW + ioh*OW + iow)*(IC*KH*KW); // [IC, KH, KW]
                        const float * const src_data = (float *)((char *) src1->data + in*ofs0 + iic*ofs1); // [IH, IW]

                        for (int64_t ikh = 0; ikh < KH; ikh++) {  // 1
                            for (int64_t ikw = 0; ikw < KW; ikw++) {
                                const int64_t iiw = iow*s0 + ikw*d0 - p0;
                                const int64_t iih = ioh*s1 + ikh*d1 - p1;

                                if (iih < 0 || iih >= IH || iiw < 0 || iiw >= IW) {
                                    dst_data[iic*(KH*KW) + ikh*KW + ikw] = 0;
                                } else {
                                    dst_data[iic*(KH*KW) + ikh*KW + ikw] = (src_data[iih*IW + iiw]);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


// lm_ggml_compute_forward_im2col_f16
// src0: kernel [OC, IC, KH, KW]
// src1: image [N, IC, IH, IW]
// dst:  result [N, OH, OW, IC*KH*KW]
static void lm_ggml_compute_forward_im2col_f16(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_F16);
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F16 || src1->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT( dst->type == LM_GGML_TYPE_F16);

    LM_GGML_TENSOR_BINARY_OP_LOCALS;

    const int32_t s0 = ((const int32_t *)(dst->op_params))[0];
    const int32_t s1 = ((const int32_t *)(dst->op_params))[1];
    const int32_t p0 = ((const int32_t *)(dst->op_params))[2];
    const int32_t p1 = ((const int32_t *)(dst->op_params))[3];
    const int32_t d0 = ((const int32_t *)(dst->op_params))[4];
    const int32_t d1 = ((const int32_t *)(dst->op_params))[5];
    const bool is_2D = ((const int32_t *)(dst->op_params))[6] == 1;

    const int ith = params->ith;
    const int nth = params->nth;

    const int64_t N  = is_2D ? ne13 : ne12;
    const int64_t IC = is_2D ? ne12 : ne11;
    const int64_t IH = is_2D ? ne11 : 1;
    const int64_t IW = ne10;

    const int64_t KH = is_2D ? ne01 : 1;
    const int64_t KW = ne00;

    const int64_t OH = is_2D ? ne2 : 1;
    const int64_t OW = ne1;

    int ofs0 = is_2D ? nb13 : nb12;
    int ofs1 = is_2D ? nb12 : nb11;

    LM_GGML_ASSERT(nb00 == sizeof(lm_ggml_fp16_t));
    LM_GGML_ASSERT(nb10 == lm_ggml_type_size(src1->type));

    // im2col: [N, IC, IH, IW] => [N, OH, OW, IC*KH*KW]
    {
        lm_ggml_fp16_t * const wdata = (lm_ggml_fp16_t *) dst->data;

        for (int64_t in = 0; in < N; in++) {
            for (int64_t ioh = 0; ioh < OH; ioh++) { // 1
                for (int64_t iow = 0; iow < OW; iow++) {
                    for (int64_t iic = ith; iic < IC; iic += nth) {

                        // micro kernel
                        lm_ggml_fp16_t * dst_data = wdata + (in*OH*OW + ioh*OW + iow)*(IC*KH*KW); // [IC, KH, KW]
                        const float * const src_data_f32 = src1->type == LM_GGML_TYPE_F32
                            ? (const float *)((const char *) src1->data + in*ofs0 + iic*ofs1)
                            : nullptr; // [IH, IW]
                        const lm_ggml_fp16_t * const src_data_f16 = src1->type == LM_GGML_TYPE_F16
                            ? (const lm_ggml_fp16_t *)((const char *) src1->data + in*ofs0 + iic*ofs1)
                            : nullptr; // [IH, IW]

                        for (int64_t ikh = 0; ikh < KH; ikh++) {  // 1
                            for (int64_t ikw = 0; ikw < KW; ikw++) {
                                const int64_t iiw = iow*s0 + ikw*d0 - p0;
                                const int64_t iih = ioh*s1 + ikh*d1 - p1;

                                if (iih < 0 || iih >= IH || iiw < 0 || iiw >= IW) {
                                    dst_data[iic*(KH*KW) + ikh*KW + ikw] = 0;
                                } else {
                                    if (src_data_f32 != nullptr) {
                                        dst_data[iic*(KH*KW) + ikh*KW + ikw] = LM_GGML_CPU_FP32_TO_FP16(src_data_f32[iih*IW + iiw]);
                                    } else {
                                        dst_data[iic*(KH*KW) + ikh*KW + ikw] = src_data_f16[iih*IW + iiw];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

void lm_ggml_compute_forward_im2col(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {
    switch (dst->type) {
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_im2col_f16(params, dst);
            } break;
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_im2col_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_im2col_back_f32

void lm_ggml_compute_forward_im2col_back_f32(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0]; // gradients of forward pass output
    const lm_ggml_tensor * src1 = dst->src[1]; // convolution kernel

    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT( dst->type == LM_GGML_TYPE_F32);

    LM_GGML_TENSOR_BINARY_OP_LOCALS;

    const int32_t s0 = ((const int32_t *)(dst->op_params))[0];
    const int32_t s1 = ((const int32_t *)(dst->op_params))[1];
    const int32_t p0 = ((const int32_t *)(dst->op_params))[2];
    const int32_t p1 = ((const int32_t *)(dst->op_params))[3];
    const int32_t d0 = ((const int32_t *)(dst->op_params))[4];
    const int32_t d1 = ((const int32_t *)(dst->op_params))[5];
    const bool is_2D = ((const int32_t *)(dst->op_params))[6] == 1;

    const int ith = params->ith;
    const int nth = params->nth;

    const int64_t N  = is_2D ? ne3 : ne2;
    const int64_t IC = is_2D ? ne2 : ne1;
    const int64_t IH = is_2D ? ne1 : 1;
    const int64_t IW = ne0;

    const int64_t KH = is_2D ? ne11 : 1;
    const int64_t KW = ne10;

    const int64_t OH = is_2D ? ne02 : 1;
    const int64_t OW = ne01;

    int ofs0 = is_2D ? nb3 : nb2;
    int ofs1 = is_2D ? nb2 : nb1;

    LM_GGML_ASSERT(nb0  == sizeof(float));

    // im2col: [N, IC, IH, IW] => [N, OH, OW, IC*KH*KW]
    {
        float * const wdata = (float *) dst->data;

        for (int64_t in = 0; in < N; in++) {
            for (int64_t iic = ith; iic < IC; iic += nth) {
                for (int64_t iih = 0; iih < IH; iih++) {
                    for (int64_t iiw = 0; iiw < IW; iiw++) {

                        // micro kernel
                        float grad = 0.0f;
                        for (int64_t ikh = 0; ikh < KH; ikh++) {
                            for (int64_t ikw = 0; ikw < KW; ikw++) {
                                // For s0 > 1 some values were skipped over in the forward pass.
                                // These values have tmpw % s0 != 0 and need to be skipped in the backwards pass as well.
                                const int64_t tmpw = (iiw + p0 - ikw*d0);
                                if (tmpw % s0 != 0) {
                                    continue;
                                }
                                const int64_t iow = tmpw / s0;

                                // Equivalent logic as above except for s1.
                                int64_t ioh;
                                if (is_2D) {
                                    const int64_t tmph = iih + p1 - ikh*d1;

                                    if (tmph % s1 != 0) {
                                        continue;
                                    }

                                    ioh = tmph / s1;
                                } else {
                                    ioh = 0;
                                }

                                if (iow < 0 || iow >= OW || ioh < 0 || ioh >= OH) {
                                    continue;
                                }

                                const float * const grad_in = (const float *) src0->data
                                    + (in*OH*OW + ioh*OW + iow)*(IC*KH*KW); // [IC, KH, KW]
                                grad += grad_in[iic*(KH*KW) + ikh*KW + ikw];
                            }
                        }
                        float * dst_data = (float *)((char *) wdata + (in*ofs0 + iic*ofs1)); // [IH, IW]
                        dst_data[iih*IW + iiw] = grad;
                    }
                }
            }
        }
    }
}


// lm_ggml_compute_forward_im2col_3d_f16
// src0: kernel [OC*IC, KD, KH, KW]
// src1: image [N*IC, ID, IH, IW]
// dst:  result [N*OD, OH, OW, IC * KD * KH * KW]
static void lm_ggml_compute_forward_im2col_3d_f16(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_F16);
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT( dst->type == LM_GGML_TYPE_F16);

    LM_GGML_TENSOR_BINARY_OP_LOCALS;

    const int32_t s0 = ((const int32_t *)(dst->op_params))[0];
    const int32_t s1 = ((const int32_t *)(dst->op_params))[1];
    const int32_t s2 = ((const int32_t *)(dst->op_params))[2];
    const int32_t p0 = ((const int32_t *)(dst->op_params))[3];
    const int32_t p1 = ((const int32_t *)(dst->op_params))[4];
    const int32_t p2 = ((const int32_t *)(dst->op_params))[5];
    const int32_t d0 = ((const int32_t *)(dst->op_params))[6];
    const int32_t d1 = ((const int32_t *)(dst->op_params))[7];
    const int32_t d2 = ((const int32_t *)(dst->op_params))[8];
    const int32_t IC = ((const int32_t *)(dst->op_params))[9];


    const int ith = params->ith;
    const int nth = params->nth;

    const int64_t N  = ne13 / IC;
    const int64_t ID = ne12;
    const int64_t IH = ne11;
    const int64_t IW = ne10;

    const int64_t OC = ne03 / IC;
    LM_GGML_UNUSED(OC);
    const int64_t KD = ne02;
    const int64_t KH = ne01;
    const int64_t KW = ne00;

    const int64_t OD = ne3 / N;
    const int64_t OH = ne2;
    const int64_t OW = ne1;
    const int64_t OH_OW = OH*OW;
    const int64_t KD_KH_KW = KD*KH*KW;
    const int64_t KH_KW = KH*KW;
    const int64_t IC_KD_KH_KW = IC*KD*KH*KW;

    LM_GGML_ASSERT(nb10 == sizeof(float));

    // im2col: [N*IC, ID, IH, IW] => [N*OD, OH, OW, IC * KD * KH * KW]
    {
        lm_ggml_fp16_t * const wdata = (lm_ggml_fp16_t *) dst->data;

        for (int64_t in = 0; in < N; in++) {
            for (int64_t iod = 0; iod < OD; iod++) {
                for (int64_t ioh = 0; ioh < OH; ioh++) {
                    for (int64_t iow = 0; iow < OW; iow++) {
                        for (int64_t iic = ith; iic < IC; iic += nth) {

                            // micro kernel
                            lm_ggml_fp16_t * dst_data = wdata + (in*OD*OH_OW + iod*OH_OW + ioh*OW + iow)*IC_KD_KH_KW; // [IC, KD, KH, KW]
                            const float * const src_data = (const float *) ((const char *)src1->data + (in*IC + iic)*nb13); // [ID, IH, IW]

                            for (int64_t ikd = 0; ikd < KD; ikd++) {
                                for (int64_t ikh = 0; ikh < KH; ikh++) {
                                    for (int64_t ikw = 0; ikw < KW; ikw++) {
                                        const int64_t iiw = iow*s0 + ikw*d0 - p0;
                                        const int64_t iih = ioh*s1 + ikh*d1 - p1;
                                        const int64_t iid = iod*s2 + ikd*d2 - p2;

                                        if (iid < 0 || iid >= ID || iih < 0 || iih >= IH || iiw < 0 || iiw >= IW) {
                                            dst_data[iic*KD_KH_KW + ikd * KH_KW + ikh*KW + ikw] = 0;
                                        } else {
                                            const float * const s = (const float *) ((const char *)src_data + iid*nb12 + iih*nb11 + iiw*nb10); // [ID, IH, IW]
                                            dst_data[iic*KD_KH_KW + ikd * KH_KW + ikh*KW + ikw] = LM_GGML_CPU_FP32_TO_FP16(*s);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// lm_ggml_compute_forward_im2col_3d_f32
// src0: kernel [OC*IC, KD, KH, KW]
// src1: image [N*IC, ID, IH, IW]
// dst:  result [N*OD, OH, OW, IC * KD * KH * KW]
static void lm_ggml_compute_forward_im2col_3d_f32(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT( dst->type == LM_GGML_TYPE_F32);

    LM_GGML_TENSOR_BINARY_OP_LOCALS;

    const int32_t s0 = ((const int32_t *)(dst->op_params))[0];
    const int32_t s1 = ((const int32_t *)(dst->op_params))[1];
    const int32_t s2 = ((const int32_t *)(dst->op_params))[2];
    const int32_t p0 = ((const int32_t *)(dst->op_params))[3];
    const int32_t p1 = ((const int32_t *)(dst->op_params))[4];
    const int32_t p2 = ((const int32_t *)(dst->op_params))[5];
    const int32_t d0 = ((const int32_t *)(dst->op_params))[6];
    const int32_t d1 = ((const int32_t *)(dst->op_params))[7];
    const int32_t d2 = ((const int32_t *)(dst->op_params))[8];
    const int32_t IC = ((const int32_t *)(dst->op_params))[9];


    const int ith = params->ith;
    const int nth = params->nth;

    const int64_t N  = ne13 / IC;
    const int64_t ID = ne12;
    const int64_t IH = ne11;
    const int64_t IW = ne10;

    const int64_t OC = ne03 / IC;
    LM_GGML_UNUSED(OC);
    const int64_t KD = ne02;
    const int64_t KH = ne01;
    const int64_t KW = ne00;

    const int64_t OD = ne3 / N;
    const int64_t OH = ne2;
    const int64_t OW = ne1;

    const int64_t OH_OW = OH*OW;
    const int64_t KD_KH_KW = KD*KH*KW;
    const int64_t KH_KW = KH*KW;
    const int64_t IC_KD_KH_KW = IC*KD*KH*KW;

    LM_GGML_ASSERT(nb10 == sizeof(float));

    // im2col: [N*IC, ID, IH, IW] => [N*OD, OH, OW, IC * KD * KH * KW]
    {
        float * const wdata = (float *) dst->data;

        for (int64_t in = 0; in < N; in++) {
            for (int64_t iod = 0; iod < OD; iod++) {
                for (int64_t ioh = 0; ioh < OH; ioh++) {
                    for (int64_t iow = 0; iow < OW; iow++) {
                        for (int64_t iic = ith; iic < IC; iic += nth) {

                            // micro kernel
                            float * dst_data = wdata + (in*OD*OH_OW + iod*OH_OW + ioh*OW + iow)*IC_KD_KH_KW; // [IC, KD, KH, KW]
                            const float * const src_data = (const float *) ((const char *)src1->data + (in*IC + iic)*nb13); // [ID, IH, IW]

                            for (int64_t ikd = 0; ikd < KD; ikd++) {
                                for (int64_t ikh = 0; ikh < KH; ikh++) {
                                    for (int64_t ikw = 0; ikw < KW; ikw++) {
                                        const int64_t iiw = iow*s0 + ikw*d0 - p0;
                                        const int64_t iih = ioh*s1 + ikh*d1 - p1;
                                        const int64_t iid = iod*s2 + ikd*d2 - p2;

                                        if (iid < 0 || iid >= ID || iih < 0 || iih >= IH || iiw < 0 || iiw >= IW || iid < 0 || iid >= ID) {
                                            dst_data[iic*KD_KH_KW + ikd * KH_KW + ikh*KW + ikw] = 0;
                                        } else {
                                            const float * const s = (const float *) ((const char *)src_data + iid*nb12 + iih*nb11 + iiw*nb10); // [ID, IH, IW]
                                            dst_data[iic*KD_KH_KW + ikd * KH_KW + ikh*KW + ikw] = *s;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


void lm_ggml_compute_forward_im2col_3d(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {
    switch (dst->type) {
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_im2col_3d_f16(params, dst);
            } break;
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_im2col_3d_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

static void lm_ggml_call_mul_mat(lm_ggml_type type, const lm_ggml_compute_params * params, int64_t m, int64_t n, int64_t k,
                              void * a, void * b, float * c) {
    const lm_ggml_type_traits * traits = lm_ggml_get_type_traits(type);
    struct lm_ggml_tensor src1 = {};
    src1.type  = type;
    src1.ne[0] = k;
    src1.ne[1] = m;
    src1.ne[2] = 1;
    src1.ne[3] = 1;
    src1.nb[0] = traits->type_size;
    src1.nb[1] = k * traits->type_size;
    src1.nb[2] = src1.nb[1];
    src1.nb[3] = src1.nb[2];
    src1.data  = a;

    struct lm_ggml_tensor src0 = {};
    src0.type  = type;
    src0.ne[0] = k;
    src0.ne[1] = n;
    src0.ne[2] = 1;
    src0.ne[3] = 1;
    src0.nb[0] = traits->type_size;
    src0.nb[1] = k * traits->type_size;
    src0.nb[2] = src0.nb[1];
    src0.nb[3] = src0.nb[2];
    src0.data  = b;

    struct lm_ggml_tensor dst = {};
    dst.ne[0] = n;
    dst.ne[1] = m;
    dst.ne[2] = 1;
    dst.ne[3] = 1;
    dst.nb[0] = sizeof(float);
    dst.nb[1] = n * sizeof(float);
    dst.nb[2] = dst.nb[1];
    dst.nb[3] = dst.nb[2];
    dst.data  = c;
    dst.src[0] = &src0;
    dst.src[1] = &src1;

    lm_ggml_compute_forward_mul_mat(params, &dst);
}

static inline int64_t lm_ggml_wrap_around(int64_t coord, int64_t size) {
    return (coord  + size) % size; // adding size avoids negative number weirdness
}

// lm_ggml_compute_forward_col2im_1d
//
// Scatter-add columns [K*OC, T_in] -> signal [T_out, OC]
// where T_out = (T_in - 1)*s + K - 2*p.  Gather approach: each output reads ceil(K/s) inputs.
// Parallelized over the time axis so the split stays balanced whatever OC is.
// Supports F32, F16, BF16 input/output (same type), F32 accumulator.

template <typename elem_t>
static void lm_ggml_compute_forward_col2im_1d_impl(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src = dst->src[0];  // [K*OC, T_in]

    LM_GGML_ASSERT(lm_ggml_is_contiguous(src));
    LM_GGML_ASSERT(lm_ggml_is_contiguous(dst));

    const int32_t s0 = ((const int32_t *)(dst->op_params))[0];
    const int32_t OC = ((const int32_t *)(dst->op_params))[1];
    const int32_t p0 = ((const int32_t *)(dst->op_params))[2];

    const int64_t K_OC = src->ne[0];
    const int64_t T_in = src->ne[1];
    const int64_t K    = K_OC / OC;
    const int64_t T_out = dst->ne[0];

    const elem_t * col_data = (const elem_t *) src->data;
    elem_t       * dst_data = (elem_t *) dst->data;

    const int ith = params->ith;
    const int nth = params->nth;

    // Parallelize over the time axis: the split stays balanced whatever OC is,
    // down to OC = 1 for mono audio, and threads read disjoint column bands
    const int64_t dr = (T_out + nth - 1) / nth;
    const int64_t it0 = dr * ith;
    const int64_t it1 = it0 + dr < T_out ? it0 + dr : T_out;

    for (int64_t oc = 0; oc < OC; oc++) {
        for (int64_t t_out = it0; t_out < it1; t_out++) {
            const int64_t t_abs = t_out + p0;  // absolute position in uncropped signal
            // Gather: find all (t_in, k) where t_in * s + k == t_abs, 0 <= k < K
            int64_t t_in_min = (t_abs - K + 1 + s0 - 1) / s0;  // ceil((t_abs-K+1)/s)
            if (t_in_min < 0) t_in_min = 0;
            int64_t t_in_max = t_abs / s0;
            if (t_in_max >= T_in) t_in_max = T_in - 1;

            float sum = 0.0f;
            for (int64_t t_in = t_in_min; t_in <= t_in_max; t_in++) {
                int64_t k = t_abs - t_in * s0;
                if (k >= 0 && k < K) {
                    // col layout: [K*OC, T_in], element (oc*K+k, t_in)
                    sum += type_conversion_table<elem_t>::to_f32(col_data[(oc * K + k) + t_in * K_OC]);
                }
            }
            // dst layout: [T_out, OC], element (t_out, oc)
            dst_data[t_out + oc * T_out] = type_conversion_table<elem_t>::from_f32(sum);
        }
    }
}

void lm_ggml_compute_forward_col2im_1d(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {
    switch (dst->src[0]->type) {
        case LM_GGML_TYPE_F32:  lm_ggml_compute_forward_col2im_1d_impl<float>      (params, dst); break;
        case LM_GGML_TYPE_F16:  lm_ggml_compute_forward_col2im_1d_impl<lm_ggml_fp16_t>(params, dst); break;
        case LM_GGML_TYPE_BF16: lm_ggml_compute_forward_col2im_1d_impl<lm_ggml_bf16_t>(params, dst); break;
        default: LM_GGML_ABORT("col2im_1d: unsupported type %d", dst->src[0]->type);
    }
}

// lm_ggml_compute_forward_conv_2d


static void lm_ggml_compute_forward_conv_2d_impl(const lm_ggml_compute_params * params,
                                              const lm_ggml_tensor *         kernel,  // [KW, KH, IC, OC]
                                              const lm_ggml_tensor *         src,     // [W, H, C, N]
                                              lm_ggml_tensor *               dst,     // [OW, OH, OC, N]
                                              lm_ggml_type                   kernel_type) {

    LM_GGML_ASSERT(lm_ggml_is_contiguous(kernel));
    LM_GGML_ASSERT(kernel_type == LM_GGML_TYPE_F16 || kernel_type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT(kernel->type == kernel_type);

    const lm_ggml_type_traits * traits = lm_ggml_get_type_traits(kernel_type);

    const int32_t stride_x   = dst->op_params[0];
    const int32_t stride_y   = dst->op_params[1];
    const int32_t pad_x      = dst->op_params[2];
    const int32_t pad_y      = dst->op_params[3];
    const int32_t dilation_x = dst->op_params[4];
    const int32_t dilation_y = dst->op_params[5];

    const int64_t c_in  = src->ne[2];
    const int64_t c_out = kernel->ne[3];
    LM_GGML_ASSERT(c_in == kernel->ne[2]);

    const int64_t src_w = src->ne[0];
    const int64_t src_h = src->ne[1];
    const int64_t knl_w = kernel->ne[0];
    const int64_t knl_h = kernel->ne[1];
    const int64_t dst_w = dst->ne[0];
    const int64_t dst_h = dst->ne[1];

    const float * src_data = (float *) src->data;
    void  * knl_data       = kernel->data;
    float * dst_data       = (float *) dst->data;

    const int64_t knl_n           = knl_w * knl_h * c_in;
    const int64_t patch_total     = dst->ne[3] * dst_w * dst_h;

    const int64_t space_per_patch   = knl_n * traits->type_size + c_out * sizeof(float);
    const int64_t batch_size        = params->wsize / space_per_patch;
    const int64_t patches_per_batch = batch_size > 8 ? (batch_size / 8) * 8 : batch_size;
    const int64_t batch_n           = (patch_total + patches_per_batch - 1) / patches_per_batch;

    LM_GGML_ASSERT(patches_per_batch > 0 && batch_size >= 1);

    void * tmp = params->wdata;

    for (int64_t batch_i = 0; batch_i < batch_n; ++batch_i) {

        const int64_t patch_start_batch = batch_i * patches_per_batch;
        const int64_t patch_end_batch   = std::min(patch_start_batch + patches_per_batch,
                                              patch_total);
        const int64_t patch_n           = patch_end_batch - patch_start_batch;

        const int64_t patch_per_thread  = (patch_n + params->nth - 1) / params->nth;
        const int64_t patch_start       = patch_start_batch + params->ith * patch_per_thread;
        const int64_t patch_end         = std::min(patch_start + patch_per_thread, patch_end_batch);

        //im2col for a patch
        for (int64_t p = patch_start; p < patch_end; ++p) {
            const int64_t  batch_n     =  p / (dst_w * dst_h);
            const int64_t  src_x       = (p / dst_w) % dst_h;
            const int64_t  src_y       =  p % dst_w;

            const float * src_base = (const float *)((const char *)src_data + batch_n * src->nb[3]);
            char *        dst_row  = (char *) tmp + (p % patches_per_batch) * knl_n * traits->type_size;

            for (int64_t ic = 0; ic < c_in; ++ic) {
                for (int64_t ky = 0; ky < knl_h; ++ky) {
                    for (int64_t kx = 0; kx < knl_w; ++kx) {
                        const int64_t sy = src_x * stride_y + ky * dilation_y - pad_y;
                        const int64_t sx = src_y * stride_x + kx * dilation_x - pad_x;

                        int64_t dst_idx = ic * (knl_h * knl_w) + ky * knl_w + kx;

                        float src_val;
                        if (sy < 0 || sy >= src_h || sx < 0 || sx >= src_w) {
                            src_val = 0.0f;
                        } else {
                            const float * src_ptr = (const float *)((const char *)src_base + sx * src->nb[0] + sy * src->nb[1] + ic * src->nb[2]);
                            src_val               = *src_ptr;
                        }

                        char * element_ptr = dst_row + dst_idx * traits->type_size;
                        if (kernel_type == LM_GGML_TYPE_F32) {
                            *(float *) element_ptr = src_val;
                        } else if (kernel_type == LM_GGML_TYPE_F16) {
                            *(lm_ggml_fp16_t *) element_ptr = LM_GGML_CPU_FP32_TO_FP16(src_val);
                        }
                    }
                }
            }
        }   // patches handled by this thread

        lm_ggml_barrier(params->threadpool);

        float * gemm_output = (float *) ((char *) tmp + patches_per_batch * knl_n * traits->type_size);

        LM_GGML_ASSERT(gemm_output + patch_n * c_out <= (float*)tmp + params->wsize);

        // GEMM: patches[patch_n, knl_n] × kernel[knl_n, c_out] = output[patch_n, c_out]
        lm_ggml_call_mul_mat(kernel_type, params, patch_n, c_out, knl_n, tmp, knl_data, gemm_output);

        lm_ggml_barrier(params->threadpool);


        //permute back [OC, N, OH, OW] to [N, OC, OH, OW]
        const int64_t permute_per_thread = (patch_n + params->nth - 1) / params->nth;
        const int64_t permute_start = params->ith * permute_per_thread;
        const int64_t permute_end = std::min(permute_start + permute_per_thread, patch_n);

        for (int64_t i = permute_start; i < permute_end; ++i) {
            const int64_t p       = patch_start_batch + i;
            const int64_t batch_n = p / (dst_w * dst_h);
            const int64_t dst_y   = (p / dst_w) % dst_h;
            const int64_t dst_x   = p % dst_w;

            for (int64_t oc = 0; oc < c_out; ++oc) {
                const float value = gemm_output[i * c_out + oc];
                float * dst_ptr = (float *)((char *)dst_data + dst_x * dst->nb[0] + dst_y * dst->nb[1] + oc * dst->nb[2] + batch_n * dst->nb[3]);
                *dst_ptr = value;
            }
        }
    }
}

void lm_ggml_compute_forward_conv_2d(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    lm_ggml_compute_forward_conv_2d_impl(params, src0, src1, dst, src0->type);
}

// lm_ggml_compute_forward_conv_3d

static void lm_ggml_compute_forward_conv_3d_impl(const lm_ggml_compute_params * params,
                                              const lm_ggml_tensor *         kernel,
                                              const lm_ggml_tensor *         src,
                                              lm_ggml_tensor *               dst,
                                              lm_ggml_type                   kernel_type) {

    LM_GGML_ASSERT(lm_ggml_is_contiguous(kernel));
    LM_GGML_ASSERT(kernel_type == LM_GGML_TYPE_F16 || kernel_type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT(kernel->type == kernel_type);

    const lm_ggml_type_traits * traits = lm_ggml_get_type_traits(kernel_type);

    const int32_t s0 = dst->op_params[0];
    const int32_t s1 = dst->op_params[1];
    const int32_t s2 = dst->op_params[2];
    const int32_t p0 = dst->op_params[3];
    const int32_t p1 = dst->op_params[4];
    const int32_t p2 = dst->op_params[5];
    const int32_t d0 = dst->op_params[6];
    const int32_t d1 = dst->op_params[7];
    const int32_t d2 = dst->op_params[8];
    const int32_t c  = dst->op_params[9];
    const int32_t n  = dst->op_params[10];
    const int32_t oc = dst->op_params[11];

    const int64_t src_w = src->ne[0];
    const int64_t src_h = src->ne[1];
    const int64_t src_d = src->ne[2];
    const int64_t knl_w = kernel->ne[0];
    const int64_t knl_h = kernel->ne[1];
    const int64_t knl_d = kernel->ne[2];
    const int64_t dst_w = dst->ne[0];
    const int64_t dst_h = dst->ne[1];
    const int64_t dst_d = dst->ne[2];

    const float * src_data = (float *) src->data;
    void  * knl_data       = kernel->data;
    float * dst_data       = (float *) dst->data;

    const int64_t knl_n_per_channel = knl_w * knl_h * knl_d;
    const int64_t knl_n_total       = knl_n_per_channel * c;
    const int64_t patch_total       = n * dst_w * dst_h * dst_d;

    const int64_t space_per_patch   = knl_n_total * traits->type_size + oc * sizeof(float);
    const int64_t batch_size        = params->wsize / space_per_patch;
    const int64_t patches_per_batch = batch_size > 8 ? (batch_size / 8) * 8 : batch_size;
    const int64_t batch_n           = (patch_total + patches_per_batch - 1) / patches_per_batch;

    LM_GGML_ASSERT(patches_per_batch > 0 && batch_size >= 1);

    void * tmp = params->wdata;

    for (int64_t batch_i = 0; batch_i < batch_n; ++batch_i) {
        const int64_t patch_start_batch = batch_i * patches_per_batch;
        const int64_t patch_end_batch   = std::min(patch_start_batch + patches_per_batch, patch_total);
        const int64_t patch_n_in_batch  = patch_end_batch - patch_start_batch;

        const int64_t patch_per_thread  = (patch_n_in_batch + params->nth - 1) / params->nth;
        const int64_t patch_start       = patch_start_batch + params->ith * patch_per_thread;
        const int64_t patch_end         = std::min(patch_start + patch_per_thread, patch_end_batch);

        for (int64_t p = patch_start; p < patch_end; ++p) {
            const int64_t p_in_batch = p % (dst_w * dst_h * dst_d);
            const int64_t p_in_depth = p_in_batch % (dst_w * dst_h);
            const int64_t batch_idx  = p / (dst_w * dst_h * dst_d);
            const int64_t dst_z      = p_in_batch / (dst_w * dst_h);
            const int64_t dst_y      = p_in_depth / dst_w;
            const int64_t dst_x      = p_in_depth % dst_w;

            char * dst_row = (char *) tmp + (p % patches_per_batch) * knl_n_total * traits->type_size;

            for (int64_t ic = 0; ic < c; ++ic) {
                for (int64_t kz = 0; kz < knl_d; ++kz) {
                    for (int64_t ky = 0; ky < knl_h; ++ky) {
                        for (int64_t kx = 0; kx < knl_w; ++kx) {
                            const int64_t sz = dst_z * s2 + kz * d2 - p2;
                            const int64_t sy = dst_y * s1 + ky * d1 - p1;
                            const int64_t sx = dst_x * s0 + kx * d0 - p0;

                            int64_t dst_idx = ic * knl_n_per_channel + kz * (knl_h * knl_w) + ky * knl_w + kx;

                            float src_val;
                            if (sz < 0 || sz >= src_d || sy < 0 || sy >= src_h || sx < 0 || sx >= src_w) {
                                src_val = 0.0f;
                            } else {
                                const int64_t cn_idx = batch_idx * c + ic;
                                const float * src_ptr = (const float *)((const char *)src_data + sx*src->nb[0] + sy*src->nb[1] + sz*src->nb[2] + cn_idx*src->nb[3]);
                                src_val = *src_ptr;
                            }

                            char * element_ptr = dst_row + dst_idx * traits->type_size;
                            if (kernel_type == LM_GGML_TYPE_F32) {
                                *(float *)element_ptr = src_val;
                            } else if (kernel_type == LM_GGML_TYPE_F16) {
                                *(lm_ggml_fp16_t *)element_ptr = LM_GGML_CPU_FP32_TO_FP16(src_val);
                            }
                        }
                    }
                }
            }
        }

        lm_ggml_barrier(params->threadpool);

        float * gemm_output = (float *) ((char *) tmp + patches_per_batch * knl_n_total * traits->type_size);
        lm_ggml_call_mul_mat(kernel_type, params, patch_n_in_batch, oc, knl_n_total, tmp, knl_data, gemm_output);

        lm_ggml_barrier(params->threadpool);

        const int64_t permute_per_thread = (patch_n_in_batch + params->nth - 1) / params->nth;
        const int64_t permute_start = params->ith * permute_per_thread;
        const int64_t permute_end = std::min(permute_start + permute_per_thread, patch_n_in_batch);

        for (int64_t i = permute_start; i < permute_end; ++i) {
            const int64_t p = patch_start_batch + i;
            const int64_t p_in_batch = p % (dst_w * dst_h * dst_d);
            const int64_t p_in_depth = p_in_batch % (dst_w * dst_h);
            const int64_t batch_idx  = p / (dst_w * dst_h * dst_d);
            const int64_t dst_z      = p_in_batch / (dst_w * dst_h);
            const int64_t dst_y      = p_in_depth / dst_w;
            const int64_t dst_x      = p_in_depth % dst_w;

            for (int64_t ioc = 0; ioc < oc; ++ioc) {
                const float value = gemm_output[i * oc + ioc];
                const int64_t ocn_idx = batch_idx * oc + ioc;
                float * dst_ptr = (float *)((char *)dst_data + dst_x*dst->nb[0] + dst_y*dst->nb[1] + dst_z*dst->nb[2] + ocn_idx*dst->nb[3]);
                *dst_ptr = value;
            }
        }
    }
}

void lm_ggml_compute_forward_conv_3d(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {
    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];
    lm_ggml_compute_forward_conv_3d_impl(params, src0, src1, dst, src0->type);
}

template <typename kernel_t>
static void lm_ggml_compute_forward_conv_transpose_2d_impl(
    const lm_ggml_compute_params * params,
          lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_F16 || src0->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT( dst->type == LM_GGML_TYPE_F32);

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    const int ith = params->ith;
    const int nth = params->nth;

    const int nk = ne00*ne01*ne02*ne03;

    LM_GGML_ASSERT(nb00 == lm_ggml_type_size(src0->type));
    LM_GGML_ASSERT(nb10 == sizeof(float));

    if (ith == 0) {
        memset(params->wdata, 0, params->wsize);

        // permute kernel data (src0) from (Kw x Kh x Cout x Cin) to (Cin x Kw x Kh x Cout)
        {
            kernel_t * const wdata = (kernel_t *) params->wdata + 0;

            for (int64_t i03 = 0; i03 < ne03; i03++) {
                for (int64_t i02 = 0; i02 < ne02; i02++) {
                    const kernel_t * const src = (kernel_t *)((char *) src0->data + i03*nb03 + i02*nb02);
                    kernel_t * dst_data = wdata + i02*ne01*ne00*ne03;
                    for (int64_t i01 = 0; i01 < ne01; i01++) {
                        for (int64_t i00 = 0; i00 < ne00; i00++) {
                            dst_data[i01*ne00*ne03 + i00*ne03 + i03] = src[i01 * ne00 + i00];
                        }
                    }
                }
            }
        }

        // permute source data (src1) from (Sw x Sh x Cin) to (Cin x Sw x Sh)
        {
            kernel_t * const wdata = (kernel_t *) params->wdata + nk;
            for (int i12 = 0; i12 < ne12; i12++) {
                for (int i11 = 0; i11 < ne11; i11++) {
                    const float * const src = (float *)((char *) src1->data + i12*nb12 + i11*nb11);
                    kernel_t * dst_data = wdata + i11*ne10*ne12;
                    for (int i10 = 0; i10 < ne10; i10++) {
                        if constexpr (std::is_same_v<kernel_t, lm_ggml_fp16_t>) {
                            dst_data[i10*ne12 + i12] = LM_GGML_CPU_FP32_TO_FP16(src[i10]);
                        } else {
                            dst_data[i10*ne12 + i12] = src[i10];
                        }
                    }
                }
            }
        }

        memset(dst->data, 0, lm_ggml_nbytes(dst));
    }
    lm_ggml_barrier(params->threadpool);

    const int32_t stride = lm_ggml_get_op_params_i32(dst, 0);

    // total patches in dst
    const int np = ne2;

    // patches per thread
    const int dp = (np + nth - 1)/nth;

    // patch range for this thread
    const int ip0 = dp*ith;
    const int ip1 = MIN(ip0 + dp, np);

    kernel_t * const wdata = (kernel_t *) params->wdata + 0;
    kernel_t * const wdata_src = wdata + nk;

    for (int i2 = ip0; i2 < ip1; i2++) { // Cout
        float * dst_data = (float *)((char *) dst->data + i2*nb2);
        kernel_t * wdata_kernel = wdata + i2*ne01*ne00*ne03;
        for (int i11 = 0; i11 < ne11; i11++) {
            for (int i10 = 0; i10 < ne10; i10++) {
                const int i1n = i11*ne10*ne12 + i10*ne12;
                for (int i01 = 0; i01 < ne01; i01++) {
                    for (int i00 = 0; i00 < ne00; i00++) {
                        float v = 0;
                        if constexpr (std::is_same_v<kernel_t, lm_ggml_fp16_t>) {
                            lm_ggml_vec_dot_f16(ne03, &v, 0,
                                    wdata_src + i1n, 0,
                                    wdata_kernel + i01*ne00*ne03 + i00*ne03, 0, 1);
                        } else {
                            lm_ggml_vec_dot_f32(ne03, &v, 0,
                                    wdata_src + i1n, 0,
                                    wdata_kernel + i01*ne00*ne03 + i00*ne03, 0, 1);
                        }
                        dst_data[(i11*stride + i01)*ne0 + i10*stride + i00] += v;
                    }
                }
            }
        }
    }
}

void lm_ggml_compute_forward_conv_transpose_2d(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F16:
            {
                lm_ggml_compute_forward_conv_transpose_2d_impl<lm_ggml_fp16_t>(params, dst);
            } break;
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_conv_transpose_2d_impl<float>(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_conv_2d_dw

struct lm_ggml_conv_2d_dw_params {
    int64_t channels;
    int64_t batch;
    int64_t src_w;
    int64_t src_h;
    int64_t dst_w;
    int64_t dst_h;
    int64_t knl_w;
    int64_t knl_h;
    int stride_x;
    int stride_y;
    int pad_x;
    int pad_y;
    int dilation_x;
    int dilation_y;
};

static void lm_ggml_compute_forward_conv_2d_dw_cwhn(
        const lm_ggml_compute_params * params,
        const lm_ggml_tensor * src,
        const lm_ggml_tensor * kernel,
        lm_ggml_tensor * dst,
        const lm_ggml_conv_2d_dw_params & p) {

    const int64_t c = p.channels;
    const float * knl_data = (const float *)kernel->data;

    const int64_t rows_total = p.dst_h * p.batch;
    const int64_t rows_per_thread = (rows_total + params->nth - 1) / params->nth;
    const int64_t row_start = params->ith * rows_per_thread;
    const int64_t row_end = MIN(row_start + rows_per_thread, rows_total);

#ifdef LM_GGML_SIMD
    #if defined(__ARM_FEATURE_SVE)
        const int64_t pkg_size = svcntw();
    #else
        const int64_t pkg_size = LM_GGML_F32_EPR;
    #endif
    const int64_t pkg_count = c / pkg_size;
    const int64_t c_pkg_end = pkg_count * pkg_size;
#else
    const int64_t c_pkg_end = 0;
#endif

    for (int64_t row = row_start; row < row_end; ++row) {
        const int64_t dst_y = row % p.dst_h;
        const float * src_data = (const float *)src->data + (row / p.dst_h) * p.src_w * p.src_h * c;
        for (int64_t dst_x = 0; dst_x < p.dst_w; ++dst_x) {
            float * dst_data = (float *)dst->data + (row * p.dst_w + dst_x) * c;
            const int64_t src_y_base = dst_y * p.stride_y - p.pad_y;
            const int64_t src_x_base = dst_x * p.stride_x - p.pad_x;

#ifdef LM_GGML_SIMD
            // Vectorized loop
            for (int64_t c_i = 0; c_i < c_pkg_end; c_i += pkg_size) {
                LM_GGML_F32_VEC sum = LM_GGML_F32_VEC_ZERO;
                for (int64_t knl_y = 0; knl_y < p.knl_h; ++knl_y) {
                    const int64_t src_y = src_y_base + knl_y * p.dilation_y;
                    if (src_y < 0 || src_y >= p.src_h) {
                        continue;
                    }
                    for (int64_t knl_x = 0; knl_x < p.knl_w; ++knl_x) {
                        const int64_t src_x = src_x_base + knl_x * p.dilation_x;
                        if (src_x < 0 || src_x >= p.src_w) {
                            continue;
                        }
                        LM_GGML_F32_VEC k = LM_GGML_F32_VEC_LOAD(knl_data + (knl_y * p.knl_w + knl_x) * c + c_i);
                        LM_GGML_F32_VEC s = LM_GGML_F32_VEC_LOAD(src_data + (src_y * p.src_w + src_x) * c + c_i);
                        sum = LM_GGML_F32_VEC_FMA(sum, k, s);
                    }
                }
                LM_GGML_F32_VEC_STORE(dst_data + c_i, sum);
            }
#endif
            // Scalar loop
            for (int64_t c_i = c_pkg_end; c_i < c; ++c_i) {
                float sum = 0.0f;
                for (int64_t knl_y = 0; knl_y < p.knl_h; ++knl_y) {
                    const int64_t src_y = src_y_base + knl_y * p.dilation_y;
                    if (src_y < 0 || src_y >= p.src_h) {
                        continue;
                    }
                    for (int64_t knl_x = 0; knl_x < p.knl_w; ++knl_x) {
                        const int64_t src_x = src_x_base + knl_x * p.dilation_x;
                        if (src_x < 0 || src_x >= p.src_w) {
                            continue;
                        }
                        sum += knl_data[(knl_y * p.knl_w + knl_x) * c + c_i]
                             * src_data[(src_y * p.src_w + src_x) * c + c_i];
                    }
                }
                dst_data[c_i] = sum;
            }
        }
    }
}

static void lm_ggml_compute_forward_conv_2d_dw_whcn(
        const lm_ggml_compute_params * params,
        const lm_ggml_tensor * src,
        const lm_ggml_tensor * kernel,
        lm_ggml_tensor * dst,
        const lm_ggml_conv_2d_dw_params & p) {

    const int64_t n = p.channels * p.batch;
    const int64_t per_thread = (n + params->nth - 1) / params->nth;
    const int64_t start = params->ith * per_thread;
    const int64_t end = MIN(start + per_thread, n);

    for (int64_t i = start; i < end; ++i) {
        const float * knl_data = (const float *)kernel->data + (i % p.channels) * p.knl_w * p.knl_h;
        const float * src_data = (const float *)src->data + i * p.src_w * p.src_h;
        float * dst_data = (float *)dst->data + i * p.dst_w * p.dst_h;

        for (int64_t dst_y = 0; dst_y < p.dst_h; ++dst_y) {
            for (int64_t dst_x = 0; dst_x < p.dst_w; ++dst_x) {

                float sum = 0.0f;
                for (int64_t knl_y = 0; knl_y < p.knl_h; ++knl_y) {
                    const int64_t src_y = dst_y * p.stride_y + knl_y * p.dilation_y - p.pad_y;
                    if (src_y < 0 || src_y >= p.src_h) {
                        continue;
                    }
                    for (int64_t knl_x = 0; knl_x < p.knl_w; ++knl_x) {
                        const int64_t src_x = dst_x * p.stride_x + knl_x * p.dilation_x - p.pad_x;
                        if (src_x < 0 || src_x >= p.src_w) {
                            continue;
                        }
                        sum += knl_data[knl_y * p.knl_w + knl_x]
                             * src_data[src_y * p.src_w + src_x];
                    }
                }
                dst_data[dst_y * p.dst_w + dst_x] = sum;
            }
        }
    }
}

void lm_ggml_compute_forward_conv_2d_dw(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * kernel = dst->src[0];
    const lm_ggml_tensor * src = dst->src[1];
    lm_ggml_conv_2d_dw_params p;
    p.channels = src->ne[2];
    p.batch = src->ne[3];
    p.src_w = src->ne[0];
    p.src_h = src->ne[1];
    p.dst_w = dst->ne[0];
    p.dst_h = dst->ne[1];
    p.knl_w = kernel->ne[0];
    p.knl_h = kernel->ne[1];
    p.stride_x = dst->op_params[0];
    p.stride_y = dst->op_params[1];
    p.pad_x = dst->op_params[2];
    p.pad_y = dst->op_params[3];
    p.dilation_x = dst->op_params[4];
    p.dilation_y = dst->op_params[5];

    LM_GGML_ASSERT(kernel->ne[3] == p.channels);
    LM_GGML_ASSERT(dst->ne[3] == p.batch);

    if (lm_ggml_is_contiguous(src)) {
        lm_ggml_compute_forward_conv_2d_dw_whcn(params, src, kernel, dst, p);
    } else if (lm_ggml_is_contiguous_channels(src)) {
        // kernel should also have channels most contiguous in memory
        LM_GGML_ASSERT(kernel->nb[0] >= kernel->nb[2] && kernel->nb[1] >= kernel->nb[0]);
        lm_ggml_compute_forward_conv_2d_dw_cwhn(params, src, kernel, dst, p);
    } else {
        LM_GGML_ABORT("non-contiguous memory layout not supported");
    }
}

// lm_ggml_compute_forward_pool_1d_ksp
static void lm_ggml_compute_forward_pool_1d_ksp(
        const lm_ggml_compute_params * params,
        const lm_ggml_op_pool op,
        const int k,
        const int s,
        const int p,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src = dst->src[0];

    assert(src->type == LM_GGML_TYPE_F32 || src->type == LM_GGML_TYPE_F16);

    if (params->ith != 0) {
        return;
    }

    const int64_t IW = src->ne[0];
    const int64_t OW = dst->ne[0];

    const int64_t nr = lm_ggml_nrows(src);

    for (int64_t ir = 0; ir < nr; ++ir) {
        const char * srow_bytes =            (const char *) src->data + ir * src->nb[1];
        float      * drow       = (float *) ((      char *) dst->data + ir * dst->nb[1]);

        for (int64_t ow = 0; ow < OW; ++ow) {
            float res = 0;
            switch (op) {
                case LM_GGML_OP_POOL_AVG: res = 0.0f;     break;
                case LM_GGML_OP_POOL_MAX: res = -FLT_MAX; break;
                case LM_GGML_OP_POOL_COUNT: LM_GGML_ABORT("fatal error");
            }

            int count = 0;
            const int base = (int) ow * s - p;

            for (int ki = 0; ki < k; ++ki) {
                const int j = base + ki;
                if (j < 0 || j >= (int) IW) {
                    continue;
                }

                float v;
                if (src->type == LM_GGML_TYPE_F32) {
                    v = ((const float *) srow_bytes)[j];
                } else {
                    v = LM_GGML_CPU_FP16_TO_FP32(((const lm_ggml_fp16_t *) srow_bytes)[j]);
                }

                switch (op) {
                    case LM_GGML_OP_POOL_AVG: res += v;                break;
                    case LM_GGML_OP_POOL_MAX: res =  std::max(v, res); break;
                    case LM_GGML_OP_POOL_COUNT: LM_GGML_ABORT("fatal error");
                }

                ++count;
            }

            switch (op) {
                case LM_GGML_OP_POOL_AVG: res = (count > 0) ? (res / count) : 0.0f; break;
                case LM_GGML_OP_POOL_MAX:                                           break;
                case LM_GGML_OP_POOL_COUNT: LM_GGML_ABORT("fatal error");
            }

            drow[ow] = res;
        }
    }
}

// lm_ggml_compute_forward_pool_1d

void lm_ggml_compute_forward_pool_1d(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const int32_t * opts = (const int32_t *)dst->op_params;
    lm_ggml_op_pool op = static_cast<lm_ggml_op_pool>(opts[0]);
    const int k0 = opts[1];
    const int s0 = opts[2];
    const int p0 = opts[3];

    lm_ggml_compute_forward_pool_1d_ksp(params, op, k0, s0, p0, dst);
}

// lm_ggml_compute_forward_pool_2d

void lm_ggml_compute_forward_pool_2d(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src = dst->src[0];

    assert(src->type == LM_GGML_TYPE_F32 || src->type == LM_GGML_TYPE_F16);

    if (params->ith != 0) {
        return;
    }

    const int32_t * opts = (const int32_t *)dst->op_params;

    lm_ggml_op_pool op = static_cast<lm_ggml_op_pool>(opts[0]);
    const int k0 = opts[1];
    const int k1 = opts[2];
    const int s0 = opts[3];
    const int s1 = opts[4];
    const int p0 = opts[5];
    const int p1 = opts[6];
    const char * cdata = (const char*)src->data;
    const char * const data_end = cdata + lm_ggml_nbytes(src);

    const int64_t px = dst->ne[0];
    const int64_t py = dst->ne[1];
    const int64_t pa = px * py;

    float * dplane = (float *)dst->data;

    const int ka = k0 * k1;
    const int offset0 = -p0;
    const int offset1 = -p1;

    while (cdata < data_end) {
        for (int oy = 0; oy < py; ++oy) {
            float * const drow = dplane + oy * px;
            float * const out  = drow;

            for (int ox = 0; ox < px; ++ox) {
                float res = 0;
                switch (op) {
                    case LM_GGML_OP_POOL_AVG: res = 0;        break;
                    case LM_GGML_OP_POOL_MAX: res = -FLT_MAX; break;
                    case LM_GGML_OP_POOL_COUNT: LM_GGML_ABORT("fatal error");
                }

                const int ix = offset0 + ox * s0;
                const int iy = offset1 + oy * s1;

                for (int ky = 0; ky < k1; ++ky) {
                    if (iy + ky < 0 || iy + ky >= src->ne[1]) {
                        continue;
                    }

                    const void * srow = (const void *)(cdata + src->nb[1] * (iy + ky));
                    for (int kx = 0; kx < k0; ++kx) {
                        int j = ix + kx;
                        if (j < 0 || j >= src->ne[0]) {
                            continue;
                        }

                        const float srow_j = (src->type == LM_GGML_TYPE_F32) ? ((const float*)srow)[j] : LM_GGML_CPU_FP16_TO_FP32(((const lm_ggml_fp16_t*)srow)[j]);
                        switch (op) {
                            case LM_GGML_OP_POOL_AVG: res += srow_j;                break;
                            case LM_GGML_OP_POOL_MAX: res =  std::max(srow_j, res); break;
                            case LM_GGML_OP_POOL_COUNT:               LM_GGML_ABORT("fatal error");
                        }
                    }
                }
                switch (op) {
                    case LM_GGML_OP_POOL_AVG:           res /= ka; break;
                    case LM_GGML_OP_POOL_MAX:                      break;
                    case LM_GGML_OP_POOL_COUNT: LM_GGML_ABORT("fatal error");
                }

                out[ox] = res;
            }
        }

        cdata  += src->nb[2];
        dplane += pa;
    }
}

// lm_ggml_compute_forward_pool_2d_back

void lm_ggml_compute_forward_pool_2d_back(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src  = dst->src[0];
    const lm_ggml_tensor * dstf = dst->src[1]; // forward tensor of dst

    assert(dst->type == LM_GGML_TYPE_F32 || dst->type == LM_GGML_TYPE_F16);

    if (params->ith != 0) {
        return;
    }

    const int32_t * opts = (const int32_t *)dst->op_params;
    lm_ggml_op_pool op = static_cast<lm_ggml_op_pool>(opts[0]);
    const int k0 = opts[1];
    const int k1 = opts[2];
    const int s0 = opts[3];
    const int s1 = opts[4];
    const int p0 = opts[5];
    const int p1 = opts[6];

    char       * cdata  = (char       *) dst->data;
    const char * cdataf = (const char *) dstf->data;
    const char * const data_end = cdata + lm_ggml_nbytes(dst);

    LM_GGML_ASSERT(params->ith == 0);
    memset(cdata, 0, lm_ggml_nbytes(dst));

    const int64_t px = src->ne[0];
    const int64_t py = src->ne[1];
    const int64_t pa = px * py;

    const float * splane = (const float *) src->data;

    const int ka = k0 * k1;
    const int offset0 = -p0;
    const int offset1 = -p1;

    while (cdata < data_end) {
        for (int oy = 0; oy < py; ++oy) {
            const float * const srow = splane + oy * px;
            for (int ox = 0; ox < px; ++ox) {
                const float grad0 = srow[ox];

                const int ix = offset0 + ox * s0;
                const int iy = offset1 + oy * s1;

                if (op == LM_GGML_OP_POOL_MAX) {
                    float maxval = -FLT_MAX;
                    int kxmax = -1;
                    int kymax = -1;

                    for (int ky = 0; ky < k1; ++ky) {
                        if (iy + ky < 0 || iy + ky >= dst->ne[1]) {
                            continue;
                        }
                        const void * drowf = (const void *)(cdataf + dst->nb[1] * (iy + ky));
                        for (int kx = 0; kx < k0; ++kx) {
                            int j = ix + kx;
                            if (j < 0 || j >= dst->ne[0]) {
                                continue;
                            }

                            const float val = dst->type == LM_GGML_TYPE_F32 ?
                                ((const float *) drowf)[j] : LM_GGML_CPU_FP16_TO_FP32(((const lm_ggml_fp16_t *) drowf)[j]);
                            if (val <= maxval) {
                                continue;
                            }

                            maxval = val;
                            kxmax = kx;
                            kymax = ky;
                        }
                    }

                    if (kxmax == -1 || kymax == -1) {
                        continue;
                    }

                    void * drow = (void *)(cdata + dst->nb[1] * (iy + kymax));
                    const int j = ix + kxmax;
                    if (dst->type == LM_GGML_TYPE_F32) {
                        ((float *) drow)[j] += grad0;
                    } else {
                        ((lm_ggml_fp16_t *) drow)[j] = LM_GGML_CPU_FP32_TO_FP16(grad0 + LM_GGML_CPU_FP16_TO_FP32(((const lm_ggml_fp16_t *) drow)[j]));
                    }
                } else if (op == LM_GGML_OP_POOL_AVG) {
                    const float grad = grad0 / ka;

                    for (int ky = 0; ky < k1; ++ky) {
                        if (iy + ky < 0 || iy + ky >= dst->ne[1]) {
                            continue;
                        }
                        void * drow = (void *)(cdata + dst->nb[1] * (iy + ky));
                        for (int kx = 0; kx < k0; ++kx) {
                            int j = ix + kx;
                            if (j < 0 || j >= dst->ne[0]) {
                                continue;
                            }

                            if (dst->type == LM_GGML_TYPE_F32) {
                                ((float *) drow)[j] += grad;
                            } else {
                                ((lm_ggml_fp16_t *) drow)[j] += LM_GGML_CPU_FP32_TO_FP16(grad);
                            }
                        }
                    }
                } else {
                    LM_GGML_ASSERT(false);
                }
            }
        }

        cdata  += dst->nb[2];
        cdataf += dst->nb[2];
        splane += pa;
    }
}

// lm_ggml_compute_forward_upscale

static void lm_ggml_compute_forward_upscale_f32(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_F32);

    const int ith = params->ith;
    const int nth = params->nth;

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    float sf0 = (float)ne0/src0->ne[0];
    float sf1 = (float)ne1/src0->ne[1];
    float sf2 = (float)ne2/src0->ne[2];
    float sf3 = (float)ne3/src0->ne[3];
    float pixel_offset = 0.5f;

    const int32_t mode_flags = lm_ggml_get_op_params_i32(dst, 0);
    const lm_ggml_scale_mode mode = (lm_ggml_scale_mode) (mode_flags & 0xFF);

    if (mode_flags & LM_GGML_SCALE_FLAG_ALIGN_CORNERS) {
        pixel_offset = 0.0f;
        sf0 = ne0 > 1 && ne00 > 1 ? (float)(ne0 - 1) / (ne00 - 1) : sf0;
        sf1 = ne1 > 1 && ne01 > 1 ? (float)(ne1 - 1) / (ne01 - 1) : sf1;
    }

    if (mode == LM_GGML_SCALE_MODE_NEAREST) {
        for (int64_t i3 = 0; i3 < ne3; i3++) {
            const int64_t i03 = i3 / sf3;
            for (int64_t i2 = ith; i2 < ne2; i2 += nth) {
                const int64_t i02 = i2 / sf2;
                for (int64_t i1 = 0; i1 < ne1; i1++) {
                    const int64_t i01 = i1 / sf1;
                    for (int64_t i0 = 0; i0 < ne0; i0++) {
                        const int64_t i00 = i0 / sf0;

                        const float * x = (float *)((char *) src0->data + i00*nb00 + i01*nb01 + i02*nb02 + i03*nb03);
                              float * y = (float *)((char *)  dst->data +  i0*nb0  +  i1*nb1  +  i2*nb2  +  i3*nb3);

                        *y = *x;
                    }
                }
            }
        }
    } else if (mode == LM_GGML_SCALE_MODE_BILINEAR && (mode_flags & LM_GGML_SCALE_FLAG_ANTIALIAS)) {
        // Similar to F.interpolate(..., mode="bilinear", align_corners=False, antialias=True)
        // https://github.com/pytorch/pytorch/blob/8871ff29b743948d1225389d5b7068f37b22750b/aten/src/ATen/native/cpu/UpSampleKernel.cpp
        auto triangle_filter = [](float x) -> float {
            return std::max(1.0f - fabsf(x), 0.0f);
        };

        // support and invscale, minimum 1 pixel for bilinear
        const float support1  = std::max(1.0f, 1.0f / sf1);
        const float invscale1 = 1.0f / support1;
        const float support0  = std::max(1.0f, 1.0f / sf0);
        const float invscale0 = 1.0f / support0;

        for (int64_t i3 = 0; i3 < ne3; i3++) {
            const int64_t i03 = i3 / sf3;
            for (int64_t i2 = ith; i2 < ne2; i2 += nth) {
                const int64_t i02 = i2 / sf2;
                for (int64_t i1 = 0; i1 < ne1; i1++) {
                    const float y = ((float) i1 + pixel_offset) / sf1;
                    for (int64_t i0 = 0; i0 < ne0; i0++) {
                        const float x = ((float) i0 + pixel_offset) / sf0;

                        // the range of source pixels that contribute
                        const int64_t x_min = std::max<int64_t>(x - support0 + pixel_offset, 0);
                        const int64_t x_max = std::min<int64_t>(x + support0 + pixel_offset, ne00);
                        const int64_t y_min = std::max<int64_t>(y - support1 + pixel_offset, 0);
                        const int64_t y_max = std::min<int64_t>(y + support1 + pixel_offset, ne01);

                        // bilinear filter with antialiasing
                        float val = 0.0f;
                        float total_weight = 0.0f;

                        for (int64_t sy = y_min; sy < y_max; sy++) {
                            const float weight_y = triangle_filter((sy - y + pixel_offset) * invscale1);

                            for (int64_t sx = x_min; sx < x_max; sx++) {
                                const float weight_x = triangle_filter((sx - x + pixel_offset) * invscale0);
                                const float weight = weight_x * weight_y;

                                if (weight <= 0.0f) {
                                    continue;
                                }

                                const float pixel = *(const float *)((const char *)src0->data + sx*nb00 + sy*nb01 + i02*nb02 + i03*nb03);
                                val += pixel * weight;
                                total_weight += weight;
                            }
                        }

                        if (total_weight > 0.0f) {
                            val /= total_weight;
                        }

                        float * dst_ptr = (float *)((char *)dst->data + i0*nb0 + i1*nb1 + i2*nb2 + i3*nb3);
                        *dst_ptr = val;
                    }
                }
            }
        }
    } else if (mode == LM_GGML_SCALE_MODE_BILINEAR) {
        for (int64_t i3 = 0; i3 < ne3; i3++) {
            const int64_t i03 = i3 / sf3;
            for (int64_t i2 = ith; i2 < ne2; i2 += nth) {
                const int64_t i02 = i2 / sf2;
                for (int64_t i1 = 0; i1 < ne1; i1++) {
                    const float y = ((float)i1 + pixel_offset) / sf1 - pixel_offset;
                    int64_t y0 = (int64_t)floorf(y);
                    int64_t y1 = y0 + 1;

                    y0 = std::max(int64_t(0), std::min(y0, ne01 - 1));
                    y1 = std::max(int64_t(0), std::min(y1, ne01 - 1));

                    float dy = y - (float)y0;
                    dy = std::max(0.0f, std::min(dy, 1.0f));

                    for (int64_t i0 = 0; i0 < ne0; i0++) {
                        const float x = ((float)i0 + pixel_offset) / sf0 - pixel_offset;
                        int64_t x0 = (int64_t)floorf(x);
                        int64_t x1 = x0 + 1;

                        x0 = std::max(int64_t(0), std::min(x0, ne00 - 1));
                        x1 = std::max(int64_t(0), std::min(x1, ne00 - 1));

                        float dx = x - (float)x0;
                        dx = std::max(0.0f, std::min(dx, 1.0f));

                        // fetch the four surrounding pixel values and interpolate
                        const float a = *(const float *)((const char *)src0->data + x0*nb00 + y0*nb01 + i02*nb02 + i03*nb03);
                        const float b = *(const float *)((const char *)src0->data + x1*nb00 + y0*nb01 + i02*nb02 + i03*nb03);
                        const float c = *(const float *)((const char *)src0->data + x0*nb00 + y1*nb01 + i02*nb02 + i03*nb03);
                        const float d = *(const float *)((const char *)src0->data + x1*nb00 + y1*nb01 + i02*nb02 + i03*nb03);

                        const float val = a*(1 - dx)*(1 - dy) + b*dx*(1 - dy) + c*(1 - dx)*dy + d*dx*dy;

                        float * y_dst = (float *)((char *)dst->data + i0*nb0 + i1*nb1 + i2*nb2 + i3*nb3);
                        *y_dst = val;
                    }
                }
            }
        }
    } else if (mode == LM_GGML_SCALE_MODE_BICUBIC) {
        // https://en.wikipedia.org/wiki/Bicubic_interpolation#Bicubic_convolution_algorithm
        const float a = -0.75f; // use alpha = -0.75 (same as PyTorch)
        auto weight1 = [a](float x) { return ((a + 2) * x - (a + 3)) * x * x + 1; };
        auto weight2 = [a](float x) { return ((a * x - 5 * a) * x + 8 * a) * x - 4 * a; };
        auto bicubic = [=](float p0, float p1, float p2, float p3, float x) {
            const float w0 = weight2(x + 1);
            const float w1 = weight1(x + 0);
            const float w2 = weight1(1 - x);
            const float w3 = weight2(2 - x);
            return p0*w0 + p1*w1 + p2*w2 + p3*w3;
        };

        for (int64_t i3 = 0; i3 < ne3; i3++) {
            const int64_t i03 = i3 / sf3;
            for (int64_t i2 = ith; i2 < ne2; i2 += nth) {
                const int64_t i02 = i2 / sf2;
                for (int64_t i1 = 0; i1 < ne1; i1++) {
                    const float y = ((float)i1 + pixel_offset) / sf1 - pixel_offset;
                    const int64_t y0 = (int64_t)floorf(y);
                    const float dy = y - (float)y0;

                    for (int64_t i0 = 0; i0 < ne0; i0++) {
                        const float x = ((float)i0 + pixel_offset) / sf0 - pixel_offset;
                        const int64_t x0 = (int64_t)floorf(x);
                        const float dx = x - (float)x0;

                        auto p = [=](int64_t x_off, int64_t y_off) -> float {
                            int64_t i00 = std::max(int64_t(0), std::min(x0 + x_off, ne00 - 1));
                            int64_t i01 = std::max(int64_t(0), std::min(y0 + y_off, ne01 - 1));
                            return *(const float *)((const char *)src0->data + i00*nb00 + i01*nb01 + i02*nb02 + i03*nb03);
                        };

                        const float val = bicubic(
                            bicubic(p(-1,-1), p(0,-1), p(1,-1), p(2,-1), dx),
                            bicubic(p(-1, 0), p(0, 0), p(1, 0), p(2, 0), dx),
                            bicubic(p(-1, 1), p(0, 1), p(1, 1), p(2, 1), dx),
                            bicubic(p(-1, 2), p(0, 2), p(1, 2), p(2, 2), dx), dy);

                        float * y_dst = (float *)((char *)dst->data + i0*nb0 + i1*nb1 + i2*nb2 + i3*nb3);
                        *y_dst = val;
                    }
                }
            }
        }
    } else {
        LM_GGML_ABORT("unsupported upscale mode");
    }
}

void lm_ggml_compute_forward_upscale(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_upscale_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}


// lm_ggml_compute_forward_pad

template<bool circular_t>
static void lm_ggml_compute_forward_pad_f32(
    const lm_ggml_compute_params * params,
          lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    assert(dst->nb[0] == sizeof(float));

    const int ith = params->ith;
    const int nth = params->nth;

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    float * dst_ptr = (float *) dst->data;
    const int32_t lp0 = lm_ggml_get_op_params_i32(dst, 0);
    const int32_t rp0 = lm_ggml_get_op_params_i32(dst, 1);
    const int32_t lp1 = lm_ggml_get_op_params_i32(dst, 2);
    const int32_t rp1 = lm_ggml_get_op_params_i32(dst, 3);
    const int32_t lp2 = lm_ggml_get_op_params_i32(dst, 4);
    const int32_t rp2 = lm_ggml_get_op_params_i32(dst, 5);
    const int32_t lp3 = lm_ggml_get_op_params_i32(dst, 6);
    const int32_t rp3 = lm_ggml_get_op_params_i32(dst, 7);

    // TODO: optimize

    for (int64_t i2 = 0; i2 < ne2; ++i2) {
        for (int64_t i1 = ith; i1 < ne1; i1 += nth) {
            for (int64_t i0 = 0; i0 < ne0; ++i0) {
                for (int64_t i3 = 0; i3 < ne3; ++i3) {
                    // circular means wrap around on a torus, so x and y loop around
                    if constexpr (circular_t) {
                        const int64_t dst_idx = i3*(ne0*ne1*ne2) + i2*(ne0*ne1) + i1*ne0 + i0;
                        const int64_t src_i0 = lm_ggml_wrap_around(i0 - lp0, ne00);
                        const int64_t src_i1 = lm_ggml_wrap_around(i1 - lp1, ne01);
                        const int64_t src_i2 = lm_ggml_wrap_around(i2 - lp2, ne02);
                        const int64_t src_i3 = lm_ggml_wrap_around(i3 - lp3, ne03);

                        const int64_t src_idx =
                            src_i3*nb03 +
                            src_i2*nb02 +
                            src_i1*nb01 +
                            src_i0*nb00;

                        const float * src_ptr = (const float *)((char *) src0->data + src_idx);
                        dst_ptr[dst_idx] = *src_ptr;
                    } else {
                        const int64_t dst_idx = i3*(ne0*ne1*ne2) + i2*(ne0*ne1) + i1*ne0 + i0;
                        if ((i0 >= lp0 && i0 < ne0 - rp0) \
                            && (i1 >= lp1 && i1 < ne1 - rp1) \
                            && (i2 >= lp2 && i2 < ne2 - rp2) \
                            && (i3 >= lp3 && i3 < ne3 - rp3)) {
                            const int64_t src_idx = (i3 - lp3)*nb03 + (i2 - lp2)*nb02 + (i1 - lp1)*nb01 + (i0 - lp0)*nb00;
                            const float * src_ptr = (const float *)((char *) src0->data + src_idx);
                            dst_ptr[dst_idx] = *src_ptr;
                        } else {
                            dst_ptr[dst_idx] = 0;
                        }
                    }
                }
            }
        }
    }
}


void lm_ggml_compute_forward_pad(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {
    const lm_ggml_tensor * src0 = dst->src[0];
    const bool circular = (bool) lm_ggml_get_op_params_i32(dst, 8);
    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                if (circular) {
                    lm_ggml_compute_forward_pad_f32<true>(params, dst);
                } else {
                    lm_ggml_compute_forward_pad_f32<false>(params, dst);
                }
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_pad_reflect_1d

void lm_ggml_compute_forward_pad_reflect_1d(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT( dst->type == LM_GGML_TYPE_F32);

    const int ith = params->ith;
    const int nth = params->nth;

    const int32_t * opts = (const int32_t *) dst->op_params;
    const int p0 = opts[0];
    const int p1 = opts[1];

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    for (int64_t i3 = 0; i3 < ne3; i3++) {
        for (int64_t i2 = 0; i2 < ne2; i2++) {
            for (int64_t i1 = ith; i1 < ne1; i1 += nth) {
                float * left  = (float *) ((char *) dst->data + i3*nb3 + i2*nb2 + i1*nb1 +         p0*nb0);
                float * right = (float *) ((char *) dst->data + i3*nb3 + i2*nb2 + i1*nb1 + (ne0-p1-1)*nb0);

                lm_ggml_vec_cpy_f32(ne00, left, (float *) ((char *) src0->data + i3*nb03 + i2*nb02 + i1*nb01));

                for (int i0 = 1; i0 <= p0; i0++) { left[-i0] = left[i0];   }
                for (int i0 = 1; i0 <= p1; i0++) { right[i0] = right[-i0]; }
            }
        }
    }
}

// lm_ggml_compute_forward_roll

static int64_t lm_ggml_wrap_index(int64_t i, int64_t ne) {
    if (i < 0) {
        return i + ne;
    } else if (i >= ne) {
        return i - ne;
    }
    return i;
}

static void lm_ggml_compute_forward_roll_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const float * src_data = (const float *) src0->data;
    float * dst_data = (float *) dst->data;

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    const int s0 = lm_ggml_get_op_params_i32(dst, 0);
    const int s1 = lm_ggml_get_op_params_i32(dst, 1);
    const int s2 = lm_ggml_get_op_params_i32(dst, 2);
    const int s3 = lm_ggml_get_op_params_i32(dst, 3);

    const int64_t total = ne1 * ne2 * ne3;
    const int64_t per_thread = (total + params->nth) / params->nth;
    const int64_t start = params->ith * per_thread;
    const int64_t end   = std::min(start + per_thread, total);

    for (int64_t i = start; i < end; ++i) {
        const int64_t i1 = i % ne1;
        const int64_t i2 = (i / ne1) % ne2;
        const int64_t i3 = i / (ne2 * ne1);
        float * dst_row = dst_data + (i3*nb3 + i2*nb2 + i1*nb1) / sizeof(float);

        const int64_t i01 = lm_ggml_wrap_index(i1 - s1, ne01);
        const int64_t i02 = lm_ggml_wrap_index(i2 - s2, ne02);
        const int64_t i03 = lm_ggml_wrap_index(i3 - s3, ne03);
        const float * src_row = src_data + (i03*nb03 + i02*nb02 + i01*nb01) / sizeof(float);

        const int64_t s = lm_ggml_wrap_index(-s0, ne00);
        const int64_t n = ne00 - s;
        lm_ggml_vec_cpy_f32(n, dst_row,     src_row + s);
        lm_ggml_vec_cpy_f32(s, dst_row + n, src_row);
    }
}

void lm_ggml_compute_forward_roll(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_roll_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_arange

static void lm_ggml_compute_forward_arange_f32(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    LM_GGML_ASSERT(dst->nb[0] == sizeof(float));

    const int ith = params->ith;
    const int nth = params->nth;

    const float start = lm_ggml_get_op_params_f32(dst, 0);
    const float stop  = lm_ggml_get_op_params_f32(dst, 1);
    const float step  = lm_ggml_get_op_params_f32(dst, 2);

    const int64_t steps = (int64_t) ceilf((stop - start) / step);

    LM_GGML_ASSERT(lm_ggml_nelements(dst) == steps);

    for (int64_t i = ith; i < steps; i+= nth) {
        float value = start + step * i;
        ((float *)dst->data)[i] = value;
    }
}

void lm_ggml_compute_forward_arange(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {
    switch (dst->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_arange_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

static void lm_ggml_compute_forward_timestep_embedding_f32(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    LM_GGML_ASSERT(src0->nb[0] == sizeof(float));

    const int ith = params->ith;
    const int nth = params->nth;

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    const int dim = lm_ggml_get_op_params_i32(dst, 0);
    const int max_period = lm_ggml_get_op_params_i32(dst, 1);

    int half = dim / 2;

    for (int64_t i = 0; i < ne00; i++) {
        float * embed_data = (float *)((char *)  dst->data +  i*nb1);
        for (int64_t j = ith; j < half; j += nth) {
            float timestep = ((float *)src0->data)[i];
            float freq = (float)expf(-logf(max_period) * j / half);
            float arg = timestep * freq;
            embed_data[j] = cosf(arg);
            embed_data[j + half] = sinf(arg);
        }
        if (dim % 2 != 0 && ith == 0) {
            embed_data[2 * half] = 0.f;
        }
    }
}

void lm_ggml_compute_forward_timestep_embedding(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_timestep_embedding_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_argsort

template<enum lm_ggml_sort_order order>
struct cmp_argsort {
    const float * data;
    bool operator()(int32_t a, int32_t b) const {
        if constexpr (order == LM_GGML_SORT_ORDER_ASC) {
            return data[a] < data[b];
        } else {
            return data[a] > data[b];
        }
    }
};

static void lm_ggml_compute_forward_argsort_f32(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    LM_GGML_ASSERT(nb0 == sizeof(float));

    const int ith = params->ith;
    const int nth = params->nth;

    const int64_t nr = lm_ggml_nrows(src0);

    lm_ggml_sort_order order = (lm_ggml_sort_order) lm_ggml_get_op_params_i32(dst, 0);

    for (int64_t i = ith; i < nr; i += nth) {
        const float * src_data = (float *)((char *) src0->data + i*nb01);

        int32_t * dst_data = (int32_t *)((char *) dst->data + i*nb1);

        for (int64_t j = 0; j < ne0; j++) {
            dst_data[j] = j;
        }

        switch (order) {
            case LM_GGML_SORT_ORDER_ASC:
                std::sort(dst_data, dst_data + ne0, cmp_argsort<LM_GGML_SORT_ORDER_ASC>{src_data});
                break;

            case LM_GGML_SORT_ORDER_DESC:
                std::sort(dst_data, dst_data + ne0, cmp_argsort<LM_GGML_SORT_ORDER_DESC>{src_data});
                break;

            default:
                LM_GGML_ABORT("invalid sort order");
        }
    }
}

void lm_ggml_compute_forward_argsort(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_argsort_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_top_k

struct cmp_top_k {
    const float * data;
    bool operator()(int32_t a, int32_t b) const {
        return data[a] > data[b];
    }
};

static void lm_ggml_compute_forward_top_k_f32(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    LM_GGML_ASSERT(nb0 == sizeof(float));

    const int ith = params->ith;
    const int nth = params->nth;

    const int64_t nr = lm_ggml_nrows(src0);

    const int top_k = ne0;

    int32_t * tmp = (int32_t *) params->wdata + (ne00 + CACHE_LINE_SIZE_F32) * ith;

    for (int64_t i = ith; i < nr; i += nth) {
        const float * src_data = (float *)((char *) src0->data + i*nb01);

        for (int64_t j = 0; j < ne00; j++) {
            tmp[j] = j;
        }

        std::partial_sort(tmp, tmp + top_k, tmp + ne00, cmp_top_k{src_data});

        int32_t * dst_data = (int32_t *)((char *) dst->data + i*nb1);

        std::copy(tmp, tmp + top_k, dst_data);

        // emphasize that the order is not important
        if (top_k > 1) {
            std::swap(dst_data[0], dst_data[1]);
        }
    }
}

void lm_ggml_compute_forward_top_k(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_top_k_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

static void lm_ggml_compute_forward_flash_attn_ext_f16_one_chunk(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst,
        int ir0, int ir1,
        int64_t ic_start, int64_t ic_end,
        float * partials, int64_t partial_stride) {

    const bool write_partials = (partials != nullptr);
    const lm_ggml_tensor * q     = dst->src[0];
    const lm_ggml_tensor * k     = dst->src[1];
    const lm_ggml_tensor * v     = dst->src[2];
    const lm_ggml_tensor * mask  = dst->src[3];
    const lm_ggml_tensor * sinks = dst->src[4];

    LM_GGML_TENSOR_LOCALS(int64_t, neq, q,   ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nbq, q,   nb)
    LM_GGML_TENSOR_LOCALS(int64_t, nek, k,   ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nbk, k,   nb)
    LM_GGML_TENSOR_LOCALS(int64_t, nev, v,   ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nbv, v,   nb)
    LM_GGML_TENSOR_LOCALS(int64_t, ne,  dst, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb,  dst, nb)

    const int64_t DK = nek0;
    const int64_t DV = nev0;
    const int64_t N  = neq1;

    LM_GGML_ASSERT(ne0 == DV);
    LM_GGML_ASSERT(ne2 == N);

    // input tensor rows must be contiguous
    LM_GGML_ASSERT(nbq0 == lm_ggml_type_size(q->type));
    LM_GGML_ASSERT(nbk0 == lm_ggml_type_size(k->type));
    LM_GGML_ASSERT(nbv0 == lm_ggml_type_size(v->type));

    LM_GGML_ASSERT(neq0 == DK);
    LM_GGML_ASSERT(nek0 == DK);
    LM_GGML_ASSERT(nev0 == DV);

    LM_GGML_ASSERT(neq1 == N);

    // dst cannot be transposed or permuted
    LM_GGML_ASSERT(nb0 == sizeof(float));
    LM_GGML_ASSERT(nb0 <= nb1);
    LM_GGML_ASSERT(nb1 <= nb2);
    LM_GGML_ASSERT(nb2 <= nb3);

    // broadcast factors
    const int64_t rk2 = neq2/nek2;
    const int64_t rk3 = neq3/nek3;

    const int64_t rv2 = neq2/nev2;
    const int64_t rv3 = neq3/nev3;

    // parallelize by q rows using lm_ggml_vec_dot_f32

    float scale         = 1.0f;
    float max_bias      = 0.0f;
    float logit_softcap = 0.0f;

    memcpy(&scale,         (float *) dst->op_params + 0, sizeof(float));
    memcpy(&max_bias,      (float *) dst->op_params + 1, sizeof(float));
    memcpy(&logit_softcap, (float *) dst->op_params + 2, sizeof(float));

    if (logit_softcap != 0) {
        scale /= logit_softcap;
    }

    const uint32_t n_head      = neq2;
    const uint32_t n_head_log2 = 1u << (uint32_t) floor(log2(n_head));

    const float m0 = powf(2.0f, -(max_bias       ) / n_head_log2);
    const float m1 = powf(2.0f, -(max_bias / 2.0f) / n_head_log2);

    lm_ggml_type         const k_vec_dot_type = lm_ggml_get_type_traits_cpu(k->type)->vec_dot_type;
    lm_ggml_from_float_t const q_to_vec_dot   = lm_ggml_get_type_traits_cpu(k_vec_dot_type)->from_float;
    lm_ggml_vec_dot_t    const kq_vec_dot     = lm_ggml_get_type_traits_cpu(k->type)->vec_dot;
    lm_ggml_to_float_t   const v_to_float     = lm_ggml_get_type_traits(v->type)->to_float;

    LM_GGML_ASSERT((                            q_to_vec_dot) && "fattn: unsupported K-type");
    LM_GGML_ASSERT((v->type == LM_GGML_TYPE_F32 || v_to_float  ) && "fattn: unsupported V-type");

    int ith = params->ith;

    for (int ir = ir0; ir < ir1; ++ir) {
        // q indices
        const int iq3 = ir/(neq2*neq1);
        const int iq2 = (ir - iq3*neq2*neq1)/neq1;
        const int iq1 = (ir - iq3*neq2*neq1 - iq2*neq1);

        const uint32_t h = iq2; // head index
        const float slope = (max_bias > 0.0f) ? h < n_head_log2 ? powf(m0, h + 1) : powf(m1, 2*(h - n_head_log2) + 1) : 1.0f;

        float S = 0.0f;      // sum
        float M = -INFINITY; // maximum KQ value

        float       * VKQ32 = (float       *) params->wdata + ith*(1*DK + 2*DV + CACHE_LINE_SIZE_F32); // FP32 VKQ accumulator
        float       * V32   =                 (VKQ32 + 1*DV); // (temporary) FP32 V buffer
        lm_ggml_fp16_t * VKQ16 = (lm_ggml_fp16_t *) (VKQ32 + 1*DV); // (temporary) FP16 VKQ accumulator
        lm_ggml_fp16_t * Q_q   = (lm_ggml_fp16_t *) (VKQ32 + 2*DV); // (temporary) buffer for Q converted to quantized/FP16

        if (v->type == LM_GGML_TYPE_F16) {
            memset(VKQ16, 0, DV*sizeof(lm_ggml_fp16_t));
        } else {
            memset(VKQ32, 0, DV*sizeof(float));
        }

        const lm_ggml_fp16_t * mp = mask ? (lm_ggml_fp16_t *)((char *) mask->data + iq1*mask->nb[1] + (iq2%mask->ne[2])*mask->nb[2] + (iq3%mask->ne[3])*mask->nb[3]) : NULL;

        // k indices
        const int ik3 = iq3 / rk3;
        const int ik2 = iq2 / rk2;

        // v indices
        const int iv3 = iq3 / rv3;
        const int iv2 = iq2 / rv2;

        const float * pq = (const float *) ((char *) q->data + (iq1*nbq1 + iq2*nbq2 + iq3*nbq3));
        q_to_vec_dot(pq, Q_q, DK);

        // online softmax / attention
        // loop over n_kv and n_head_kv
        // ref: https://arxiv.org/pdf/2112.05682.pdf

        for (int64_t ic = ic_start; ic < ic_end; ++ic) {
            const float mv = mp ? slope*LM_GGML_CPU_FP16_TO_FP32(mp[ic]) : 0.0f;
            if (mv == -INFINITY) {
                continue;
            }

            float s; // KQ value

            const char * k_data = (const char *) k->data + ( ic*nbk1 + ik2*nbk2 + ik3*nbk3);
            kq_vec_dot(DK, &s, 0, k_data, 0, Q_q, 0, 1);

            s = s*scale; // scale KQ value

            if (logit_softcap != 0.0f) {
                s = logit_softcap*tanhf(s);
            }

            s += mv; // apply mask

            const float Mold = M;

            float ms = 1.0f; // upon new higher max val, scale VKQ and KQ sum with this value
            float vs = 1.0f; // post-softmax KQ value, expf(s - M)

            const char * v_data = ((const char *) v->data + (ic*nbv1 + iv2*nbv2 + iv3*nbv3));

            if (v->type == LM_GGML_TYPE_F16) {
                if (s > M) {
                    // s is new maximum, ms < 1.0f, vs == expf(s - s) == 1.0f
                    M = s;
                    ms = expf(Mold - M);

                    // V = V*expf(Mold - M)
                    lm_ggml_vec_scale_f16(DV, VKQ16, ms);
                } else {
                    // no new maximum, ms == 1.0f, vs != 1.0f
                    vs = expf(s - M);
                }

                // V += v*expf(s - M)
                lm_ggml_vec_mad_f16(DV, VKQ16, (const lm_ggml_fp16_t *) v_data, vs);
            } else {
                if (s > M) {
                    // s is new maximum, ms < 1.0f, vs == expf(s - s) == 1.0f
                    M = s;
                    ms = expf(Mold - M);

                    // V = V*expf(Mold - M)
                    lm_ggml_vec_scale_f32(DV, VKQ32, ms);
                } else {
                    // no new maximum, ms == 1.0f, vs != 1.0f
                    vs = expf(s - M);
                }

                // V += v*expf(s - M)
                if (v_to_float) {
                    v_to_float(v_data, V32, DV);
                    lm_ggml_vec_mad_f32(DV, VKQ32, V32, vs);
                } else {
                    // V is F32
                    lm_ggml_vec_mad_f32(DV, VKQ32, (const float *) v_data, vs);
                }
            }

            S = S*ms + vs; // scale and increment sum with partial sum
        }

        if (v->type == LM_GGML_TYPE_F16) {
            for (int64_t d = 0; d < DV; ++d) {
                VKQ32[d] = LM_GGML_CPU_FP16_TO_FP32(VKQ16[d]);
            }
        }

        // sinks - apply only on the first kv-chunk
        if (sinks && ic_start == 0) {
            const float s = ((float *)((char *) sinks->data))[h];

            float ms = 1.0f;
            float vs = 1.0f;

            if (s > M) {
                ms = expf(M - s);
                M = s;
                lm_ggml_vec_scale_f32(DV, VKQ32, ms);
            } else {
                vs = expf(s - M);
            }

            S = S*ms + vs;
        }

        if (write_partials) {
            // Write M, S, VKQ to partials for later reduction
            // partials layout: [M, S, VKQ[DV]] per query head
            float * partial = partials + ir * partial_stride;
            partial[0] = M;
            partial[1] = S;
            memcpy(partial + 2, VKQ32, DV * sizeof(float));
        } else {
            // V /= S
            const float S_inv = S == 0.0f ? 0.0f : 1.0f/S;
            lm_ggml_vec_scale_f32(DV, VKQ32, S_inv);

            // dst indices
            const int i1 = iq1;
            const int i2 = iq2;
            const int i3 = iq3;

            // permute(0, 2, 1, 3)
            memcpy((char *) dst->data + (i3*ne2*ne1 + i2 + i1*ne1)*nb1, VKQ32, nb1);
        }
    }
}

static void lm_ggml_compute_forward_flash_attn_ext_tiled(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst,
        int ir0, int ir1) {
    const lm_ggml_tensor * q     = dst->src[0];
    const lm_ggml_tensor * k     = dst->src[1];
    const lm_ggml_tensor * v     = dst->src[2];
    const lm_ggml_tensor * mask  = dst->src[3];
    const lm_ggml_tensor * sinks = dst->src[4];

    LM_GGML_TENSOR_LOCALS(int64_t, neq, q,   ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nbq, q,   nb)
    LM_GGML_TENSOR_LOCALS(int64_t, nek, k,   ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nbk, k,   nb)
    LM_GGML_TENSOR_LOCALS(int64_t, nev, v,   ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nbv, v,   nb)
    LM_GGML_TENSOR_LOCALS(int64_t, ne,  dst, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb,  dst, nb)

    const int64_t DK = nek0;
    const int64_t DV = nev0;
    const int64_t N  = neq1;

    LM_GGML_ASSERT(ne0 == DV);
    LM_GGML_ASSERT(ne2 == N);

    // input tensor rows must be contiguous
    LM_GGML_ASSERT(nbq0 == lm_ggml_type_size(q->type));
    LM_GGML_ASSERT(nbk0 == lm_ggml_type_size(k->type));
    LM_GGML_ASSERT(nbv0 == lm_ggml_type_size(v->type));

    LM_GGML_ASSERT(neq0 == DK);
    LM_GGML_ASSERT(nek0 == DK);
    LM_GGML_ASSERT(nev0 == DV);

    LM_GGML_ASSERT(neq1 == N);

    // dst cannot be transposed or permuted
    LM_GGML_ASSERT(nb0 == sizeof(float));
    LM_GGML_ASSERT(nb0 <= nb1);
    LM_GGML_ASSERT(nb1 <= nb2);
    LM_GGML_ASSERT(nb2 <= nb3);

    LM_GGML_ASSERT(k->type == v->type);
    const lm_ggml_type kv_type = k->type;


    // broadcast factors
    const int64_t rk2 = neq2/nek2;
    const int64_t rk3 = neq3/nek3;

    const int64_t rv2 = neq2/nev2;
    const int64_t rv3 = neq3/nev3;

    float scale         = 1.0f;
    float max_bias      = 0.0f;
    float logit_softcap = 0.0f;

    memcpy(&scale,         (float *) dst->op_params + 0, sizeof(float));
    memcpy(&max_bias,      (float *) dst->op_params + 1, sizeof(float));
    memcpy(&logit_softcap, (float *) dst->op_params + 2, sizeof(float));

    if (logit_softcap != 0) {
        scale /= logit_softcap;
    }

    const uint32_t n_head      = neq2;
    const uint32_t n_head_log2 = 1u << (uint32_t) floor(log2(n_head));

    const float m0 = powf(2.0f, -(max_bias       ) / n_head_log2);
    const float m1 = powf(2.0f, -(max_bias / 2.0f) / n_head_log2);

    int ith = params->ith;

    static constexpr int Q_TILE_SZ  = lm_ggml_fa_tile_config::Q;
    static constexpr int KV_TILE_SZ = lm_ggml_fa_tile_config::KV;

    int ir = ir0;
    while (ir < ir1) {
        // q indices for the start of this tile
        const int iq3 = ir/(neq2*neq1);
        const int iq2 = (ir - iq3*neq2*neq1)/neq1;
        const int iq1 = (ir - iq3*neq2*neq1 - iq2*neq1);

        // Number of valid rows in this tile:
        // - limited by tile size (Q_TILE_SZ)
        // - limited by chunk boundary (ir1 - ir)
        // - limited by head boundary (neq1 - iq1) to avoid crossing into next head
        const int tile_rows = MIN(Q_TILE_SZ, MIN((int)(ir1 - ir), (int)(neq1 - iq1)));
        LM_GGML_ASSERT(tile_rows > 0);

        const uint32_t h = iq2; // head index
        const float slope = (max_bias > 0.0f) ? h < n_head_log2 ? powf(m0, h + 1) : powf(m1, 2*(h - n_head_log2) + 1) : 1.0f;

        float S[Q_TILE_SZ];
        float M[Q_TILE_SZ];

        for (int i = 0 ; i < Q_TILE_SZ; ++i) {
            S[i] = 0.;
            M[i] = -INFINITY;
        }

        // Per-thread scratch layout:
        // Q_q:    Q_TILE_SZ * DK (converted Q tile — F32 for GEMM, KV type for scalar)
        // KQ:     Q_TILE_SZ * KV_TILE_SZ (attention scores in float)
        // mask:   Q_TILE_SZ * KV_TILE_SZ (mask in float)
        // VKQ32:  Q_TILE_SZ * DV (FP32 output accumulator)
        // V32:    KV_TILE_SZ * DV (F32 buffer for V tile)
        // K_f32:  KV_TILE_SZ * DK (F32 buffer for K tile — GEMM path)
        float * base  = (float *) params->wdata + ith*(Q_TILE_SZ*DK + 2*Q_TILE_SZ*KV_TILE_SZ + Q_TILE_SZ*DV + KV_TILE_SZ*DV + KV_TILE_SZ*DK + CACHE_LINE_SIZE_F32);

        void  * Q_q    = base;
        float * KQ     = (float *)((char *)base + Q_TILE_SZ * DK * sizeof(float));
        float * mask32 = KQ + Q_TILE_SZ * KV_TILE_SZ;
        float * VKQ32  = mask32 + Q_TILE_SZ * KV_TILE_SZ;
        float * V32    = VKQ32 + Q_TILE_SZ * DV;
        float * K_f32  = V32 + KV_TILE_SZ * DV;

        memset(VKQ32, 0, Q_TILE_SZ * DV * sizeof(float));
        memset(mask32, 0, Q_TILE_SZ * KV_TILE_SZ * sizeof(float));

        // k indices
        const int ik3 = iq3 / rk3;
        const int ik2 = iq2 / rk2;

        // v indices
        const int iv3 = iq3 / rv3;
        const int iv2 = iq2 / rv2;

        {
            float * Q_f32 = (float *)Q_q;
            for (int tq = 0; tq < tile_rows; tq++) {
                const float * pq = (const float *) ((char *) q->data + ((iq1 + tq)*nbq1 + iq2*nbq2 + iq3*nbq3));
                memcpy(Q_f32 + tq * DK, pq, DK * sizeof(float));
            }
            for (int tq = tile_rows; tq < Q_TILE_SZ; tq++) {
                memset(Q_f32 + tq * DK, 0, DK * sizeof(float));
            }
        }

        memset(K_f32, 0, DK * KV_TILE_SZ * sizeof(float));
        memset(V32,   0, KV_TILE_SZ * DV * sizeof(float));

        for (int64_t ic = 0; ic < nek1; ic += KV_TILE_SZ) {
            const int kv_tile = (int)std::min((int64_t)KV_TILE_SZ, nek1 - ic);

            // skip the tile entirely if all the masks are -inf
            if (mask) {
                bool can_skip = true;
                for (int tq = 0; tq < tile_rows; tq++) {
                    const lm_ggml_fp16_t * mp_row = (const lm_ggml_fp16_t *)((const char *) mask->data + (iq1 + tq)*mask->nb[1] + (iq2%mask->ne[2])*mask->nb[2] + (iq3%mask->ne[3])*mask->nb[3]);
                    for (int tk = 0; tk < kv_tile; tk++) {
                        mask32[tq * KV_TILE_SZ + tk] = slope * LM_GGML_CPU_FP16_TO_FP32(mp_row[ic + tk]);
                        if (mask32[tq * KV_TILE_SZ + tk] != -INFINITY) {
                            can_skip = false;
                        }
                    }
                    // Pad remaining mask entries with -inf
                    for (int tk = kv_tile; tk < KV_TILE_SZ; tk++) {
                        mask32[tq * KV_TILE_SZ + tk] = -INFINITY;
                    }
                }

                if (can_skip) {
                    continue;
                }
            }

            // Pack K tile transposed: K_f32[dk][kv] so KV_TILE is contiguous (SIMD dim)
            // Zero-pad the last tile so the GEMM always operates on KV_TILE_SZ columns
            for (int tk = 0; tk < kv_tile; tk++) {
                const char * k_data = (const char *)k->data + (ic + tk)*nbk1 + ik2*nbk2 + ik3*nbk3;
                if (kv_type == LM_GGML_TYPE_F16) {
                    const lm_ggml_fp16_t * k_f16 = (const lm_ggml_fp16_t *)k_data;
                    for (int64_t dk = 0; dk < DK; dk++) {
                        K_f32[dk * KV_TILE_SZ + tk] = LM_GGML_CPU_FP16_TO_FP32(k_f16[dk]);
                    }
                } else {
                    const float * k_f32_src = (const float *)k_data;
                    for (int64_t dk = 0; dk < DK; dk++) {
                        K_f32[dk * KV_TILE_SZ + tk] = k_f32_src[dk];
                    }
                }
            }
            memset(KQ, 0, Q_TILE_SZ * KV_TILE_SZ * sizeof(float));
            simd_gemm(KQ, (const float *)Q_q, K_f32, Q_TILE_SZ, DK, KV_TILE_SZ);
            lm_ggml_vec_scale_f32(Q_TILE_SZ * KV_TILE_SZ, KQ, scale);

            // Set padded KQ entries to -inf so softmax gives them zero weight
            if (kv_tile < KV_TILE_SZ) {
                for (int tq = 0; tq < Q_TILE_SZ; tq++) {
                    for (int tk = kv_tile; tk < KV_TILE_SZ; tk++) {
                        KQ[tq * KV_TILE_SZ + tk] = -INFINITY;
                    }
                }
            }

            if (logit_softcap != 0.0f) {
                lm_ggml_vec_tanh_f32(Q_TILE_SZ * KV_TILE_SZ, KQ, KQ);
                lm_ggml_vec_scale_f32(Q_TILE_SZ * KV_TILE_SZ, KQ, logit_softcap);
            }

            if (mask) {
                lm_ggml_vec_add_f32(tile_rows * KV_TILE_SZ, KQ, KQ, mask32);
            }

            bool skip[Q_TILE_SZ] = {};

            for (int tq = 0; tq < Q_TILE_SZ; tq++) {
                float * kq_row = KQ + tq * KV_TILE_SZ;

                float tile_max;
                lm_ggml_vec_max_f32(KV_TILE_SZ, &tile_max, kq_row);

                if (tile_max == -INFINITY) {
                    skip[tq] = true;
                    continue;
                }

                const float Mold = M[tq];
                const float Mnew = fmaxf(Mold, tile_max);

                if (Mnew > Mold) {
                    const float ms = expf(Mold - Mnew);
                    lm_ggml_vec_scale_f32(DV, VKQ32 + tq * DV, ms);
                    S[tq] *= ms;
                }
                M[tq] = Mnew;


                S[tq] += lm_ggml_vec_soft_max_f32(KV_TILE_SZ, kq_row, kq_row, Mnew);
            }

            // V accumulation: VKQ32 += softmax(KQ) * V
            // Pack V tile to contiguous F32, zero-padded
            for (int tk = 0; tk < kv_tile; tk++) {
                const char * v_data = (const char *)v->data + (ic + tk)*nbv1 + iv2*nbv2 + iv3*nbv3;
                if (kv_type == LM_GGML_TYPE_F16) {
                    lm_ggml_fp16_to_fp32_row((const lm_ggml_fp16_t *)v_data, V32 + tk * DV, DV);
                } else {
                    memcpy(V32 + tk * DV, v_data, DV * sizeof(float));
                }
            }
            for (int tq = 0; tq < Q_TILE_SZ; tq++) {
                if (skip[tq]) {
                    memset(KQ + tq * KV_TILE_SZ, 0, KV_TILE_SZ * sizeof(float));
                }
            }
            simd_gemm(VKQ32, KQ, V32, Q_TILE_SZ, KV_TILE_SZ, DV);
        }

        // sinks (apply only to valid rows in the tile)
        if (sinks) {
            const float s = ((float *)((char *) sinks->data))[h];

            for (int tq = 0; tq < tile_rows; tq++) {
                float ms = 1.0f;
                float vs = 1.0f;

                if (s > M[tq]) {
                    ms = expf(M[tq] - s);
                    lm_ggml_vec_scale_f32(DV, VKQ32 + tq * DV, ms);
                } else {
                    vs = expf(s - M[tq]);
                }

                S[tq] = S[tq] * ms + vs;
            }
        }

        for (int tq = 0; tq < tile_rows; tq++) {
            // V /= S
            const float S_inv = S[tq] == 0.0f ? 0.0f : 1.0f / S[tq];
            lm_ggml_vec_scale_f32(DV, VKQ32 + tq * DV, S_inv);

            // dst indices
            const int i1 = iq1 + tq;
            const int i2 = iq2;
            const int i3 = iq3;

            // permute(0, 2, 1, 3)
            memcpy((char *) dst->data + (i3*ne2*ne1 + i2 + i1*ne1)*nb1, VKQ32 + tq * DV, nb1);
        }

        ir += tile_rows;
    }
}

// Reduction function: combines partial results across KV chunks
// Partials layout in wdata: [n_q_heads][n_chunks][2 + DV]
static void lm_ggml_flash_attn_ext_reduce_partials(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst,
        const int64_t n_chunks,
        const int64_t chunk_size) {

    const lm_ggml_tensor * q = dst->src[0];
    const lm_ggml_tensor * k = dst->src[1];
    const lm_ggml_tensor * v = dst->src[2];

    const int64_t DK        = k->ne[0];
    const int64_t DV        = v->ne[0];
    const int64_t nek1      = k->ne[1];
    const int64_t n_q_heads = q->ne[2];

    const int ith = params->ith;
    const int nth = params->nth;

    const int64_t wdata_per_thread = DK + 2*DV + CACHE_LINE_SIZE_F32;
    float *       thread_wdata     = (float *) params->wdata + ith * wdata_per_thread;

    const int64_t partials_offset  = nth * (DK + 2*DV + CACHE_LINE_SIZE_F32);
    const int64_t partial_size     = 2 + DV;
    const float * partials_base    = (const float *) params->wdata + partials_offset;

    // Output layout
    const int64_t ne1 = dst->ne[1];
    const int64_t ne2 = dst->ne[2];
    const size_t  nb1 = dst->nb[1];

    // Each thread reduces a subset of query heads
    for (int64_t q_head = ith; q_head < n_q_heads; q_head += nth) {
        float   M_final   = -INFINITY;
        float   S_final   = 0.0f;
        float * VKQ_final = thread_wdata;
        memset(VKQ_final, 0, DV * sizeof(float));

        // Combine partials from all chunks
        for (int64_t chunk_idx = 0; chunk_idx < n_chunks; ++chunk_idx) {
            const int64_t ic_start = chunk_idx * chunk_size;
            if (ic_start >= nek1) continue;

            const float * partial   = partials_base + (q_head * n_chunks + chunk_idx) * partial_size;
            const float   M_chunk   = partial[0];
            const float   S_chunk   = partial[1];
            const float * VKQ_chunk = partial + 2;

            if (S_chunk == 0.0f) continue;

            const float M_new     = fmaxf(M_final, M_chunk);
            const float scale_old = expf(M_final - M_new);
            const float scale_new = expf(M_chunk - M_new);

            for (int64_t d = 0; d < DV; ++d) {
                VKQ_final[d] = VKQ_final[d] * scale_old + VKQ_chunk[d] * scale_new;
            }
            S_final = S_final * scale_old + S_chunk * scale_new;
            M_final = M_new;
        }

        // Normalize and write to output
        if (S_final != 0.0f) {
            const float S_inv = 1.0f / S_final;
            lm_ggml_vec_scale_f32(DV, VKQ_final, S_inv);
        }
        // iq1=0, iq3=0 for decode
        memcpy((char *) dst->data + (0*ne2*ne1 + q_head + 0*ne1)*nb1, VKQ_final, nb1);
    }
}

static void lm_ggml_compute_forward_flash_attn_ext_f16(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * q     = dst->src[0];
    const lm_ggml_tensor * k     = dst->src[1];
    const lm_ggml_tensor * v     = dst->src[2];

    LM_GGML_TENSOR_LOCALS(int64_t, neq, q,   ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nbq, q,   nb)
    LM_GGML_TENSOR_LOCALS(int64_t, nek, k,   ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nbk, k,   nb)
    LM_GGML_TENSOR_LOCALS(int64_t, nev, v,   ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nbv, v,   nb)
    LM_GGML_TENSOR_LOCALS(int64_t, ne,  dst, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb,  dst, nb)

    const int64_t DK = nek0;
    const int64_t DV = nev0;
    const int64_t N  = neq1;


    LM_GGML_ASSERT(ne0 == DV);
    LM_GGML_ASSERT(ne2 == N);

    // input tensor rows must be contiguous
    LM_GGML_ASSERT(nbq0 == lm_ggml_type_size(q->type));
    LM_GGML_ASSERT(nbk0 == lm_ggml_type_size(k->type));
    LM_GGML_ASSERT(nbv0 == lm_ggml_type_size(v->type));

    LM_GGML_ASSERT(neq0 == DK);
    LM_GGML_ASSERT(nek0 == DK);
    LM_GGML_ASSERT(nev0 == DV);

    LM_GGML_ASSERT(neq1 == N);

    // dst cannot be transposed or permuted
    LM_GGML_ASSERT(nb0 == sizeof(float));
    LM_GGML_ASSERT(nb0 <= nb1);
    LM_GGML_ASSERT(nb1 <= nb2);
    LM_GGML_ASSERT(nb2 <= nb3);

    const int ith = params->ith;
    const int nth = params->nth;

    // When use_ref is set, force the vec-only reference implementation (no tiling, no KV-chunking)
    const bool use_ref = params->use_ref;

    const bool kv_is_f32_or_f16 = (k->type == LM_GGML_TYPE_F32 || k->type == LM_GGML_TYPE_F16);
    const bool use_split_kv_path = !use_ref && (neq1 == 1 && neq3 == 1) && kv_is_f32_or_f16 && (k->type == v->type) && q->type == LM_GGML_TYPE_F32 && nek1 >= 512;

    if (use_split_kv_path) {
        const int64_t chunk_size = (nek1 + nth - 1) / nth;

        // Partials buffer layout: [q_head][kv_chunk][M, S, VKQ]
        const int64_t partial_size  = 2 + DV;
        float *       partials_base = (float *) params->wdata + nth * (DK + 2*DV + CACHE_LINE_SIZE_F32);

        const int64_t ic_start = ith * chunk_size;
        const int64_t ic_end   = std::min(ic_start + chunk_size, nek1);

        const int64_t partial_stride = nth * partial_size;
        float *       chunk_partials = partials_base + ith * partial_size;

        if (ic_start < nek1) {
            for (int64_t q_head = 0; q_head < neq2; q_head++) {
                lm_ggml_compute_forward_flash_attn_ext_f16_one_chunk(
                    params, dst, q_head, q_head + 1, ic_start, ic_end,
                    chunk_partials, partial_stride);
            }
        } else {
            for (int64_t q_head = 0; q_head < neq2; q_head++) {
                float * q_partials = chunk_partials + q_head * partial_stride;
                q_partials[0] = -INFINITY;  // M
                q_partials[1] = 0.0f;       // S
            }
        }

        lm_ggml_barrier(params->threadpool);
        lm_ggml_flash_attn_ext_reduce_partials(params, dst, nth, chunk_size);
    } else {

        // total rows in q
        const int64_t nr = neq1*neq2*neq3;

        // disable for NUMA
        const bool disable_chunking = lm_ggml_is_numa();

        // 4x chunks per thread
        int nth_scaled = nth * 4;
        int64_t chunk_size = (nr + nth_scaled - 1) / nth_scaled;
        int64_t nchunk     = (nr + chunk_size - 1) / chunk_size;

        if (nth == 1 || nchunk < nth || disable_chunking) {
            nchunk = nth;
        }

        if (ith == 0) {
            lm_ggml_threadpool_chunk_set(params->threadpool, nth);
        }

        lm_ggml_barrier(params->threadpool);

        const int64_t dr = (nr + nchunk - 1) / nchunk;

        static constexpr int64_t Q_TILE_SZ  = lm_ggml_fa_tile_config::Q;
        bool use_tiled = !use_ref &&
                               (q->type == LM_GGML_TYPE_F32 &&
                                kv_is_f32_or_f16 &&
                                k->type == v->type &&
                                neq1 >= Q_TILE_SZ);
#ifdef LM_GGML_SIMD
#if defined(__ARM_FEATURE_SVE)
        const int64_t f32_epr = svcntw();
#else
        const int64_t f32_epr = LM_GGML_F32_EPR;
#endif
        use_tiled &= (DV % f32_epr == 0);
#endif
        int current_chunk = ith;

        while (current_chunk < nchunk) {
            const int64_t ir0 = dr * current_chunk;
            const int64_t ir1 = MIN(ir0 + dr, nr);

            if (use_tiled) {
                lm_ggml_compute_forward_flash_attn_ext_tiled(params, dst, ir0, ir1);
            } else {
                lm_ggml_compute_forward_flash_attn_ext_f16_one_chunk(params, dst, ir0, ir1, 0, nek1, nullptr, 0);
            }

            current_chunk = lm_ggml_threadpool_chunk_add(params->threadpool, 1);
        }
    }
}

void lm_ggml_compute_forward_flash_attn_ext(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {
    switch (dst->op_params[3]) {
        case LM_GGML_PREC_DEFAULT:
        case LM_GGML_PREC_F32:
            {
                // uses F32 accumulators
                lm_ggml_compute_forward_flash_attn_ext_f16(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_flash_attn_back

static void lm_ggml_compute_forward_flash_attn_back_f32(
        const lm_ggml_compute_params * params,
        const bool masked,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * q = dst->src[0];
    const lm_ggml_tensor * k = dst->src[1];
    const lm_ggml_tensor * v = dst->src[2];
    const lm_ggml_tensor * d = dst->src[3];

    LM_GGML_TENSOR_LOCALS(int64_t, neq, q,   ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nbq, q,   nb)
    LM_GGML_TENSOR_LOCALS(int64_t, nek, k,   ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nbk, k,   nb)
    LM_GGML_TENSOR_LOCALS(int64_t, nev, v,   ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nbv, v,   nb)
    LM_GGML_TENSOR_LOCALS(int64_t, ned, d,   ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nbd, d,   nb)
    LM_GGML_TENSOR_LOCALS(int64_t, ne,  dst, ne)
    LM_GGML_TENSOR_LOCALS(size_t,  nb,  dst, nb)

    const int ith = params->ith;
    const int nth = params->nth;

    const int64_t D = neq0;
    const int64_t N = neq1;
    const int64_t P = nek1 - N;
    const int64_t M = P + N;

    const int Mup  = lm_ggml_up(M, LM_GGML_SOFT_MAX_UNROLL);
    const int mxDM = MAX(D, Mup);

    // LM_GGML_ASSERT(ne0 == D);
    // LM_GGML_ASSERT(ne1 == N);
    LM_GGML_ASSERT(P >= 0);

    LM_GGML_ASSERT(nbq0 == sizeof(float));
    LM_GGML_ASSERT(nbk0 == sizeof(float));
    LM_GGML_ASSERT(nbv0 == sizeof(float));

    LM_GGML_ASSERT(neq0 == D);
    LM_GGML_ASSERT(nek0 == D);
    LM_GGML_ASSERT(nev1 == D);
    LM_GGML_ASSERT(ned0 == D);

    LM_GGML_ASSERT(neq1 == N);
    LM_GGML_ASSERT(nek1 == N + P);
    LM_GGML_ASSERT(nev1 == D);
    LM_GGML_ASSERT(ned1 == N);

    // dst cannot be transposed or permuted
    LM_GGML_ASSERT(nb0 == sizeof(float));
    LM_GGML_ASSERT(nb0 <= nb1);
    LM_GGML_ASSERT(nb1 <= nb2);
    LM_GGML_ASSERT(nb2 <= nb3);

    if (ith == 0) {
        memset(dst->data, 0, nb0*ne0*ne1*ne2*ne3);
    }
    lm_ggml_barrier(params->threadpool);

    const int64_t elem_q = lm_ggml_nelements(q);
    const int64_t elem_k = lm_ggml_nelements(k);

    lm_ggml_type result_type = dst->type;
    LM_GGML_ASSERT(lm_ggml_blck_size(result_type) == 1);
    const size_t tsize = lm_ggml_type_size(result_type);

    const size_t offs_q = 0;
    const size_t offs_k = offs_q + LM_GGML_PAD(elem_q * tsize, LM_GGML_MEM_ALIGN);
    const size_t offs_v = offs_k + LM_GGML_PAD(elem_k * tsize, LM_GGML_MEM_ALIGN);

    void * grad_q = (char *) dst->data;
    void * grad_k = (char *) dst->data + offs_k;
    void * grad_v = (char *) dst->data + offs_v;

    const size_t nbgq1 = nb0*neq0;
    const size_t nbgq2 = nb0*neq0*neq1;
    const size_t nbgq3 = nb0*neq0*neq1*neq2;

    const size_t nbgk1 = nb0*nek0;
    const size_t nbgk2 = nb0*nek0*nek1;
    const size_t nbgk3 = nb0*nek0*nek1*neq2;

    const size_t nbgv1 = nb0*nev0;
    const size_t nbgv2 = nb0*nev0*nev1;
    const size_t nbgv3 = nb0*nev0*nev1*neq2;

    // parallelize by k rows using lm_ggml_vec_dot_f32

    // total rows in k
    const int nr = nek2*nek3;

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    const float scale = 1.0f/sqrtf(D);

    //printf("P=%d N=%d D=%d ir0=%d ir1=%d scale = %f\n", P, N, D, ir0, ir1, scale);

    // how often k2 (and v2) is repeated in q2
    int nrep = neq2/nek2;

    for (int ir = ir0; ir < ir1; ++ir) {
        // q indices
        const int ik3 = ir/(nek2);
        const int ik2 = ir - ik3*nek2;

        const int iq3 = ik3;
        const int id3 = ik3;
        const int iv3 = ik3;
        const int iv2 = ik2;

        for (int irep = 0; irep < nrep; ++irep) {
            const int iq2 = ik2 + irep*nek2;
            const int id2 = iq2;

            // (ik2 + irep*nek2) % nek2 == ik2
            for (int iq1 = 0; iq1 < neq1; ++iq1) {
                const int id1 = iq1;

                // not sure about CACHE_LINE_SIZE_F32..
                // - maybe it must not be multiplied by 2 and excluded from .. in SM 1*(..) offset?
                float * S  = (float *) params->wdata + ith*2*(mxDM + CACHE_LINE_SIZE_F32) + 0*(mxDM+CACHE_LINE_SIZE_F32);
                float * SM = (float *) params->wdata + ith*2*(mxDM + CACHE_LINE_SIZE_F32) + 1*(mxDM+CACHE_LINE_SIZE_F32);

                for (int i = M; i < Mup; ++i) {
                    S[i] = -INFINITY;
                }

                const int64_t masked_begin = masked ? (P + iq1 + 1) : M;
                for (int64_t ic = 0; ic < masked_begin; ++ic) {
                    // k indices
                    const int ik1 = ic;

                    // S indices
                    const int i1 = ik1;

                    lm_ggml_vec_dot_f32(neq0,
                            S + i1, 0,
                            (float *) ((char *) k->data + (ik1*nbk1 + ik2*nbk2 + ik3*nbk3)), 0,
                            (float *) ((char *) q->data + (iq1*nbq1 + iq2*nbq2 + iq3*nbq3)), 0, 1);
                }

                // scale
                lm_ggml_vec_scale_f32(masked_begin, S, scale);

                for (int64_t i = masked_begin; i < M; i++) {
                    S[i] = -INFINITY;
                }

                // softmax
                // exclude known -INF S[..] values from max and loop
                // dont forget to set their SM values to zero
                {
                    float max = -INFINITY;
                    lm_ggml_vec_max_f32(masked_begin, &max, S);

                    lm_ggml_float sum = 0.0;
                    {
#ifdef LM_GGML_SOFT_MAX_ACCELERATE
                        max = -max;
                        vDSP_vsadd(SM, 1, &max, SM, 1, Mup);
                        vvexpf(SM, SM, &Mup);
                        lm_ggml_vec_sum_f32(Mup, &sum, SM);
#else
                        sum = lm_ggml_vec_soft_max_f32(Mup, SM, S, max);
#endif
                    }

                    assert(sum > 0.0);

                    sum = 1.0/sum;
                    lm_ggml_vec_scale_f32(masked_begin, SM, sum);

                }

                // step-by-step explanation
                {
                    // forward-process                    shape      grads from backward process
                    // parallel_for ik2,ik3:
                    //  for irep:
                    //   iq2 = ik2 + irep*nek2
                    //   k[:D,:M,:,:]                     [D,M,:,:]  grad[k][:D,:M,ik2,ik3]  += grad[kcur]
                    //   q[:D,:N,:,:]                     [D,N,:,:]  grad[q][:D,iq1,iq2,iq3] += grad[qcur]
                    //   v[:M,:D,:,:]                     [M,D,:,:]  grad[v][:M,:D,iv2,iv3]  += grad[vcur]
                    //   for iq1:
                    //    kcur   = k[:D,:M,ik2,ik3]       [D,M,1,1]  grad[kcur] = grad[S1].T @ qcur
                    //    qcur   = q[:D,iq1,iq2,iq3]      [D,1,1,1]  grad[qcur] = grad[S1]   @ kcur
                    //    vcur   = v[:M,:D,iv2,iv3]       [M,D,1,1]  grad[vcur] = grad[S5].T @ S4
                    //    S0     = -Inf                   [D,1,1,1]
                    //   ~S1[i]  = dot(kcur[:D,i], qcur)
                    //    S1     = qcur @ kcur.T          [M,1,1,1]  grad[S1]   = grad[S2] * scale
                    //    S2     = S1 * scale             [M,1,1,1]  grad[S2]   = diag_mask_zero(grad[S3], P)
                    //    S3     = diag_mask_inf(S2, P)   [M,1,1,1]  grad[S3]   = S4 * (grad[S4] - dot(S4, grad[S4]))
                    //    S4     = softmax(S3)            [M,1,1,1]  grad[S4]   = grad[S5] @ vcur
                    //   ~S5[i]  = dot(vcur[:,i], S4)
                    //    S5     = S4 @ vcur.T            [D,1,1,1]  grad[S5]   = d[:D,id1,id2,id3]
                    //   ~dst[i,iq1,iq2,iq3]  = S5[i]              ^
                    //    dst[:D,iq1,iq2,iq3] = S5                 | grad[dst[:D,iq1,iq2,iq3]] = d[:D,id1,id2,id3]
                    // dst                               backward-/ grad[dst]                 = d
                    //
                    // output gradients with their dependencies:
                    //
                    // grad[kcur] = grad[S1].T @ qcur
                    // grad[S1]   = diag_mask_zero(grad[S3], P) * scale
                    // grad[S3]   = S4 * (grad[S4] - dot(S4, grad[S4]))
                    // grad[S4]   = grad[S5] @ vcur
                    // grad[S4]   = d[:D,id1,id2,id3] @ vcur
                    // grad[qcur] = grad[S1]   @ kcur
                    // grad[vcur] = grad[S5].T @ S4
                    // grad[vcur] = d[:D,id1,id2,id3].T @ S4
                    //
                    // in post-order:
                    //
                    // S1         = qcur @ kcur.T
                    // S2         = S1 * scale
                    // S3         = diag_mask_inf(S2, P)
                    // S4         = softmax(S3)
                    // grad[S4]   = d[:D,id1,id2,id3] @ vcur
                    // grad[S3]   = S4 * (grad[S4] - dot(S4, grad[S4]))
                    // grad[S1]   = diag_mask_zero(grad[S3], P) * scale
                    // grad[qcur] = grad[S1]   @ kcur
                    // grad[kcur] = grad[S1].T @ qcur
                    // grad[vcur] = d[:D,id1,id2,id3].T @ S4
                    //
                    // using less variables (SM=S4):
                    //
                    // S             = diag_mask_inf(qcur @ kcur.T * scale, P)
                    // SM            = softmax(S)
                    // S             = d[:D,iq1,iq2,iq3] @ vcur
                    // dot_SM_gradSM = dot(SM, S)
                    // S             = SM * (S - dot(SM, S))
                    // S             = diag_mask_zero(S, P) * scale
                    //
                    // grad[q][:D,iq1,iq2,iq3] += S   @ kcur
                    // grad[k][:D,:M,ik2,ik3]  += S.T @ qcur
                    // grad[v][:M,:D,iv2,iv3]  += d[:D,id1,id2,id3].T @ SM
                }

                // S = gradSM = d[:D,id1,id2,id3] @ vcur[:,:,iv2,iv3]
                // S = d[:D,id1,id2,id3] @ vcur[:,:,iv2,iv3]
                // for ic:
                //   S[:M] += vcur[:M,ic,iv2,iv3] * d[ic,id1,id2,id3]
                // exclude known future zero S[..] values from operation
                lm_ggml_vec_set_f32(masked_begin, S, 0);
                for (int64_t ic = 0; ic < D; ++ic) {
                    lm_ggml_vec_mad_f32(masked_begin,
                            S,
                             (float *) ((char *) v->data + (          ic*nbv1  + iv2*nbv2 + iv3*nbv3)),
                            *(float *) ((char *) d->data + (ic*nbd0 + id1*nbd1 + id2*nbd2 + id3*nbd3)));
                }

                // S = SM * (S - dot(SM, S))
                float dot_SM_gradSM = 0;
                lm_ggml_vec_dot_f32 (masked_begin, &dot_SM_gradSM, 0, SM, 0, S, 0, 1);
                lm_ggml_vec_acc1_f32(M, S, -dot_SM_gradSM);
                lm_ggml_vec_mul_f32 (masked_begin, S, S, SM);

                // S = diag_mask_zero(S, P) * scale
                // already done by above lm_ggml_vec_set_f32

                // exclude known zero S[..] values from operation
                lm_ggml_vec_scale_f32(masked_begin, S, scale);

                // S    shape [M,1]
                // SM   shape [M,1]
                // kcur shape [D,M]
                // qcur shape [D,1]
                // vcur shape [M,D]

                // grad[q][:D,iq1,iq2,iq3] += S @ kcur
                // grad[q][:D,iq1,iq2,iq3] += shape[M,1] @ shape[D,M]
                // for ic:
                //  grad[q][:D,iq1,iq2,iq3] += S[ic] * kcur[:D,ic,ik2,ik3]
                // exclude known zero S[..] values from loop
                for (int64_t ic = 0; ic < masked_begin; ++ic) {
                    lm_ggml_vec_mad_f32(D,
                            (float *) ((char *) grad_q  + (iq1*nbgq1 + iq2*nbgq2  + iq3*nbgq3)),
                            (float *) ((char *) k->data + (ic*nbk1   + ik2*nbk2   + ik3*nbk3)),
                            S[ic]);
                }

                // grad[k][:D,:M,iq2,iq3] += S.T @ qcur
                // for ic:
                //  grad[k][:D,ic,iq2,iq3] += S.T[0,ic] * qcur[:D,0]
                //  grad[k][:D,ic,iq2,iq3] += S[ic]     * qcur[:D,0]
                // exclude known zero S[..] values from loop
                for (int64_t ic = 0; ic < masked_begin; ++ic) {
                    lm_ggml_vec_mad_f32(D,
                            (float *) ((char *) grad_k  + (ic*nbgk1  + ik2*nbgk2  + ik3*nbgk3)),
                            (float *) ((char *) q->data + (iq1*nbq1  + iq2*nbq2   + iq3*nbq3)),
                            S[ic]);
                }

                // grad[v][:M,:D,iv2,iv3] += d[:D,id1,id2,id3].T       @ SM
                // for ic:
                //  grad[v][:M,ic,iv2,iv3] += d[:D,id1,id2,id3].T[0,ic] * SM[:M]
                //  grad[v][:M,ic,iv2,iv3] += d[ic,id1,id2,id3]         * SM[:M]
                // exclude known zero SM[..] values from mad
                for (int64_t ic = 0; ic < D; ++ic) {
                    lm_ggml_vec_mad_f32(masked_begin,
                            (float *) ((char *) grad_v   + (          ic*nbgv1 + iv2*nbgv2 + iv3*nbgv3)),
                            SM,
                            *(float *) ((char *) d->data + (ic*nbd0 + id1*nbd1 + id2*nbd2  + id3*nbd3)));
                }
            }
        }
    }
}

void lm_ggml_compute_forward_flash_attn_back(
        const lm_ggml_compute_params * params,
        const bool masked,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * q = dst->src[0];

    switch (q->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_flash_attn_back_f32(params, masked, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_ssm_conv

static void lm_ggml_compute_forward_ssm_conv_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {
    const lm_ggml_tensor * src0 = dst->src[0]; // conv_x
    const lm_ggml_tensor * src1 = dst->src[1]; // conv1d.weight

    const int ith = params->ith;
    const int nth = params->nth;

    const int nc  = src1->ne[0]; // d_conv
    const int ncs = src0->ne[0]; // d_conv - 1 + n_t
    const int nr  = src0->ne[1]; // d_inner
    const int n_t =  dst->ne[1]; // tokens per sequence
    const int n_s =  dst->ne[2]; // number of sequences in the batch

    LM_GGML_ASSERT( dst->ne[0] == nr);
    LM_GGML_ASSERT(src0->nb[0] == sizeof(float));
    LM_GGML_ASSERT(src1->nb[0] == sizeof(float));
    LM_GGML_ASSERT(src0->nb[1] == src0->ne[0]*sizeof(float));

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);
    const int ir  = ir1 - ir0;

    for (int i3 = 0; i3 < n_s; ++i3) {
        for (int i2 = 0; i2 < n_t; ++i2) {
            // {d_conv - 1 + n_t, d_inner, n_seqs}
            // sliding window
            const float * s = (const float *) ((const char *) src0->data + ir0*(src0->nb[1]) + i2*(src0->nb[0]) + i3*(src0->nb[2])); // {d_conv, d_inner, n_s}
            const float * c = (const float *) ((const char *) src1->data + ir0*(src1->nb[1])); // {d_conv, d_inner}
            float * x = (float *) ((char *) dst->data + ir0*(dst->nb[0]) + i2*(dst->nb[1]) + i3*(dst->nb[2])); // {d_inner, n_t, n_s}

            // TODO: transpose the output for smaller strides for big batches?
            // d_inner
            for (int i1 = 0; i1 < ir; ++i1) {
                // rowwise dot product
                // NOTE: not using lm_ggml_vec_dot_f32, because its sum is in double precision
                float sumf = 0.0f;

                // d_conv
                for (int i0 = 0; i0 < nc; ++i0) {
                    sumf += s[i0 + i1*ncs] * c[i0 + i1*nc];
                }
                x[i1] = sumf;
            }
        }
    }
}

void lm_ggml_compute_forward_ssm_conv(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {
    switch (dst->src[0]->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_ssm_conv_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_ssm_scan

static void lm_ggml_compute_forward_ssm_scan_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {
    const lm_ggml_tensor * src0 = dst->src[0]; // s  {d_state, dim, n_head, n_seqs+}
    const lm_ggml_tensor * src1 = dst->src[1]; // x  {dim, n_head, n_seq_tokens, n_seqs}
    const lm_ggml_tensor * src2 = dst->src[2]; // dt {n_head, n_seq_tokens, n_seqs}
    const lm_ggml_tensor * src3 = dst->src[3]; // A  {d_state, n_head} or {1, n_head}
    const lm_ggml_tensor * src4 = dst->src[4]; // B  {d_state, n_group, n_seq_tokens, n_seqs}
    const lm_ggml_tensor * src5 = dst->src[5]; // C  {d_state, n_group, n_seq_tokens, n_seqs}
    const lm_ggml_tensor * src6 = dst->src[6]; // ids {n_seqs}

    const int ith = params->ith;
    const int nth = params->nth;

    const int64_t nc = src0->ne[0]; // d_state
    const int64_t nr = src0->ne[1]; // dim
    const int64_t nh = src1->ne[1]; // n_head
    const int64_t ng = src4->ne[1];
    const int64_t nt = src1->ne[2]; // number of tokens per sequence
    const int64_t ns = src1->ne[3]; // number of sequences in the batch

    // can't use lm_ggml_nbytes because src1 is not necessarily contiguous
    const int64_t s_off = lm_ggml_nelements(src1) * lm_ggml_element_size(src1);

    LM_GGML_ASSERT(lm_ggml_nelements(src1) + nc*nr*nh*ns == lm_ggml_nelements(dst));
    LM_GGML_ASSERT(src0->nb[0] == sizeof(float));
    LM_GGML_ASSERT(src1->nb[0] == sizeof(float));
    LM_GGML_ASSERT(src2->nb[0] == sizeof(float));
    LM_GGML_ASSERT(src3->nb[0] == sizeof(float));
    LM_GGML_ASSERT(src4->nb[0] == sizeof(float));
    LM_GGML_ASSERT(src5->nb[0] == sizeof(float));
    LM_GGML_ASSERT(src6->nb[0] == sizeof(int32_t));
    LM_GGML_ASSERT(nh % ng == 0);

    // heads per thread
    const int dh = (nh + nth - 1)/nth;

    // head range for this thread
    const int ih0 = dh*ith;
    const int ih1 = MIN(ih0 + dh, nh);

    const int32_t * ids = (const int32_t *) src6->data;

    for (int i3 = 0; i3 < ns; ++i3) {
        const float * s0 = (const float *) ((const char *) src0->data + ids[i3]*(src0->nb[3])); // {d_state, dim, nh, ns}
              float * s  = (      float *) ((      char *) dst->data  + i3*(src0->nb[3]) + s_off); // {d_state, dim, nh, ns}

        for (int i2 = 0; i2 < nt; ++i2) {
            const float * x  = (const float *) ((const char *) src1->data + i2*(src1->nb[2]) + i3*(src1->nb[3])); // {dim, nh, nt, ns}
            const float * dt = (const float *) ((const char *) src2->data + i2*(src2->nb[1]) + i3*(src2->nb[2])); // {nh, nt, ns}
            const float * A  = (const float *) ((const char *) src3->data); // {d_state, nh} or {1, nh}
            const float * B  = (const float *) ((const char *) src4->data + i2*(src4->nb[2]) + i3*(src4->nb[3])); // {d_state, ng, nt, ns}
            const float * C  = (const float *) ((const char *) src5->data + i2*(src5->nb[2]) + i3*(src5->nb[3])); // {d_state, ng, nt, ns}
                  float * y  = (      float *) ((      char *) dst->data + i2*(nh*nr*sizeof(float)) + i3*(nt*nh*nr*sizeof(float))); // {dim, nh, nt, ns}

            if (src3->ne[0] == 1) {
                // Mamba-2 has a scalar decay factor per head; dA can be outside the state-wise loop

                // n_head
                for (int h = ih0; h < ih1; ++h) {
                    // ref: https://github.com/state-spaces/mamba/blob/62db608da60f6fc790b8ed9f4b3225e95ca15fde/mamba_ssm/ops/triton/softplus.py#L16
                    const float dt_soft_plus = lm_ggml_compute_softplus_f32(dt[h]);
                    const float dA = expf(dt_soft_plus * A[h]);
                    const int g = h / (nh / ng); // repeat_interleave

                    // dim
                    for (int i1 = 0; i1 < nr; ++i1) {
                        const int ii = i1 + h*nr;
                        const float x_dt = x[ii] * dt_soft_plus;
                        float sumf = 0.0f;
#if defined(LM_GGML_SIMD)
    #if defined(__ARM_FEATURE_SVE)
                        const int lm_ggml_f32_epr = svcntw();
                        const int lm_ggml_f32_step = 1 * lm_ggml_f32_epr;

                        const int np = (nc & ~(lm_ggml_f32_step - 1));

                        LM_GGML_F32_VEC sum = LM_GGML_F32_VEC_ZERO;

                        LM_GGML_F32_VEC adA = LM_GGML_F32_VEC_SET1(dA);
                        LM_GGML_F32_VEC axdt = LM_GGML_F32_VEC_SET1(x_dt);

                        for (int i = 0; i < np; i += lm_ggml_f32_step) {
                            // TODO: maybe unroll more?
                            for (int j = 0; j < 1; j++) {
                                LM_GGML_F32_VEC t0 = LM_GGML_F32_VEC_LOAD(s0 + i + j*lm_ggml_f32_epr + ii*nc);
                                LM_GGML_F32_VEC t1 = LM_GGML_F32_VEC_LOAD(B + i + j*lm_ggml_f32_epr + g*nc);
                                LM_GGML_F32_VEC t2 = LM_GGML_F32_VEC_LOAD(C + i + j*lm_ggml_f32_epr + g*nc);

                                t0 = LM_GGML_F32_VEC_MUL(t0, adA);
                                t1 = LM_GGML_F32_VEC_MUL(t1, axdt);

                                t0 = LM_GGML_F32_VEC_ADD(t0, t1);

                                sum = LM_GGML_F32_VEC_FMA(sum, t0, t2);

                                LM_GGML_F32_VEC_STORE(s + i + j*lm_ggml_f32_epr + ii*nc, t0);
                            }
                        }

                        sumf = LM_GGML_F32xt_REDUCE_ONE(sum);
    #elif defined(__riscv_v_intrinsic)
                        // todo: RVV implementation
                        const int np = 0;
    #else
                        const int np = (nc & ~(LM_GGML_F32_STEP - 1));

                        LM_GGML_F32_VEC sum[LM_GGML_F32_ARR] = { LM_GGML_F32_VEC_ZERO };

                        LM_GGML_F32_VEC adA = LM_GGML_F32_VEC_SET1(dA);
                        LM_GGML_F32_VEC axdt = LM_GGML_F32_VEC_SET1(x_dt);

                        LM_GGML_F32_VEC ax[LM_GGML_F32_ARR];
                        LM_GGML_F32_VEC ay[LM_GGML_F32_ARR];
                        LM_GGML_F32_VEC az[LM_GGML_F32_ARR];

                        for (int i = 0; i < np; i += LM_GGML_F32_STEP) {
                            for (int j = 0; j < LM_GGML_F32_ARR; j++) {
                                ax[j] = LM_GGML_F32_VEC_LOAD(s0 + i + j*LM_GGML_F32_EPR + ii*nc);
                                ay[j] = LM_GGML_F32_VEC_LOAD(B + i + j*LM_GGML_F32_EPR + g*nc);
                                az[j] = LM_GGML_F32_VEC_LOAD(C + i + j*LM_GGML_F32_EPR + g*nc);

                                ax[j] = LM_GGML_F32_VEC_MUL(ax[j], adA);
                                ay[j] = LM_GGML_F32_VEC_MUL(ay[j], axdt);

                                ax[j] = LM_GGML_F32_VEC_ADD(ax[j], ay[j]);

                                sum[j] = LM_GGML_F32_VEC_FMA(sum[j], ax[j], az[j]);

                                LM_GGML_F32_VEC_STORE(s + i + j*LM_GGML_F32_EPR + ii*nc, ax[j]);
                            }
                        }

                        // reduce sum0..sum3 to sum0
                        LM_GGML_F32_VEC_REDUCE(sumf, sum);
    #endif
#else
                        const int np = 0;
#endif
                        // d_state
                        for (int i0 = np; i0 < nc; ++i0) {
                            const int i = i0 + ii*nc;
                            const int ig = i0 + g*nc;
                            // state = prev_state * dA + dB * x
                            const float state = (s0[i] * dA) + (B[ig] * x_dt);
                            // y = rowwise_dotprod(state, C)
                            sumf += state * C[ig];
                            s[i] = state;
                        }
                        y[ii] = sumf;
                    }
                }
            } else {
                // Mamba-1 has an element-wise decay factor for the states

                // n_head
                for (int h = ih0; h < ih1; ++h) {
                    // ref: https://github.com/state-spaces/mamba/blob/62db608da60f6fc790b8ed9f4b3225e95ca15fde/mamba_ssm/ops/triton/softplus.py#L16
                    const float dt_soft_plus = lm_ggml_compute_softplus_f32(dt[h]);
                    const int g = h / (nh / ng); // repeat_interleave

                    // dim
                    for (int i1 = 0; i1 < nr; ++i1) {
                        const int ii = i1 + h*nr;
                        const float x_dt = x[ii] * dt_soft_plus;
#if defined(__ARM_FEATURE_SVE)
                        svfloat32_t vx_dt = LM_GGML_F32_VEC_SET1(x_dt);
                        svfloat32_t vdt_soft_plus = LM_GGML_F32_VEC_SET1(dt_soft_plus);
                        svfloat32_t r1_vector = LM_GGML_F32_VEC_ZERO;

                        // d_state
                        // TODO: what happens when (d_state % svcntw()) != 0?
                        for (int64_t k = 0; k < nc; k += svcntw()) {
                            svfloat32_t vA = LM_GGML_F32_VEC_LOAD(&A[h*nc + k]);
                            svfloat32_t vB = LM_GGML_F32_VEC_LOAD(&B[k + g*nc]);
                            svfloat32_t vC = LM_GGML_F32_VEC_LOAD(&C[k + g*nc]);
                            svfloat32_t vs0 = LM_GGML_F32_VEC_LOAD(&s0[ii*nc + k]);

                            svfloat32_t t1 = LM_GGML_F32_VEC_MUL(vdt_soft_plus, vA);
                            t1 = exp_ps_sve(svptrue_b32(), t1);
                            svfloat32_t t2 = LM_GGML_F32_VEC_MUL(vx_dt, vB);

                            vs0 = LM_GGML_F32_VEC_FMA(t2, vs0, t1);
                            r1_vector = LM_GGML_F32_VEC_ADD(LM_GGML_F32_VEC_MUL(vs0, vC), r1_vector);

                            LM_GGML_F32_VEC_STORE(&s[ii*nc + k], vs0);
                        }
                        y[ii] = LM_GGML_F32xt_REDUCE_ONE(r1_vector);
#else
                        float sumf = 0.0f;
                        // NOTE: can't really use LM_GGML_SIMD here because d_state is usually 16
                        //       and also because expf is used within the loop.
                        // d_state
                        for (int i0 = 0; i0 < nc; ++i0) {
                            const int i = i0 + ii*nc;
                            const int ig = i0 + g*nc;
                            // state = prev_state * dA + dB * x
                            const float state = (s0[i] * expf(dt_soft_plus * A[i0 + h*nc])) + (B[ig] * x_dt);
                            // y = rowwise_dotprod(state, C)
                            sumf += state * C[ig];
                            s[i] = state;
                        }
                        y[ii] = sumf;
#endif
                    }
                }
            }
            // use the output as the source when it's not the first token-wise iteration
            s0 = s;
        }
    }
}

void lm_ggml_compute_forward_ssm_scan(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {
    switch (dst->src[0]->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_ssm_scan_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_win_part

static void lm_ggml_compute_forward_win_part_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {
    LM_GGML_UNUSED(params);

    const lm_ggml_tensor * src0 = dst->src[0];

    LM_GGML_TENSOR_LOCALS(int64_t, ne0, src0, ne)
    LM_GGML_TENSOR_LOCALS(int64_t, ne,  dst,  ne)

    const int32_t nep0 = ((const int32_t *)(dst->op_params))[0];
    const int32_t nep1 = ((const int32_t *)(dst->op_params))[1];
    const int32_t w    = ((const int32_t *)(dst->op_params))[2];

    assert(ne00 == ne0);
    assert(ne3  == nep0*nep1);

    // TODO: optimize / multi-thread
    for (int py = 0; py < nep1; ++py) {
        for (int px = 0; px < nep0; ++px) {
            const int64_t i3 = py*nep0 + px;
            for (int64_t i2 = 0; i2 < ne2; ++i2) {
                for (int64_t i1 = 0; i1 < ne1; ++i1) {
                    for (int64_t i0 = 0; i0 < ne0; ++i0) {
                        const int64_t i02 = py*w + i2;
                        const int64_t i01 = px*w + i1;
                        const int64_t i00 = i0;

                        const int64_t i = i3*ne2*ne1*ne0 + i2*ne1*ne0    + i1*ne0   + i0;
                        const int64_t j =                  i02*ne01*ne00 + i01*ne00 + i00;

                        if (py*w + i2 >= ne02 || px*w + i1 >= ne01) {
                            ((float *) dst->data)[i] = 0.0f;
                        } else {
                            ((float *) dst->data)[i] = ((float *) src0->data)[j];
                        }
                    }
                }
            }
        }
    }
}

void lm_ggml_compute_forward_win_part(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_win_part_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_win_unpart

static void lm_ggml_compute_forward_win_unpart_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {
    LM_GGML_UNUSED(params);

    const lm_ggml_tensor * src0 = dst->src[0];

    LM_GGML_TENSOR_LOCALS(int64_t, ne0, src0, ne)
    LM_GGML_TENSOR_LOCALS(int64_t, ne,  dst,  ne)

    const int32_t w = ((const int32_t *)(dst->op_params))[0];

    // padding
    const int px = (w - ne1%w)%w;
    //const int py = (w - ne2%w)%w;

    const int npx = (px + ne1)/w;
    //const int npy = (py + ne2)/w;

    assert(ne0 == ne00);

    // TODO: optimize / multi-thread
    for (int64_t i2 = 0; i2 < ne2; ++i2) {
        for (int64_t i1 = 0; i1 < ne1; ++i1) {
            for (int64_t i0 = 0; i0 < ne0; ++i0) {
                const int ip2 = i2/w;
                const int ip1 = i1/w;

                const int64_t i02 = i2%w;
                const int64_t i01 = i1%w;
                const int64_t i00 = i0;

                const int64_t i = (ip2*npx + ip1)*ne02*ne01*ne00 + i02*ne01*ne00 + i01*ne00 + i00;
                const int64_t j =                                  i2*ne1*ne0    + i1*ne0   + i0;

                ((float *) dst->data)[j] = ((float *) src0->data)[i];
            }
        }
    }
}

void lm_ggml_compute_forward_win_unpart(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_win_unpart_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

//lm_ggml_compute_forward_unary

void lm_ggml_compute_forward_unary(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_unary_op op = lm_ggml_get_unary_op(dst);

    switch (op) {
        case LM_GGML_UNARY_OP_ABS:
            {
                lm_ggml_compute_forward_abs(params, dst);
            } break;
        case LM_GGML_UNARY_OP_SGN:
            {
                lm_ggml_compute_forward_sgn(params, dst);
            } break;
        case LM_GGML_UNARY_OP_NEG:
            {
                lm_ggml_compute_forward_neg(params, dst);
            } break;
        case LM_GGML_UNARY_OP_STEP:
            {
                lm_ggml_compute_forward_step(params, dst);
            } break;
        case LM_GGML_UNARY_OP_TANH:
            {
                lm_ggml_compute_forward_tanh(params, dst);
            } break;
        case LM_GGML_UNARY_OP_ELU:
            {
                lm_ggml_compute_forward_elu(params, dst);
            } break;
        case LM_GGML_UNARY_OP_RELU:
            {
                lm_ggml_compute_forward_relu(params, dst);
            } break;
        case LM_GGML_UNARY_OP_SIGMOID:
            {
                lm_ggml_compute_forward_sigmoid(params, dst);
            } break;
        case LM_GGML_UNARY_OP_GELU:
            {
                lm_ggml_compute_forward_gelu(params, dst);
            } break;
        case LM_GGML_UNARY_OP_GELU_ERF:
            {
                lm_ggml_compute_forward_gelu_erf(params, dst);
            } break;
        case LM_GGML_UNARY_OP_GELU_QUICK:
            {
                lm_ggml_compute_forward_gelu_quick(params, dst);
            } break;
        case LM_GGML_UNARY_OP_SILU:
            {
                lm_ggml_compute_forward_silu(params, dst);
            } break;
        case LM_GGML_UNARY_OP_HARDSWISH:
            {
                lm_ggml_compute_forward_hardswish(params, dst);
            } break;
        case LM_GGML_UNARY_OP_HARDSIGMOID:
            {
                lm_ggml_compute_forward_hardsigmoid(params, dst);
            } break;
        case LM_GGML_UNARY_OP_EXP:
            {
                lm_ggml_compute_forward_exp(params, dst);
            } break;
        case LM_GGML_UNARY_OP_FLOOR:
            {
                lm_ggml_compute_forward_floor(params, dst);
            } break;
        case LM_GGML_UNARY_OP_CEIL:
            {
                lm_ggml_compute_forward_ceil(params, dst);
            } break;
        case LM_GGML_UNARY_OP_ROUND:
            {
                lm_ggml_compute_forward_round(params, dst);
            } break;
        case LM_GGML_UNARY_OP_TRUNC:
            {
                lm_ggml_compute_forward_trunc(params, dst);
            } break;
        case LM_GGML_UNARY_OP_XIELU:
            {
                lm_ggml_compute_forward_xielu(params, dst);
            } break;
        case LM_GGML_UNARY_OP_EXPM1:
            {
                lm_ggml_compute_forward_expm1(params, dst);
            } break;
        case LM_GGML_UNARY_OP_SOFTPLUS:
            {
                lm_ggml_compute_forward_softplus(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

//lm_ggml_compute_forward_glu

void lm_ggml_compute_forward_glu(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_glu_op op = lm_ggml_get_glu_op(dst);

    switch (op) {
        case LM_GGML_GLU_OP_REGLU:
            {
                lm_ggml_compute_forward_reglu(params, dst);
            } break;
        case LM_GGML_GLU_OP_GEGLU:
            {
                lm_ggml_compute_forward_geglu(params, dst);
            } break;
        case LM_GGML_GLU_OP_SWIGLU:
            {
                lm_ggml_compute_forward_swiglu(params, dst);
            } break;
        case LM_GGML_GLU_OP_SWIGLU_OAI:
            {
                lm_ggml_compute_forward_swiglu_oai(params, dst);
            } break;
        case LM_GGML_GLU_OP_GEGLU_ERF:
            {
                lm_ggml_compute_forward_geglu_erf(params, dst);
            } break;
        case LM_GGML_GLU_OP_GEGLU_QUICK:
            {
                lm_ggml_compute_forward_geglu_quick(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_get_rel_pos

static void lm_ggml_compute_forward_get_rel_pos_f16(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {
    LM_GGML_UNUSED(params);

    const lm_ggml_tensor * src0 = dst->src[0];

    // ref: https://github.com/facebookresearch/segment-anything/blob/main/segment_anything/modeling/image_encoder.py#L292-L322

    LM_GGML_TENSOR_UNARY_OP_LOCALS

    const int64_t w = ne1;

    lm_ggml_fp16_t * src0_data = (lm_ggml_fp16_t *) src0->data;
    lm_ggml_fp16_t * dst_data  = (lm_ggml_fp16_t *) dst->data;

    for (int64_t i2 = 0; i2 < ne2; ++i2) {
        for (int64_t i1 = 0; i1 < ne1; ++i1) {
            const int64_t pos = (w - i1 - 1) + i2;
            for (int64_t i0 = 0; i0 < ne0; ++i0) {
                dst_data[i2*ne1*ne0 + i1*ne0 + i0] = src0_data[pos*ne00 + i0];
            }
        }
    }
}

void lm_ggml_compute_forward_get_rel_pos(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F16:
        case LM_GGML_TYPE_BF16:
            {
                lm_ggml_compute_forward_get_rel_pos_f16(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_add_rel_pos

static void lm_ggml_compute_forward_add_rel_pos_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];
    const lm_ggml_tensor * src2 = dst->src[2];

    const bool inplace = (bool) ((int32_t *) dst->op_params)[0];
    if (!inplace) {
        if (params->ith == 0) {
            memcpy((char *) dst->data, (char *) src0->data, lm_ggml_nbytes(dst));
        }
        lm_ggml_barrier(params->threadpool);
    }
    // ref: https://github.com/facebookresearch/segment-anything/blob/main/segment_anything/modeling/image_encoder.py#L357-L359

    float * src1_data = (float *) src1->data;
    float * src2_data = (float *) src2->data;
    float * dst_data  = (float *) dst->data;

    const int64_t ne10 = src1->ne[0];
    const int64_t ne11 = src1->ne[1];
    const int64_t ne12 = src1->ne[2];
    const int64_t ne13 = src1->ne[3];

    const int ith = params->ith;
    const int nth = params->nth;

    // total patches in dst
    const int np = ne13;

    // patches per thread
    const int dp = (np + nth - 1)/nth;

    // patch range for this thread
    const int ip0 = dp*ith;
    const int ip1 = MIN(ip0 + dp, np);

    for (int64_t i13 = ip0; i13 < ip1; ++i13) {
        for (int64_t i12 = 0; i12 < ne12; ++i12) {
            for (int64_t i11 = 0; i11 < ne11; ++i11) {
                const int64_t jp1 = i13*ne12*ne11*ne10 + i12*ne11*ne10 + i11*ne10;
                for (int64_t i10 = 0; i10 < ne10; ++i10) {
                    const int64_t jp0  = jp1 + i10;
                    const float src1_e = src1_data[jp0];
                    const float src2_e = src2_data[jp0];

                    const int64_t jdh = jp0 * ne10;
                    const int64_t jdw = jdh - (ne10 - 1) * i10;

                    for (int64_t j = 0; j < ne10; ++j) {
                        dst_data[jdh + j     ] += src2_e;
                        dst_data[jdw + j*ne10] += src1_e;
                    }
                }
            }
        }
    }
}

void lm_ggml_compute_forward_add_rel_pos(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_add_rel_pos_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_rwkv_wkv6

static void lm_ggml_compute_forward_rwkv_wkv6_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {
    const int64_t T = dst->src[1]->ne[2];
    const int64_t C = dst->ne[0];
    const int64_t HEADS = dst->src[1]->ne[1];
    const int64_t n_seqs = dst->src[5]->ne[1];
    const int64_t head_size = C / HEADS;

    float * dst_data = (float *) dst->data;
    float * state = ((float *) dst->data) + C * T;

    const int ith = params->ith;
    const int nth = params->nth;

    const int h_start =  (HEADS * (ith    )) / nth;
    const int h_end   = ((HEADS * (ith + 1)) / nth < HEADS) ?
                         (HEADS * (ith + 1)) / nth : HEADS;

    float * k =          (float *) dst->src[0]->data;
    float * v =          (float *) dst->src[1]->data;
    float * r =          (float *) dst->src[2]->data;
    float * time_faaaa = (float *) dst->src[3]->data;
    float * time_decay = (float *) dst->src[4]->data;

    size_t t_stride = HEADS * head_size; // Same to C

    size_t h_stride = C / HEADS;
    LM_GGML_ASSERT(C % HEADS == 0); // C must be divisible by HEADS
    size_t h_stride_2d = head_size * head_size;

    if (ith == 0) {
        memset(dst_data, 0, T * C * sizeof(float));
    }
    lm_ggml_barrier(params->threadpool);


    #if defined(__AVX__) && !defined(__AVX512F__)
        #define LM_GGML_F32X LM_GGML_F32x8
        #define LM_GGML_F32X_SET1 LM_GGML_F32x8_SET1
        #define LM_GGML_F32X_LOAD LM_GGML_F32x8_LOAD
        #define LM_GGML_F32X_STORE LM_GGML_F32x8_STORE
        #define LM_GGML_F32X_MUL LM_GGML_F32x8_MUL
        #define LM_GGML_F32X_FMA LM_GGML_F32x8_FMA
        #define WKV_VECTOR_SIZE 8
    #elif defined(__AVX512F__)
        #define LM_GGML_F32X LM_GGML_F32x16
        #define LM_GGML_F32X_SET1 LM_GGML_F32x16_SET1
        #define LM_GGML_F32X_LOAD LM_GGML_F32x16_LOAD
        #define LM_GGML_F32X_STORE LM_GGML_F32x16_STORE
        #define LM_GGML_F32X_MUL LM_GGML_F32x16_MUL
        #define LM_GGML_F32X_FMA LM_GGML_F32x16_FMA
        #define WKV_VECTOR_SIZE 16
    #elif defined(__ARM_FEATURE_SVE) && defined(__aarch64__)
        #define LM_GGML_F32X LM_GGML_F32xt
        #define LM_GGML_F32X_SET1 LM_GGML_F32xt_SET1
        #define LM_GGML_F32X_LOAD LM_GGML_F32xt_LOAD
        #define LM_GGML_F32X_STORE LM_GGML_F32xt_STORE
        #define LM_GGML_F32X_MUL LM_GGML_F32xt_MUL
        #define LM_GGML_F32X_FMA LM_GGML_F32xt_FMA
        #define WKV_VECTOR_SIZE 8
    #elif defined(__ARM_NEON) && defined(__aarch64__)
        #define LM_GGML_F32X LM_GGML_F32x4
        #define LM_GGML_F32X_SET1 LM_GGML_F32x4_SET1
        #define LM_GGML_F32X_LOAD LM_GGML_F32x4_LOAD
        #define LM_GGML_F32X_STORE LM_GGML_F32x4_STORE
        #define LM_GGML_F32X_MUL LM_GGML_F32x4_MUL
        #define LM_GGML_F32X_FMA LM_GGML_F32x4_FMA
        #define WKV_VECTOR_SIZE 4
    #endif

    #ifdef WKV_VECTOR_SIZE
        int wkv_vector_size;
        #if defined(__ARM_FEATURE_SVE)
            wkv_vector_size = svcntw();
        #else
            wkv_vector_size = WKV_VECTOR_SIZE;
        #endif
        const int64_t vec_count = head_size / wkv_vector_size;

        for (int64_t t = 0; t < T; t++) {
            size_t t_offset = t * t_stride;
            size_t state_offset = head_size * C * (t / (T / n_seqs));
            float * state_cur = state + state_offset;
            float * state_prev = t % (T / n_seqs) ? state_cur : (float*)dst->src[5]->data + state_offset;

            for (int64_t h = h_start; h < h_end; h++) {
                size_t h_offset = h * h_stride;
                size_t t_h_offset = t_offset + h_offset;
                size_t h_2d_offset = h * h_stride_2d;

                for (int64_t i = 0; i < head_size; i++) {
                    size_t t_h_i_offset = t_h_offset + i;
                    size_t h_i_offset = h_offset + i;
                    size_t h_2d_i_offset = h_2d_offset + i * h_stride;

                    float k_val = k[t_h_i_offset];
                    float r_val = r[t_h_i_offset];
                    float time_faaaa_val = time_faaaa[h_i_offset];
                    float time_decay_val = time_decay[t_h_i_offset];

                    // Broadcast scalar values to vectors
                    LM_GGML_F32X k_vec = LM_GGML_F32X_SET1(k_val);
                    LM_GGML_F32X r_vec = LM_GGML_F32X_SET1(r_val);
                    LM_GGML_F32X time_faaaa_vec = LM_GGML_F32X_SET1(time_faaaa_val);
                    LM_GGML_F32X time_decay_vec = LM_GGML_F32X_SET1(time_decay_val);

                    for (int64_t j = 0; j < vec_count; j++) {
                        size_t base_j = j * wkv_vector_size;
                        size_t t_h_j_offset = t_h_offset + base_j;
                        size_t h_2d_i_j_offset = h_2d_i_offset + base_j;

                        // Load x elements at once
                        LM_GGML_F32X v_vec = LM_GGML_F32X_LOAD(&v[t_h_j_offset]);
                        LM_GGML_F32X prev_state_vec = LM_GGML_F32X_LOAD(&state_prev[h_2d_i_j_offset]);
                        LM_GGML_F32X dst_vec = LM_GGML_F32X_LOAD(&dst_data[t_h_j_offset]);

                        // Compute kv = v * k
                        LM_GGML_F32X kv_vec = LM_GGML_F32X_MUL(v_vec, k_vec);

                        // Compute temp = kv * time_faaaa + prev_state
                        LM_GGML_F32X temp_vec = LM_GGML_F32X_FMA(prev_state_vec, kv_vec, time_faaaa_vec);

                        // Update dst: dst += temp * r
                        dst_vec = LM_GGML_F32X_FMA(dst_vec, temp_vec, r_vec);
                        LM_GGML_F32X_STORE(&dst_data[t_h_j_offset], dst_vec);

                        // Update state: state = prev_state * time_decay + kv
                        LM_GGML_F32X new_state_vec = LM_GGML_F32X_FMA(kv_vec, prev_state_vec, time_decay_vec);
                        LM_GGML_F32X_STORE(&state_cur[h_2d_i_j_offset], new_state_vec);
                    }

                    // Handle remaining elements, this will not be used.
                    for (int64_t j = vec_count * wkv_vector_size; j < head_size; j++) {
                        size_t t_h_j_offset = t_h_offset + j;
                        size_t h_2d_i_j_offset = h_2d_i_offset + j;
                        float v_val = v[t_h_j_offset];
                        float kv_val = v_val * k_val;
                        float prev_state_val = state_prev[h_2d_i_j_offset];
                        float temp_val = kv_val * time_faaaa_val + prev_state_val;
                        dst_data[t_h_j_offset] += temp_val * r_val;
                        state_cur[h_2d_i_j_offset] = prev_state_val * time_decay_val + kv_val;
                    }
                }
            }
        }

    #else
        // basically fused operations:
        // dst = r @ (time_faaaa * (k @ v) + state),
        // state = time_decay * state + (k @ v),
        // recursive through each token
        for (int64_t t = 0; t < T; t++) {
            size_t t_offset = t * t_stride;
            size_t state_offset = head_size * C * (t / (T / n_seqs));
            float * state_cur = state + state_offset;
            float * state_prev = t % (T / n_seqs) ? state_cur : (float*)dst->src[5]->data + state_offset;

            for (int64_t h = h_start; h < h_end; h++) {
                size_t h_offset = h * h_stride;
                size_t t_h_offset = t_offset + h_offset;
                size_t h_2d_offset = h * h_stride_2d;

                for (int64_t i = 0; i < head_size; i++) {
                    size_t t_h_i_offset = t_h_offset + i;
                    size_t h_i_offset = h_offset + i;
                    size_t h_2d_i_offset = h_2d_offset + i * h_stride;

                    float k_val = k[t_h_i_offset];
                    float r_val = r[t_h_i_offset];
                    float time_faaaa_val = time_faaaa[h_i_offset];
                    // RWKV v6: different time_decay for each token.
                    float time_decay_val = time_decay[t_h_i_offset];

                    for (int64_t j = 0; j < head_size; j++) {
                        size_t t_h_j_offset = t_h_offset + j;
                        size_t h_2d_i_j_offset = h_2d_i_offset + j;

                        float v_val = v[t_h_j_offset];
                        float kv_val = v_val * k_val;
                        float prev_state_val = state_prev[h_2d_i_j_offset];
                        float temp_val = kv_val * time_faaaa_val + prev_state_val;
                        dst_data[t_h_j_offset] += temp_val * r_val;
                        state_cur[h_2d_i_j_offset] = prev_state_val * time_decay_val + kv_val;
                    }
                }
            }
        }
    #endif
}


void lm_ggml_compute_forward_rwkv_wkv6(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_rwkv_wkv6_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_gla

static void lm_ggml_compute_forward_gla_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {
    const int64_t T = dst->src[1]->ne[2];
    const int64_t C = dst->ne[0];
    const int64_t HEADS = dst->src[1]->ne[1];
    const int64_t n_seqs = dst->src[4]->ne[1];
    const int64_t head_size = C / HEADS;
    const float scale = lm_ggml_get_op_params_f32(dst, 0);

    float * dst_data = (float *) dst->data;
    float * state = ((float *) dst->data) + C * T;

    const int ith = params->ith;
    const int nth = params->nth;

    const int h_start =  (HEADS * (ith    )) / nth;
    const int h_end   = ((HEADS * (ith + 1)) / nth < HEADS) ?
                         (HEADS * (ith + 1)) / nth : HEADS;

    float * k = (float *) dst->src[0]->data;
    float * v = (float *) dst->src[1]->data;
    float * q = (float *) dst->src[2]->data;
    float * g = (float *) dst->src[3]->data;

    size_t t_stride = HEADS * head_size; // Same to C

    size_t h_stride = C / HEADS;
    LM_GGML_ASSERT(C % HEADS == 0); // C must be divisible by HEADS
    size_t h_stride_2d = head_size * head_size;

    if (ith == 0) {
        memset(dst_data, 0, T * C * sizeof(float));
    }
    lm_ggml_barrier(params->threadpool);


    #if defined(__AVX__) && !defined(__AVX512F__)
        #define LM_GGML_F32X LM_GGML_F32x8
        #define LM_GGML_F32X_SET1 LM_GGML_F32x8_SET1
        #define LM_GGML_F32X_LOAD LM_GGML_F32x8_LOAD
        #define LM_GGML_F32X_STORE LM_GGML_F32x8_STORE
        #define LM_GGML_F32X_MUL LM_GGML_F32x8_MUL
        #define LM_GGML_F32X_FMA LM_GGML_F32x8_FMA
        #define GLA_VECTOR_SIZE 8
    #elif defined(__AVX512F__)
        #define LM_GGML_F32X LM_GGML_F32x16
        #define LM_GGML_F32X_SET1 LM_GGML_F32x16_SET1
        #define LM_GGML_F32X_LOAD LM_GGML_F32x16_LOAD
        #define LM_GGML_F32X_STORE LM_GGML_F32x16_STORE
        #define LM_GGML_F32X_MUL LM_GGML_F32x16_MUL
        #define LM_GGML_F32X_FMA LM_GGML_F32x16_FMA
        #define GLA_VECTOR_SIZE 16
    #elif defined(__ARM_FEATURE_SVE) && defined(__aarch64__)
        #define LM_GGML_F32X LM_GGML_F32xt
        #define LM_GGML_F32X_SET1 LM_GGML_F32xt_SET1
        #define LM_GGML_F32X_LOAD LM_GGML_F32xt_LOAD
        #define LM_GGML_F32X_STORE LM_GGML_F32xt_STORE
        #define LM_GGML_F32X_MUL LM_GGML_F32xt_MUL
        #define LM_GGML_F32X_FMA LM_GGML_F32xt_FMA
        #define GLA_VECTOR_SIZE 8
    #elif defined(__ARM_NEON) && defined(__aarch64__)
        #define LM_GGML_F32X LM_GGML_F32x4
        #define LM_GGML_F32X_SET1 LM_GGML_F32x4_SET1
        #define LM_GGML_F32X_LOAD LM_GGML_F32x4_LOAD
        #define LM_GGML_F32X_STORE LM_GGML_F32x4_STORE
        #define LM_GGML_F32X_MUL LM_GGML_F32x4_MUL
        #define LM_GGML_F32X_FMA LM_GGML_F32x4_FMA
        #define GLA_VECTOR_SIZE 4
    #endif

    #ifdef GLA_VECTOR_SIZE
        int gla_vector_size;
        #if defined(__ARM_FEATURE_SVE)
            gla_vector_size = svcntw();
        #else
            gla_vector_size = GLA_VECTOR_SIZE;
        #endif
        const int64_t vec_count = head_size / gla_vector_size;

        for (int64_t t = 0; t < T; t++) {
            size_t t_offset = t * t_stride;
            size_t state_offset = head_size * C * (t / (T / n_seqs));
            float * state_cur = state + state_offset;
            float * state_prev = t % (T / n_seqs) ? state_cur : (float*)dst->src[4]->data + state_offset;

            for (int64_t h = h_start; h < h_end; h++) {
                size_t h_offset = h * h_stride;
                size_t t_h_offset = t_offset + h_offset;
                size_t h_2d_offset = h * h_stride_2d;

                for (int64_t i = 0; i < head_size; i++) {
                    size_t t_h_i_offset = t_h_offset + i;
                    size_t h_2d_i_offset = h_2d_offset + i * h_stride;

                    float k_val = k[t_h_i_offset];
                    float q_val = q[t_h_i_offset] * scale;
                    float g_val = g[t_h_i_offset];

                    // Broadcast scalar values to vectors
                    LM_GGML_F32X k_vec = LM_GGML_F32X_SET1(k_val);
                    LM_GGML_F32X q_vec = LM_GGML_F32X_SET1(q_val);
                    LM_GGML_F32X g_vec = LM_GGML_F32X_SET1(g_val);

                    for (int64_t j = 0; j < vec_count; j++) {
                        size_t base_j = j * gla_vector_size;
                        size_t t_h_j_offset = t_h_offset + base_j;
                        size_t h_2d_i_j_offset = h_2d_i_offset + base_j;

                        // Load x elements at once
                        LM_GGML_F32X v_vec = LM_GGML_F32X_LOAD(&v[t_h_j_offset]);
                        LM_GGML_F32X prev_state_vec = LM_GGML_F32X_LOAD(&state_prev[h_2d_i_j_offset]);
                        LM_GGML_F32X dst_vec = LM_GGML_F32X_LOAD(&dst_data[t_h_j_offset]);

                        // Compute kv = v * k
                        LM_GGML_F32X kv_vec = LM_GGML_F32X_MUL(v_vec, k_vec);

                        // Compute temp = prev_state * g + kv
                        LM_GGML_F32X temp_vec = LM_GGML_F32X_FMA(kv_vec, prev_state_vec, g_vec);

                        // Update dst: dst += temp * q
                        dst_vec = LM_GGML_F32X_FMA(dst_vec, temp_vec, q_vec);
                        LM_GGML_F32X_STORE(&dst_data[t_h_j_offset], dst_vec);

                        // Update state
                        LM_GGML_F32X_STORE(&state_cur[h_2d_i_j_offset], temp_vec);
                    }

                    // Handle remaining elements, this will not be used.
                    for (int64_t j = vec_count * gla_vector_size; j < head_size; j++) {
                        size_t t_h_j_offset = t_h_offset + j;
                        size_t h_2d_i_j_offset = h_2d_i_offset + j;
                        float v_val = v[t_h_j_offset];
                        float kv_val = v_val * k_val;
                        float prev_state_val = state_prev[h_2d_i_j_offset];
                        float temp_val = kv_val + prev_state_val * g_val;
                        dst_data[t_h_j_offset] += temp_val * q_val;
                        state_cur[h_2d_i_j_offset] = temp_val;
                    }
                }
            }
        }

    #else
        for (int64_t t = 0; t < T; t++) {
            size_t t_offset = t * t_stride;
            size_t state_offset = head_size * C * (t / (T / n_seqs));
            float * state_cur = state + state_offset;
            float * state_prev = t % (T / n_seqs) ? state_cur : (float*)dst->src[4]->data + state_offset;

            for (int64_t h = h_start; h < h_end; h++) {
                size_t h_offset = h * h_stride;
                size_t t_h_offset = t_offset + h_offset;
                size_t h_2d_offset = h * h_stride_2d;

                for (int64_t i = 0; i < head_size; i++) {
                    size_t t_h_i_offset = t_h_offset + i;
                    size_t h_2d_i_offset = h_2d_offset + i * h_stride;

                    float k_val = k[t_h_i_offset];
                    float q_val = q[t_h_i_offset] * scale;
                    float g_val = g[t_h_i_offset];

                    for (int64_t j = 0; j < head_size; j++) {
                        size_t t_h_j_offset = t_h_offset + j;
                        size_t h_2d_i_j_offset = h_2d_i_offset + j;

                        float v_val = v[t_h_j_offset];
                        float kv_val = v_val * k_val;
                        float prev_state_val = state_prev[h_2d_i_j_offset];
                        float temp_val = prev_state_val * g_val + kv_val;
                        dst_data[t_h_j_offset] += temp_val * q_val;
                        state_cur[h_2d_i_j_offset] = temp_val;
                    }
                }
            }
        }
    #endif
}


void lm_ggml_compute_forward_gla(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_gla_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

static void lm_ggml_compute_forward_solve_tri_f32(const struct lm_ggml_compute_params * params, struct lm_ggml_tensor * dst) {
    const struct lm_ggml_tensor * src0 = dst->src[0];  // A (lower triangular)
    const struct lm_ggml_tensor * src1 = dst->src[1];  // B (RHS)

    LM_GGML_TENSOR_BINARY_OP_LOCALS;

    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT(dst->type  == LM_GGML_TYPE_F32);

    LM_GGML_ASSERT(ne00 == ne01); // A must be square
    LM_GGML_ASSERT(ne0  == ne10); // solution cols == B cols
    LM_GGML_ASSERT(ne1  == ne11); // solution rows == B rows

    LM_GGML_ASSERT(ne02 == ne12 && ne12 == ne2);
    LM_GGML_ASSERT(ne03 == ne13 && ne13 == ne3);

    const int ith = params->ith;
    const int nth = params->nth;

    const int64_t k = ne10;   // number of RHS columns
    const int64_t n = ne11;   // A is n×n
    const int64_t nr = ne02 * ne03 * k; // we're parallelizing on columns here, so seq x token x column will be the unit

    // chunks per thread
    const int64_t dr = (nr + nth - 1)/nth;

    // chunk range for this thread
    const int64_t ir0 = dr*ith;
    const int64_t ir1 = MIN(ir0 + dr, nr);

    const float * A = (const float *) src0->data;  // [n, n, B1, B2]
    const float * B = (const float *) src1->data;  // [n, k, B1, B2]
          float * X = (      float *) dst->data;   // [n, k, B1, B2]

    for (int64_t ir = ir0; ir < ir1; ++ir) {
        const int64_t i03 = ir/(ne02*k);
        const int64_t i02 = (ir - i03*ne02*k)/k;
        const int64_t i01 = (ir - i03*ne02*k - i02*k);

        const float * A_batch = A + i02 * nb02 / sizeof(float) + i03 * nb03 / sizeof(float);
        const float * B_batch = B + i02 * nb12 / sizeof(float) + i03 * nb13 / sizeof(float);

        float * X_batch = X + i02 * nb2 / sizeof(float) + i03 * nb3 / sizeof(float);

        for (int64_t i00 = 0; i00 < n; ++i00) {
            float sum = 0.0f;
            for (int64_t t = 0; t < i00; ++t) {
                sum += A_batch[i00 * n + t] * X_batch[t * k + i01];
            }

            const float diag = A_batch[i00 * n + i00];
            assert(diag != 0.0f && "Zero diagonal in triangular matrix");

            X_batch[i00 * k + i01] = (B_batch[i00 * k + i01] - sum) / diag;
        }
    }
}

void lm_ggml_compute_forward_solve_tri(const struct lm_ggml_compute_params * params, struct lm_ggml_tensor * dst) {
    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    if (src0->type == LM_GGML_TYPE_F32 && src1->type == LM_GGML_TYPE_F32) {
        lm_ggml_compute_forward_solve_tri_f32(params, dst);
    } else {
        LM_GGML_ABORT("fatal error");
    }
}

// lm_ggml_compute_forward_gated_delta_net
static void lm_ggml_compute_forward_gated_delta_net_one_chunk(
    const lm_ggml_compute_params * params,
    lm_ggml_tensor * dst,
    int64_t ir0,
    int64_t ir1) {

    lm_ggml_tensor * src_q     = dst->src[0];
    lm_ggml_tensor * src_k     = dst->src[1];
    lm_ggml_tensor * src_v     = dst->src[2];
    lm_ggml_tensor * src_g     = dst->src[3];
    lm_ggml_tensor * src_beta  = dst->src[4];
    lm_ggml_tensor * src_state = dst->src[5];

    const int64_t S_v      = src_v->ne[0];
    const int64_t H        = src_v->ne[1];
    const int64_t n_tokens = src_v->ne[2];
    const int64_t n_seqs   = src_v->ne[3];

    LM_GGML_ASSERT(lm_ggml_is_contiguous_rows(src_q));
    LM_GGML_ASSERT(lm_ggml_is_contiguous_rows(src_k));
    LM_GGML_ASSERT(lm_ggml_is_contiguous_rows(src_v));
    LM_GGML_ASSERT(lm_ggml_is_contiguous(src_g));
    LM_GGML_ASSERT(lm_ggml_is_contiguous(src_beta));
    LM_GGML_ASSERT(lm_ggml_is_contiguous(src_state));

    LM_GGML_ASSERT(src_g->ne[0] == 1 || src_g->ne[0] == S_v);
    LM_GGML_ASSERT(src_beta->ne[0] == 1);

    LM_GGML_TENSOR_LOCALS(int64_t, neq, src_q, ne);
    LM_GGML_TENSOR_LOCALS(size_t,  nbq, src_q, nb);
    LM_GGML_TENSOR_LOCALS(int64_t, nek, src_k, ne);
    LM_GGML_TENSOR_LOCALS(size_t,  nbk, src_k, nb);
    LM_GGML_TENSOR_LOCALS(int64_t, nev, src_v, ne);
    LM_GGML_TENSOR_LOCALS(size_t,  nbv, src_v, nb);
    LM_GGML_TENSOR_LOCALS(int64_t, neg, src_g, ne);
    LM_GGML_TENSOR_LOCALS(size_t,  nbg, src_g, nb);
    LM_GGML_TENSOR_LOCALS(size_t,  nbb, src_beta, nb);

    const bool kda = (neg0 == S_v);

    // K (snapshot slot count) is an op param; state holds s0 only [S_v, S_v, H, n_seqs].
    const int64_t K = lm_ggml_get_op_params_i32(dst, 0);
    LM_GGML_ASSERT(K >= 1);
    // per-seq stride in floats (seq s starts at state + s * seq_stride)
    const int64_t state_seq_stride = src_state->nb[3] / sizeof(float);

    const int64_t per_thread = S_v + (K > 1 ? S_v * S_v : 0);
    const int ith = params->ith;

    float * delta       = (float *)params->wdata + ith * per_thread + CACHE_LINE_SIZE_F32;
    float * state_work  = K > 1 ? (delta + S_v) : nullptr;

    // output layout: [attn_scores | new_states]
    // attn_scores: S_v * H * n_tokens * n_seqs    floats
    // new_states:  S_v * S_v * H * n_seqs * K     floats  (K snapshot slots; last min(n_tokens, K))
    const int64_t attn_score_elems    = S_v * H * n_tokens * n_seqs;
    const int64_t state_size_per_snap = S_v * S_v * H * n_seqs;
    float * attn_out_base  = (float *)dst->data;
    float * state_out_base = (float *)dst->data + attn_score_elems;

    // snapshot slot mapping: slot 0 = most recent state, slot s = s tokens back.
    // When n_tokens < K only slots 0..n_tokens-1 are written; older slots are caller-owned.

    const float * state_in_base = (const float *)src_state->data;

  //const int64_t rq1 = nev1 / neq1;
  //const int64_t rk1 = nev1 / nek1;
    const int64_t rq3 = nev3 / neq3;
    const int64_t rk3 = nev3 / nek3;

    const float scale = 1.0f / sqrtf((float) S_v);

    for (int64_t ir = ir0; ir < ir1; ++ir) {
        const int64_t iv1 = ir % H; // head_index
        const int64_t iv3 = ir / H; // sequence

        const int64_t iq1 = iv1 % neq1;
        const int64_t ik1 = iv1 % nek1;

        const int64_t iq3 = iv3 / rq3;
        const int64_t ik3 = iv3 / rk3;

        // For K=1, write directly to the single output slot to avoid an extra memcpy at the end.
        // For K>1, work in scratch and copy out per-token when the slot is in range.
        float * s_out = (K > 1)
            ? state_work
            : state_out_base + (iv3 * H + iv1) * S_v * S_v;

        // copy input state into the working buffer and operate in-place
        // state layout [S_v, S_v, H, n_seqs]: seq iv3 starts at iv3 * state_seq_stride.
        const float * s_in = state_in_base + iv3 * state_seq_stride + iv1 * S_v * S_v;
        memcpy(s_out, s_in, S_v * S_v * sizeof(float));

        // attn output pointer for first token of this (head, seq)
        float * attn_data = attn_out_base + (iv3 * n_tokens * H + iv1) * S_v;

        for (int64_t t = 0; t < n_tokens; t++) {
            const float * q_d = (const float *)((const char *)src_q->data + iq3 * nbq3 + t * nbq2 + iq1 * nbq1);
            const float * k_d = (const float *)((const char *)src_k->data + ik3 * nbk3 + t * nbk2 + ik1 * nbk1);
            const float * v_d = (const float *)((const char *)src_v->data + iv3 * nbv3 + t * nbv2 + iv1 * nbv1);

            const float beta_val = *(const float *)((const char *)src_beta->data + iv3 * nbb3 + t * nbb2 + iv1 * nbb1);
            const float * g_d    =  (const float *)((const char *)src_g->data    + iv3 * nbg3 + t * nbg2 + iv1 * nbg1);

            // state is stored transposed: s_out[j*S_v + i] = S[i][j]
            // so row j of s_out = column j of S (contiguous access)

            if (kda) {
                // precompute exp(g) into delta scratch (reused below)
                for (int64_t i = 0; i < S_v; ++i) {
                    delta[i] = expf(g_d[i]);
                }
                // S[i][:] *= exp(g[i]) => for each row j of M: M[j][i] *= exp(g[i])
                for (int64_t j = 0; j < S_v; ++j) {
                    lm_ggml_vec_mul_f32(S_v, &s_out[j * S_v], &s_out[j * S_v], delta);
                }
            } else {
                lm_ggml_vec_scale_f32(S_v * S_v, s_out, expf(g_d[0]));
            }

            // delta[j] = sum_i S[i][j] * k[i] = dot(row j of M, k)
            for (int64_t j = 0; j < S_v; ++j) {
                float sum = 0.0f;
                lm_ggml_vec_dot_f32(S_v, &sum, 0, &s_out[j * S_v], 0, k_d, 0, 1);
                delta[j] = (v_d[j] - sum) * beta_val;
            }

            // outer product: S[i][j] += k[i] * delta[j] => M[j][i] += delta[j] * k[i]
            for (int64_t j = 0; j < S_v; ++j) {
                lm_ggml_vec_mad_f32(S_v, &s_out[j * S_v], k_d, delta[j]);
            }

            // attn_out[j] = sum_i S[i][j] * q[i] = dot(row j of M, q)
            for (int64_t j = 0; j < S_v; ++j) {
                float sum = 0.0f;
                lm_ggml_vec_dot_f32(S_v, &sum, 0, &s_out[j * S_v], 0, q_d, 0, 1);
                attn_data[j] = sum * scale;
            }

            attn_data += S_v * H; // advance to next token

            if (K > 1) {
                const int64_t target_slot = n_tokens - 1 - t;
                if (target_slot >= 0 && target_slot < K) {
                    float * curr_state_o = state_out_base + target_slot * state_size_per_snap +
                                     (iv3 * H + iv1) * S_v * S_v;
                    memcpy(curr_state_o, s_out, S_v * S_v * sizeof(float));
                }
            }
        }
    }
}


static void lm_ggml_compute_forward_gated_delta_net_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    lm_ggml_tensor * V = dst->src[2];
    int64_t nr = V->ne[1] * V->ne[3];

    // disable for NUMA
    const bool disable_chunking = lm_ggml_is_numa();

    int nth = params->nth;
    int ith = params->ith;

    // 4x chunks per thread
    int nth_scaled = nth * 4;
    int64_t chunk_size = (nr + nth_scaled - 1) / nth_scaled;
    int64_t nchunk     = (nr + chunk_size - 1) / chunk_size;

    if (nth == 1 || nchunk < nth || disable_chunking) {
      nchunk = nth;
    }

    if (ith == 0) {
      lm_ggml_threadpool_chunk_set(params->threadpool, nth);
    }

    lm_ggml_barrier(params->threadpool);

    const int64_t dr = (nr + nchunk - 1) / nchunk;

    int current_chunk = ith;

    while (current_chunk < nchunk) {
        const int64_t ir0 = dr * current_chunk;
        const int64_t ir1 = MIN(ir0 + dr, nr);

        lm_ggml_compute_forward_gated_delta_net_one_chunk(params, dst, ir0, ir1);
        current_chunk = lm_ggml_threadpool_chunk_add(params->threadpool, 1);
    }
}

void lm_ggml_compute_forward_gated_delta_net(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {
    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_gated_delta_net_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_rwkv_wkv7

static void lm_ggml_compute_forward_rwkv_wkv7_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {
    const int64_t T = dst->src[1]->ne[2];
    const int64_t C = dst->ne[0];
    const int64_t HEADS = dst->src[1]->ne[1];
    const int64_t n_seqs = dst->src[6]->ne[1];
    const int64_t head_size = C / HEADS;

    float * dst_data = (float *) dst->data;
    float * state = ((float *) dst->data) + C * T;

    const int ith = params->ith;
    const int nth = params->nth;

    const int h_start =  (HEADS * (ith    )) / nth;
    const int h_end   = ((HEADS * (ith + 1)) / nth < HEADS) ?
                         (HEADS * (ith + 1)) / nth : HEADS;

    float * r = (float *) dst->src[0]->data;
    float * w = (float *) dst->src[1]->data;
    float * k = (float *) dst->src[2]->data;
    float * v = (float *) dst->src[3]->data;
    float * a = (float *) dst->src[4]->data;
    float * b = (float *) dst->src[5]->data;

    int64_t t_stride = HEADS * head_size; // Same to C

    int64_t h_stride = C / HEADS;
    LM_GGML_ASSERT(C % HEADS == 0); // C must be divisible by HEADS
    int64_t h_stride_2d = head_size * head_size;

    #if defined(LM_GGML_SIMD)
        #if defined(__ARM_FEATURE_SVE) || defined(__riscv_v_intrinsic)
            // scalar Route to scalar implementation       //TODO: Write SVE code and RVV code
            for (int64_t t = 0; t < T; t++) {
                int64_t t_offset = t * t_stride;
                int64_t state_offset = head_size * C * (t / (T / n_seqs));
                float * state_cur = state + state_offset;
                float * state_prev = t % (T / n_seqs) ? state_cur : (float*)dst->src[6]->data + state_offset;

                for (int64_t h = h_start; h < h_end; h++) {
                    int64_t h_offset = h * h_stride;
                    int64_t t_h_offset = t_offset + h_offset;
                    int64_t h_2d_offset = h * h_stride_2d;

                    for (int64_t i = 0; i < head_size; i++) {
                        int64_t t_h_i_offset = t_h_offset + i;
                        int64_t h_2d_i_offset = h_2d_offset + i * h_stride;

                        float v_val = v[t_h_i_offset];

                        float sa = 0, result = 0;
                        for (int64_t j = 0; j < head_size; j++) {
                            sa += a[t_h_offset + j] * state_prev[h_2d_i_offset + j];
                        }

                        for (int64_t j = 0; j < head_size; j++) {
                            int64_t t_h_j_offset = t_h_offset + j;
                            int64_t h_2d_i_j_offset = h_2d_i_offset + j;

                            float r_val = r[t_h_j_offset];
                            float w_val = w[t_h_j_offset];
                            float k_val = k[t_h_j_offset];
                            float b_val = b[t_h_j_offset];
                            float kv_val = v_val * k_val;
                            float prev_state_val = state_prev[h_2d_i_j_offset];
                            state_cur[h_2d_i_j_offset] = prev_state_val * w_val + kv_val + sa * b_val;
                            result += state_cur[h_2d_i_j_offset] * r_val;
                        }
                        dst_data[t_h_i_offset] = result;
                    }
                }
            }
        #else
            for (int64_t t = 0; t < T; t++) {
                int64_t t_offset = t * t_stride;
                int64_t state_offset = head_size * C * (t / (T / n_seqs));
                float * state_cur = state + state_offset;
                float * state_prev = t % (T / n_seqs) ? state_cur : (float*)dst->src[6]->data + state_offset;

                for (int64_t h = h_start; h < h_end; h++) {
                    int64_t h_offset = h * h_stride;
                    int64_t t_h_offset = t_offset + h_offset;
                    int64_t h_2d_offset = h * h_stride_2d;

                    for (int64_t ii = 0; ii < head_size; ii++) {
                        int64_t t_h_i_offset = t_h_offset + ii;
                        int64_t h_2d_i_offset = h_2d_offset + ii * h_stride;

                        LM_GGML_F32_VEC v_vec = LM_GGML_F32_VEC_SET1(v[t_h_i_offset]);

                        float sa = 0;
                        {
                            LM_GGML_F32_VEC sum[LM_GGML_F32_ARR] = { LM_GGML_F32_VEC_ZERO };
                            LM_GGML_F32_VEC ax[LM_GGML_F32_ARR];
                            LM_GGML_F32_VEC ay[LM_GGML_F32_ARR];
                            for (int64_t j = 0; j < head_size; j += LM_GGML_F32_STEP) {
                                for (int64_t kk = 0; kk < LM_GGML_F32_ARR; kk++) {
                                    ax[kk] = LM_GGML_F32_VEC_LOAD(&a[t_h_offset + j + kk * LM_GGML_F32_EPR]);
                                    ay[kk] = LM_GGML_F32_VEC_LOAD(&state_prev[h_2d_i_offset + j + kk * LM_GGML_F32_EPR]);
                                    sum[kk] = LM_GGML_F32_VEC_FMA(sum[kk], ax[kk], ay[kk]);
                                }
                            }
                            LM_GGML_F32_VEC_REDUCE(sa, sum);
                        }

                        LM_GGML_F32_VEC sa_vec = LM_GGML_F32_VEC_SET1(sa);

                        int64_t j = 0;
                        LM_GGML_F32_VEC result_vec[LM_GGML_F32_ARR] = { LM_GGML_F32_VEC_ZERO };
                        for (; j < head_size; j += LM_GGML_F32_STEP) {
                            for (int64_t kk = 0; kk < LM_GGML_F32_ARR; kk++) {
                                int64_t t_h_j_offset = t_h_offset + j + kk * LM_GGML_F32_EPR;
                                int64_t h_2d_i_j_offset = h_2d_i_offset + j + kk * LM_GGML_F32_EPR;

                                LM_GGML_F32_VEC r_vec = LM_GGML_F32_VEC_LOAD(&r[t_h_j_offset]);
                                LM_GGML_F32_VEC w_vec = LM_GGML_F32_VEC_LOAD(&w[t_h_j_offset]);
                                LM_GGML_F32_VEC k_vec = LM_GGML_F32_VEC_LOAD(&k[t_h_j_offset]);
                                LM_GGML_F32_VEC b_vec = LM_GGML_F32_VEC_LOAD(&b[t_h_j_offset]);

                                k_vec = LM_GGML_F32_VEC_MUL(v_vec, k_vec);

                                LM_GGML_F32_VEC state_vec = LM_GGML_F32_VEC_LOAD(&state_prev[h_2d_i_j_offset]);
                                // kv + s * decay + sa * b
                                state_vec = LM_GGML_F32_VEC_FMA(k_vec, state_vec, w_vec);
                                state_vec = LM_GGML_F32_VEC_FMA(state_vec, sa_vec, b_vec);
                                LM_GGML_F32_VEC_STORE(&state_cur[h_2d_i_j_offset], state_vec);

                                result_vec[kk] = LM_GGML_F32_VEC_FMA(result_vec[kk], state_vec, r_vec);
                            }
                        }
                        LM_GGML_F32_VEC_REDUCE(dst_data[t_h_i_offset], result_vec);

                        // There shouldn't be left-overs though.
                        for (; j < head_size; j++) {
                            int64_t t_h_j_offset = t_h_offset + j;
                            int64_t h_2d_i_j_offset = h_2d_i_offset + j;

                            float r_val = r[t_h_j_offset];
                            float w_val = w[t_h_j_offset];
                            float k_val = k[t_h_j_offset];
                            float b_val = b[t_h_j_offset];
                            float kv_val = v[t_h_i_offset] * k_val;

                            float prev_state_val = state_prev[h_2d_i_j_offset];
                            state_cur[h_2d_i_j_offset] = prev_state_val * w_val + kv_val + sa * b_val;
                            dst_data[t_h_i_offset] += state_cur[h_2d_i_j_offset] * r_val;
                        }
                    }
                }
            }
        #endif
    #else
        for (int64_t t = 0; t < T; t++) {
            int64_t t_offset = t * t_stride;
            int64_t state_offset = head_size * C * (t / (T / n_seqs));
            float * state_cur = state + state_offset;
            float * state_prev = t % (T / n_seqs) ? state_cur : (float*)dst->src[6]->data + state_offset;

            for (int64_t h = h_start; h < h_end; h++) {
                int64_t h_offset = h * h_stride;
                int64_t t_h_offset = t_offset + h_offset;
                int64_t h_2d_offset = h * h_stride_2d;

                for (int64_t i = 0; i < head_size; i++) {
                    int64_t t_h_i_offset = t_h_offset + i;
                    int64_t h_2d_i_offset = h_2d_offset + i * h_stride;

                    float v_val = v[t_h_i_offset];

                    float sa = 0, result = 0;
                    for (int64_t j = 0; j < head_size; j++) {
                        sa += a[t_h_offset + j] * state_prev[h_2d_i_offset + j];
                    }

                    for (int64_t j = 0; j < head_size; j++) {
                        int64_t t_h_j_offset = t_h_offset + j;
                        int64_t h_2d_i_j_offset = h_2d_i_offset + j;

                        float r_val = r[t_h_j_offset];
                        float w_val = w[t_h_j_offset];
                        float k_val = k[t_h_j_offset];
                        float b_val = b[t_h_j_offset];
                        float kv_val = v_val * k_val;
                        float prev_state_val = state_prev[h_2d_i_j_offset];
                        state_cur[h_2d_i_j_offset] = prev_state_val * w_val + kv_val + sa * b_val;
                        result += state_cur[h_2d_i_j_offset] * r_val;
                    }
                    dst_data[t_h_i_offset] = result;
                }
            }
        }
    #endif
}


void lm_ggml_compute_forward_rwkv_wkv7(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_rwkv_wkv7_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_map_custom1

void lm_ggml_compute_forward_map_custom1(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * a = dst->src[0];

    struct lm_ggml_map_custom1_op_params p;
    memcpy(&p, dst->op_params, sizeof(p));

    p.fun(dst, a, params->ith, params->nth, p.userdata);
}

// lm_ggml_compute_forward_map_custom2

void lm_ggml_compute_forward_map_custom2(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * a = dst->src[0];
    const lm_ggml_tensor * b = dst->src[1];

    struct lm_ggml_map_custom2_op_params p;
    memcpy(&p, dst->op_params, sizeof(p));

    p.fun(dst, a, b, params->ith, params->nth, p.userdata);
}

// lm_ggml_compute_forward_map_custom3

void lm_ggml_compute_forward_map_custom3(
        const lm_ggml_compute_params * params,
              lm_ggml_tensor * dst) {

    const lm_ggml_tensor * a = dst->src[0];
    const lm_ggml_tensor * b = dst->src[1];
    const lm_ggml_tensor * c = dst->src[2];

    struct lm_ggml_map_custom3_op_params p;
    memcpy(&p, dst->op_params, sizeof(p));

    p.fun(dst, a, b, c, params->ith, params->nth, p.userdata);
}

// lm_ggml_compute_forward_custom

void lm_ggml_compute_forward_custom(
    const struct lm_ggml_compute_params * params,
          struct lm_ggml_tensor * dst) {

    struct lm_ggml_custom_op_params p;
    memcpy(&p, dst->op_params, sizeof(p));

    p.fun(dst, params->ith, params->nth, p.userdata);
}

// lm_ggml_compute_forward_cross_entropy_loss

static void lm_ggml_compute_forward_cross_entropy_loss_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(src0->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT(src0->nb[0] == lm_ggml_type_size(src0->type));
    LM_GGML_ASSERT(src1->nb[0] == lm_ggml_type_size(src1->type));
    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, src1));
    LM_GGML_ASSERT(lm_ggml_is_scalar(dst));
    LM_GGML_ASSERT(dst->type == LM_GGML_TYPE_F32);

    // TODO: handle transposed/permuted matrices
    const int64_t nc = src0->ne[0];
    const int64_t nr = lm_ggml_nrows(src0);

    const int ith = params->ith;
    const int nth = params->nth;

    float * sums =  (float *) params->wdata;
    float * st   = ((float *) params->wdata) + nth + ith*nc;
    float sum_thread = 0.0f;

    LM_GGML_ASSERT(params->wsize >= sizeof(float) * (nth + nth * nc));

    // rows per thread
    const int64_t dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int64_t ir0 = dr*ith;
    const int64_t ir1 = MIN(ir0 + dr, nr);

    for (int64_t i1 = ir0; i1 < ir1; ++i1) {
        const float * s0 = (const float *)((const char *) src0->data + i1*src0->nb[1]);
        const float * s1 = (const float *)((const char *) src1->data + i1*src1->nb[1]);

#ifndef NDEBUG
        for (int64_t i = 0; i < nc; ++i) {
            //printf("p[%d] = %f\n", i, p[i]);
            assert(!isnan(s0[i]));
            assert(!isnan(s1[i]));
        }
#endif // NDEBUG

        float max = -INFINITY;
        lm_ggml_vec_max_f32(nc, &max, s0);
        const lm_ggml_float sum_softmax = lm_ggml_vec_log_soft_max_f32(nc, st, s0, max);
        assert(sum_softmax >= 0.0);

        lm_ggml_vec_add1_f32(nc, st, st, -sum_softmax);
        lm_ggml_vec_mul_f32(nc, st, st, s1);

        float sum_st = 0.0f;
        lm_ggml_vec_sum_f32(nc, &sum_st, st);
        sum_thread += sum_st;

#ifndef NDEBUG
        for (int64_t i = 0; i < nc; ++i) {
            assert(!isnan(st[i]));
            assert(!isinf(st[i]));
        }
#endif // NDEBUG
    }
    sums[ith] = sum_thread;
    lm_ggml_barrier(params->threadpool);

    if (ith == 0) {
        float * dp = (float *) dst->data;
        lm_ggml_vec_sum_f32(nth, dp, sums);
        dp[0] *= -1.0f / (float) nr;
    }
}

void lm_ggml_compute_forward_cross_entropy_loss(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_cross_entropy_loss_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

// lm_ggml_compute_forward_cross_entropy_loss_back

static void lm_ggml_compute_forward_cross_entropy_loss_back_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * grad  = dst->src[0]; // gradient of forward pass output
    const lm_ggml_tensor * src0f = dst->src[1]; // src0 of forward pass
    const lm_ggml_tensor * src1f = dst->src[2]; // src1 of forward pass

    LM_GGML_ASSERT(lm_ggml_is_contiguous(dst));
    LM_GGML_ASSERT(lm_ggml_is_contiguous(src0f));
    LM_GGML_ASSERT(lm_ggml_is_contiguous(src1f));
    LM_GGML_ASSERT(lm_ggml_is_contiguous(grad));
    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0f, src1f) && lm_ggml_are_same_shape(src0f, dst));

    const int64_t ith = params->ith;
    const int64_t nth = params->nth;

    // TODO: handle transposed/permuted matrices
    const int64_t nc = src0f->ne[0];
    const int64_t nr = lm_ggml_nrows(src0f);

    // rows per thread
    const int64_t dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int64_t ir0 = dr*ith;
    const int64_t ir1 = MIN(ir0 + dr, nr);

    const float d_by_nr = ((const float *) grad->data)[0] / (float) nr;

    for (int64_t i1 = ir0; i1 < ir1; i1++) {
        float       * ds0 = (float       *)((char       *) dst->data   + i1*dst->nb[1]);
        const float * s0  = (const float *)((const char *) src0f->data + i1*src0f->nb[1]);
        const float * s1  = (const float *)((const char *) src1f->data + i1*src1f->nb[1]);

#ifndef NDEBUG
        for (int64_t i = 0; i < nc; ++i) {
            //printf("p[%d] = %f\n", i, p[i]);
            assert(!isnan(s0[i]));
            assert(!isnan(s1[i]));
        }
#endif // NDEBUG

        // soft_max
        float max = -INFINITY;
        lm_ggml_vec_max_f32(nc, &max, s0);
        const lm_ggml_float sum = lm_ggml_vec_soft_max_f32(nc, ds0, s0, max);
        assert(sum > 0.0);
        lm_ggml_vec_scale_f32(nc, ds0, 1.0/sum);

        // grad(src0f) = (softmax(src0f) - src1f) * grad(cross_entropy_loss(src0f, src1f)) / nr
        lm_ggml_vec_sub_f32(nc, ds0, ds0, s1);
        lm_ggml_vec_scale_f32(nc, ds0, d_by_nr);

#ifndef NDEBUG
        for (int64_t i = 0; i < nc; ++i) {
            assert(!isnan(ds0[i]));
            assert(!isinf(ds0[i]));
        }
#endif // NDEBUG
    }
}

void lm_ggml_compute_forward_cross_entropy_loss_back(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_cross_entropy_loss_back_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

static void lm_ggml_compute_forward_opt_step_adamw_f32(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0         = dst->src[0];
    const lm_ggml_tensor * src0_grad    = dst->src[1];
    const lm_ggml_tensor * src0_grad_m  = dst->src[2];
    const lm_ggml_tensor * src0_grad_v  = dst->src[3];
    const lm_ggml_tensor * adamw_params = dst->src[4];

    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, src0_grad));
    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, src0_grad_m));
    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, src0_grad_v));
    LM_GGML_ASSERT(lm_ggml_nelements(adamw_params) == 7);

    const int ith = params->ith;
    const int nth = params->nth;

    const int nr  = lm_ggml_nrows(src0);

    LM_GGML_TENSOR_UNARY_OP_LOCALS
    LM_GGML_ASSERT(nb00 == sizeof(float));

    // rows per thread
    const int dr = (nr + nth - 1)/nth;

    // row range for this thread
    const int ir0 = dr*ith;
    const int ir1 = MIN(ir0 + dr, nr);

    const float * adamw_params_ptr = lm_ggml_get_data_f32(adamw_params);

    const float alpha  = adamw_params_ptr[0];
    const float beta1  = adamw_params_ptr[1];
    const float beta2  = adamw_params_ptr[2];
    const float eps    = adamw_params_ptr[3];
    const float wd     = adamw_params_ptr[4];
    const float beta1h = adamw_params_ptr[5];
    const float beta2h = adamw_params_ptr[6];
    const float keep   = 1.f - alpha * wd;
    for (int ir = ir0; ir < ir1; ++ir) {
        const int64_t i03 = ir/(ne02*ne01);
        const int64_t i02 = (ir - i03*ne02*ne01)/ne01;
        const int64_t i01 = (ir - i03*ne02*ne01 - i02*ne01);

        const size_t offset = i03*nb03 + i02*nb02 + i01*nb01;

        float       * w = (float       *) ((char       *) src0->data        + offset); // weight
        const float * g = (const float *) ((const char *) src0_grad->data   + offset); // grad
        float       * m = (float       *) ((char       *) src0_grad_m->data + offset);
        float       * v = (float       *) ((char       *) src0_grad_v->data + offset);

        for (int i00 = 0; i00 < ne00; ++i00) {
            m[i00] = m[i00]*beta1 +        g[i00]*(1.0f - beta1);
            v[i00] = v[i00]*beta2 + g[i00]*g[i00]*(1.0f - beta2);

            const float mh =       m[i00]*beta1h;
            const float vh = sqrtf(v[i00]*beta2h) + eps;

            // The weight decay is applied independently of the Adam momenta m and v.
            // This is NOT equivalent to l2 regularization that adds w[i00]*w[i00] to the loss.
            // See: https://arxiv.org/pdf/1711.05101v3.pdf
            w[i00] = w[i00] * keep - alpha * mh / vh;
        }
    }
}

void lm_ggml_compute_forward_opt_step_adamw(
        const lm_ggml_compute_params * params,
        lm_ggml_tensor * dst) {

    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_opt_step_adamw_f32(params, dst);
            } break;
        default:
            {
                LM_GGML_ABORT("fatal error");
            }
    }
}

static void lm_ggml_compute_forward_opt_step_sgd_f32(const lm_ggml_compute_params * params, lm_ggml_tensor * dst) {
    const lm_ggml_tensor * src0       = dst->src[0];
    const lm_ggml_tensor * src0_grad  = dst->src[1];
    const lm_ggml_tensor * sgd_params = dst->src[2];

    LM_GGML_ASSERT(lm_ggml_are_same_shape(src0, src0_grad));
    LM_GGML_ASSERT(lm_ggml_nelements(sgd_params) == 2);

    const int ith = params->ith;
    const int nth = params->nth;

    const int nr = lm_ggml_nrows(src0);

    LM_GGML_TENSOR_UNARY_OP_LOCALS
    LM_GGML_ASSERT(nb00 == sizeof(float));

    // rows per thread
    const int dr = (nr + nth - 1) / nth;

    // row range for this thread
    const int ir0 = dr * ith;
    const int ir1 = MIN(ir0 + dr, nr);

    // using adamw param subset we care about - alpha, wd - could have a separate struct
    const float * sgd_params_ptr   = lm_ggml_get_data_f32(sgd_params);
    const float   alpha            = sgd_params_ptr[0];
    const float   keep             = 1.f - alpha * sgd_params_ptr[1];

    for (int ir = ir0; ir < ir1; ++ir) {
        const int64_t i03 = ir / (ne02 * ne01);
        const int64_t i02 = (ir - i03 * ne02 * ne01) / ne01;
        const int64_t i01 = (ir - i03 * ne02 * ne01 - i02 * ne01);

        const size_t offset = i03 * nb03 + i02 * nb02 + i01 * nb01;

        float *       w = (float *) ((char *) src0->data + offset);                   // weight
        const float * g = (const float *) ((const char *) src0_grad->data + offset);  // grad

        for (int i00 = 0; i00 < ne00; ++i00) {
            w[i00] = w[i00] * keep - alpha * g[i00];
        }
    }
}

void lm_ggml_compute_forward_opt_step_sgd(const lm_ggml_compute_params * params, lm_ggml_tensor * dst) {
    const lm_ggml_tensor * src0 = dst->src[0];

    switch (src0->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_opt_step_sgd_f32(params, dst);
            }
            break;
        default:
            {
                LM_GGML_ABORT("fatal error - sgd is F32 only");
            }
    }
}

static void lm_ggml_compute_forward_fwht_f32(const lm_ggml_compute_params * params, lm_ggml_tensor * dst) {
    const lm_ggml_tensor * src0 = dst->src[0];
    const lm_ggml_tensor * src1 = dst->src[1];

    LM_GGML_ASSERT(src1->type == LM_GGML_TYPE_F32);
    LM_GGML_ASSERT(dst->type == LM_GGML_TYPE_F32);

    LM_GGML_TENSOR_BINARY_OP_LOCALS

    const int ith = params->ith;
    const int nth = params->nth;

    const int64_t n = ne10;
    LM_GGML_ASSERT((n & (n - 1)) == 0); // must be power of 2

    const int64_t nr = ne11 * ne12 * ne13;
    const int64_t rows_per_thread = (nr + nth - 1) / nth;
    const int64_t start_row = ith * rows_per_thread;
    const int64_t end_row = MIN(start_row + rows_per_thread, nr);

    const float scale = 1.0f / sqrtf((float)n);

#if defined(LM_GGML_SIMD)
    const LM_GGML_F32_VEC v_minus_one = LM_GGML_F32_VEC_SET1(-1.0f);
#endif

    for (int64_t r = start_row; r < end_row; r++) {
        const int64_t i13 = r / (ne11 * ne12);
        const int64_t i12 = (r - i13 * ne11 * ne12) / ne11;
        const int64_t i11 = r - i13 * ne11 * ne12 - i12 * ne11;

        const float * src_row = (const float *) ((const char *) src1->data + i11 * nb11 + i12 * nb12 + i13 * nb13);
        float * dst_row = (float *) ((char *) dst->data + i11 * nb1 + i12 * nb2 + i13 * nb3);

        for (int64_t j = 0; j < n; j++) {
            dst_row[j] = src_row[j] * scale;
        }

        // Scalar passes
#if defined(LM_GGML_SIMD)
#if defined(__ARM_FEATURE_SVE)
        const int step = svcntw();
#else
        const int step = LM_GGML_F32_EPR;
#endif
#else
        const int step = n;
#endif
        for (int64_t len = 1; len < step && len < n; len <<= 1) {
            for (int64_t i = 0; i < n; i += 2 * len) {
                for (int64_t j = 0; j < len; j++) {
                    float u = dst_row[i + j];
                    float v = dst_row[i + len + j];
                    dst_row[i + j] = u + v;
                    dst_row[i + len + j] = u - v;
                }
            }
        }

        // SIMD passes using LM_GGML_F32_VEC_* macros for multi-architecture support
#if defined(LM_GGML_SIMD)
        for (int64_t len = step; len < n; len <<= 1) {
            for (int64_t i = 0; i < n; i += 2 * len) {
                for (int64_t j = 0; j < len; j += step) {
                    LM_GGML_F32_VEC u = LM_GGML_F32_VEC_LOAD(dst_row + i + j);
                    LM_GGML_F32_VEC v = LM_GGML_F32_VEC_LOAD(dst_row + i + len + j);

                    LM_GGML_F32_VEC_STORE(dst_row + i + j,       LM_GGML_F32_VEC_ADD(u, v));
                    LM_GGML_F32_VEC_STORE(dst_row + i + len + j, LM_GGML_F32_VEC_FMA(u, v, v_minus_one));
                }
            }
        }
#endif
    }
}

void lm_ggml_compute_forward_fwht(const lm_ggml_compute_params * params, lm_ggml_tensor * dst) {
    const lm_ggml_tensor * src1 = dst->src[1];

    switch (src1->type) {
        case LM_GGML_TYPE_F32:
            {
                lm_ggml_compute_forward_fwht_f32(params, dst);
            }
            break;
        default:
            {
                LM_GGML_ABORT("fatal error - fwht is F32 only");
            }
    }
}
