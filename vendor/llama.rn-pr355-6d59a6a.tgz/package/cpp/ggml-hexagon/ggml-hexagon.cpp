#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <atomic>
#include <chrono>
#include <mutex>
#include <thread>
#include <cstddef>
#include <stdexcept>
#include <string>
#include <sstream>
#include <iomanip>
#include <unordered_set>
#include <unordered_map>
#include <regex>
#include <queue>

#ifdef _WIN32
#    include <sal.h>
#else
#    include <semaphore.h>
#    include <unistd.h>
#endif

#pragma clang diagnostic ignored "-Wnested-anon-types"
#pragma clang diagnostic ignored "-Wgnu-anonymous-struct"

#include <AEEStdErr.h>
#include <dspqueue.h>
#include <rpcmem.h>

#define LM_GGML_COMMON_IMPL_CPP
#include "ggml-backend-impl.h"
#include "ggml-common.h"
#include "ggml-hexagon.h"
#include "ggml-impl.h"
#include "ggml-quants.h"
#include "htp-opnode.h"
#include "htp-ops.h"
#include "htp_iface.h"
#include "htp-drv.h"

using intvec  = std::vector<int>;
using uintvec = std::vector<unsigned int>;
using u32vec  = std::vector<uint32_t>;

static int    opt_arch    = 0; // autodetect
static size_t opt_ndev    = 1;
static size_t opt_nhvx    = 0; // use all
static int    opt_use_hmx = 1; // when set, enable HMX; when 0, use HVX only
static size_t opt_vmem    = HTP_OP_MAX_VMEM_DEFAULT;  // max available va space for buffer mappings
static size_t opt_mbuf    = 1ul * 1024 * 1024 * 1024; // max buffer size
static int    opt_etm     = 0;
static int    opt_verbose = 0;
static int    opt_profile = 0; // profiling mode (0-disabled, 1-basic, 2-pmu)
static int    opt_hostbuf = 1; // hostbuf ON by default

// Default PMU events, if profiling with PMU (mode=2) is enabled
// See https://docs.qualcomm.com/doc/80-N2040-60/topic/pmu-events.html
//     https://docs.qualcomm.com/doc/80-N2040-61/topic/hvx-pmu-events.html
static u32vec opt_pmu_evt { 0x3, 0x111, 0x100, 0x105, 0x240, 0x256, 0x7D, 0x8C };

// Enable all stages by default
static int opt_opstage  = HTP_OPSTAGE_QUEUE | HTP_OPSTAGE_COMPUTE;
static int opt_opbatch  = 1024; // max number of ops in a batch
static int opt_opqueue  = 16;   // max number of pending batches
static int opt_oppoll   = 0;    // polling for batch completions
static int opt_optrace  = 0;    // trace buffer size per thread (0 means default)

static std::regex* opt_opfilter = NULL; // regex of ops to not claim

#define HEX_VERBOSE(...) \
    if (opt_verbose) LM_GGML_LOG_DEBUG(__VA_ARGS__)

static inline uint64_t hex_is_aligned(void * addr, uint32_t align) {
    return ((size_t) addr & (align - 1)) == 0;
}

static inline size_t hex_round_up(size_t n, size_t m) {
    return m * ((n + m - 1) / m);
}

static const char * status_to_str(uint32_t status) {
    switch (status) {
        case HTP_STATUS_OK:
            return "OK";
        case HTP_STATUS_NO_SUPPORT:
            return "NO-SUPPORT";
        case HTP_STATUS_INVAL_PARAMS:
            return "INVAL-PARAMS";
        case HTP_STATUS_VTCM_TOO_SMALL:
            return "VTCM-TOO-SMALL";
        case HTP_STATUS_INTERNAL_ERR:
            return "INTERNAL-ERROR";
        default:
            return "UNKNOWN";
    }
}

// ** debug helpers

static void lm_ggml_hexagon_dump_op_exec(const std::string &sess_name, const htp_opnode & node, const uint32_t req_flags) {
    if (!opt_verbose) return;

    htp_opformat fmt(node);
    LM_GGML_LOG_DEBUG("ggml-hex: %s execute-op %s: %s : %s : %s : %s : %s : flags 0x%x\n", sess_name.c_str(),
                node.op_name().c_str(), fmt.names, fmt.dims, fmt.types, fmt.strides, fmt.buffs, req_flags);
}

static void lm_ggml_hexagon_dump_op_supp(const std::string &sess_name, const struct lm_ggml_tensor * op, bool supp) {
    if (!opt_verbose) return;

    htp_opformat fmt(htp_opformat(htp_opnode{const_cast<lm_ggml_tensor*>(op), {}, HTP_OP_INVALID}));
    LM_GGML_LOG_DEBUG("ggml-hex: %s supports-op %s: %s : %s : %s : %s : %s : %s\n", sess_name.c_str(),
                lm_ggml_op_desc(op), fmt.names, fmt.dims, fmt.types, fmt.strides, fmt.buffs, supp ? "yes" : "no");
}

static const char * htp_event_name(uint16_t id) {
    switch (id) {
        case HTP_TRACE_EVT_DMA:            return "DMA";
        case HTP_TRACE_EVT_HVX_COMP:       return "HVX_COMP";
        case HTP_TRACE_EVT_HVX_A_QUANT:    return "HVX_A_QUANT";
        case HTP_TRACE_EVT_HVX_A_PREP:     return "HVX_A_PREP";
        case HTP_TRACE_EVT_HVX_W_DEQUANT:  return "HVX_W_DEQUANT";
        case HTP_TRACE_EVT_HVX_W_PREP:     return "HVX_W_PREP";
        case HTP_TRACE_EVT_HVX_O_PROC:     return "HVX_O_PROC";
        case HTP_TRACE_EVT_HMX_COMP:       return "HMX_COMP";
        default:                           return "UNKNOWN";
    }
}

static void lm_ggml_hexagon_dump_op_prof(const std::string &sess_name, const htp_opnode & node,
                                      const htp_prof_desc & pd) {
    if (!opt_profile) return;

    uint32_t op_usec = pd.usecs;
    uint32_t op_cycles = pd.cycles_stop - pd.cycles_start;
    const uint32_t * pmu = pd.pmu;

    char pmu_str[256] = "";
    if (opt_profile == 2) {
        static_assert(HTP_PROF_PMU_NCNT == 8, "current implementation assumes 8 PMU counters");
        sprintf(pmu_str, " pmu [%u,%u,%u,%u,%u,%u,%u,%u]",
                pmu[0], pmu[1], pmu[2], pmu[3], pmu[4], pmu[5], pmu[6], pmu[7]);
    }

    htp_opformat fmt(node);
    float mhz = op_usec > 0 ? (float) op_cycles / op_usec : 0.0f;
    LM_GGML_LOG_DEBUG("ggml-hex: %s profile-op %s: %s : %s : %s : %s : usec %u cycles %u start %u mhz %.1f%s\n", sess_name.c_str(),
            node.op_name().c_str(), fmt.names, fmt.dims, fmt.types, fmt.strides, op_usec, op_cycles, pd.cycles_start, mhz, pmu_str);
}

// ** backend sessions

struct lm_ggml_hexagon_opbatch;
struct lm_ggml_hexagon_opqueue;
struct htp_opnode;

struct lm_ggml_hexagon_session {
    std::string      name;
    remote_handle64  handle;
    dspqueue_t       queue;
    uint32_t         session_id;
    uint32_t         domain_id;
    uint64_t         queue_id;
    int              dev_id;
    bool             valid_session;
    bool             valid_handle;
    bool             valid_queue;
    bool             valid_iface;

    std::atomic<int>      op_pending;
    lm_ggml_hexagon_opbatch* op_batch;
    lm_ggml_hexagon_opqueue* op_queue;

    lm_ggml_backend_buffer_type buffer_type        = {};
    lm_ggml_backend_buffer_type repack_buffer_type = {};

    lm_ggml_hexagon_session(int dev_id, lm_ggml_backend_dev_t dev) noexcept(false);
    ~lm_ggml_hexagon_session() noexcept(true);

    const char* c_name() const { return name.c_str(); }

    void allocate(int dev_id) noexcept(false);
    void release() noexcept(true);

    void enqueue_op(const htp_opnode & node);
    void flush(bool all = true);

    void flush_pending(bool all = false);
    void flush_batch();
};

// ** backend buffers

struct lm_ggml_backend_hexagon_buffer_type_context {
    lm_ggml_backend_hexagon_buffer_type_context(const std::string & name, lm_ggml_hexagon_session * sess) {
        this->sess = sess;
        this->name = name;
    }

    lm_ggml_hexagon_session * sess;
    std::string            name;
};

struct lm_ggml_hexagon_shared_buffer {
    lm_ggml_hexagon_session * sess;
    uint8_t *              base;
    size_t                 size;
    int                    fd;
    bool                   mapped;
    bool                   pinned;

    void mmap() {
        fastrpc_map_flags flags = this->pinned ? FASTRPC_MAP_FD : FASTRPC_MAP_FD_DELAYED;

        int err = fastrpc_mmap(sess->domain_id, this->fd, (void *) this->base, 0, this->size, flags);
        if (err != 0) {
            LM_GGML_LOG_ERROR("ggml-hex: %s buffer mapping failed : domain_id %d size %zu fd %d error 0x%08x\n", sess->c_name(),
                    sess->domain_id, this->size, this->fd, (unsigned) err);
            throw std::runtime_error("ggml-hex: fastrpc_mmap failed (see log for details)");
        }

        HEX_VERBOSE("ggml-hex: %s mapped buffer: base %p size %zu fd %d pinned %u\n",
                sess->c_name(), (void *) this->base, this->size, this->fd, pinned);

        this->mapped = true;
    }

    void unmap() {
        if (!this->mapped) return;

        if (!this->pinned) {
            // HTP might still hold a reference, tell it drop it
            htp_iface_munmap(sess->handle, this->fd);
        }

        fastrpc_munmap(sess->domain_id, this->fd, (void *) this->base, this->size);

        HEX_VERBOSE("ggml-hex: %s unmapped buffer: base %p size %zu fd %d\n", sess->c_name(),
                (void *) this->base, size, this->fd);

        this->mapped = false;
        this->fd     = -1;
    }

    void alloc(size_t size) {
        if (this->base) return;

        this->base = (uint8_t *) rpcmem_alloc2(RPCMEM_HEAP_ID_SYSTEM, RPCMEM_DEFAULT_FLAGS, size);
        if (!this->base) {
            LM_GGML_LOG_ERROR("ggml-hex: %s failed to allocate buffer : size %zu\n", sess->c_name(), size);
            throw std::runtime_error("ggml-hex: rpcmem_alloc failed (see log for details)");
        }

        this->fd = rpcmem_to_fd(this->base);
        if (this->fd < 0) {
            LM_GGML_LOG_ERROR("ggml-hex: %s failed to get FD for buffer %p\n", sess->c_name(), (void *) this->base);
            throw std::runtime_error("ggml-hex: rpcmem_to_fd failed (see log for details)");
        }
        this->size = size;

        HEX_VERBOSE("ggml-hex: %s allocated buffer: base %p size %zu fd %d pinned %d\n", sess->c_name(),
                    (void *) this->base, this->size, this->fd, (int) pinned);
        mmap();
    }

    void free() {
        if (!this->base) return;

        unmap();
        rpcmem_free(this->base);

        HEX_VERBOSE("ggml-hex: %s freed buffer: base %p size %zu fd %d\n", sess->c_name(),
                (void *) this->base, size, this->fd);

        this->base = NULL;
    }

    lm_ggml_hexagon_shared_buffer(lm_ggml_hexagon_session * sess, size_t size, bool pinned = false) {
        this->sess   = sess;
        this->size   = 0;
        this->base   = nullptr;
        this->fd     = -1;
        this->mapped = false;
        this->pinned = pinned;

        alloc(size);
    }

    ~lm_ggml_hexagon_shared_buffer() {
        free();
    }
};

static lm_ggml_hexagon_session * lm_ggml_backend_hexagon_buffer_get_sess(lm_ggml_backend_buffer_t buffer) {
    return static_cast<lm_ggml_backend_hexagon_buffer_type_context *>(buffer->buft->context)->sess;
}

static void lm_ggml_backend_hexagon_buffer_free_buffer(lm_ggml_backend_buffer_t buffer) {
    auto sbuf = static_cast<lm_ggml_hexagon_shared_buffer *>(buffer->context);
    delete sbuf;
}

static void * lm_ggml_backend_hexagon_buffer_get_base(lm_ggml_backend_buffer_t buffer) {
    auto sbuf = static_cast<lm_ggml_hexagon_shared_buffer *>(buffer->context);
    return sbuf->base;
}

static enum lm_ggml_status lm_ggml_backend_hexagon_buffer_init_tensor(lm_ggml_backend_buffer_t buffer, lm_ggml_tensor * tensor) {
    auto sbuf = static_cast<lm_ggml_hexagon_shared_buffer *>(buffer->context);
    auto sess = sbuf->sess;

    HEX_VERBOSE("ggml-hex: %s init-tensor %s : base %p data %p nbytes %zu usage %d\n", sess->c_name(),
                tensor->name, (void *) sbuf->base, tensor->data, lm_ggml_nbytes(tensor), (int) buffer->usage);

    if (tensor->view_src != NULL && tensor->view_offs == 0) {
        return LM_GGML_STATUS_SUCCESS; // nothing to do for the view
    }

    return LM_GGML_STATUS_SUCCESS;
}

// ======== Q4x4x2 ====================
struct x2_q4 {
    int v[2];
};

static x2_q4 unpack_q4(uint8_t v) {
    x2_q4 x = { (int) (v & 0x0f) - 8, (int) (v >> 4) - 8 };
    return x;
}

static void dump_block_q4_0(const block_q4_0 * b, int i) {
    HEX_VERBOSE("ggml-hex: repack q4_0 %d: %d %d %d %d ... %d %d %d %d : %.6f\n", i, unpack_q4(b->qs[0]).v[0],
                unpack_q4(b->qs[1]).v[0], unpack_q4(b->qs[2]).v[0], unpack_q4(b->qs[3]).v[0], unpack_q4(b->qs[12]).v[1],
                unpack_q4(b->qs[13]).v[1], unpack_q4(b->qs[14]).v[1], unpack_q4(b->qs[15]).v[1],
                LM_GGML_FP16_TO_FP32(b->d));
}

static void dump_packed_block_q4x4x2(const uint8_t * v, unsigned int i, size_t k) {
    static const int qk        = QK_Q4_0x4x2;
    const int        dblk_size = 8 * 2;   // 8x __fp16
    const int        qblk_size = qk / 2;  // int4
    const int        qrow_size = k / 2;   // int4 (not padded)

    const uint8_t * v_q = v + 0;          // quants first
    const uint8_t * v_d = v + qrow_size;  // then scales

    const uint8_t *   q = v_q + i * qblk_size;
    const lm_ggml_half * d = (const lm_ggml_half *) (v_d + i * dblk_size);

    HEX_VERBOSE("ggml-hex: repack q4x4x2-%d: %d %d %d %d ... %d %d %d %d ... %d %d %d %d : %.6f %.6f %.6f %.6f\n", i,
                unpack_q4(q[0]).v[0], unpack_q4(q[1]).v[0], unpack_q4(q[2]).v[0], unpack_q4(q[3]).v[0],
                unpack_q4(q[60]).v[0], unpack_q4(q[61]).v[0], unpack_q4(q[62]).v[0], unpack_q4(q[63]).v[0],
                unpack_q4(q[124]).v[0], unpack_q4(q[125]).v[0], unpack_q4(q[126]).v[0], unpack_q4(q[127]).v[0],
                LM_GGML_FP16_TO_FP32(d[0]), LM_GGML_FP16_TO_FP32(d[1]), LM_GGML_FP16_TO_FP32(d[2]), LM_GGML_FP16_TO_FP32(d[3]));

    HEX_VERBOSE("ggml-hex: repack q4x4x2-%d: %d %d %d %d ... %d %d %d %d ... %d %d %d %d : %.6f %.6f %.6f %.6f\n",
                i + 1, unpack_q4(q[0]).v[1], unpack_q4(q[1]).v[1], unpack_q4(q[2]).v[1], unpack_q4(q[3]).v[1],
                unpack_q4(q[60]).v[1], unpack_q4(q[61]).v[1], unpack_q4(q[62]).v[1], unpack_q4(q[63]).v[1],
                unpack_q4(q[124]).v[1], unpack_q4(q[125]).v[1], unpack_q4(q[126]).v[1], unpack_q4(q[127]).v[1],
                LM_GGML_FP16_TO_FP32(d[4]), LM_GGML_FP16_TO_FP32(d[5]), LM_GGML_FP16_TO_FP32(d[6]), LM_GGML_FP16_TO_FP32(d[7]));
}

static void unpack_q4_0_quants(uint8_t * qs, const block_q4_0 * x, unsigned int bi) {
    static const int qk = QK4_0;

    for (unsigned int i = 0; i < qk / 2; ++i) {
        const int x0             = (x->qs[i] & 0x0F);
        const int x1             = (x->qs[i] >> 4);
        qs[bi * qk + i + 0]      = x0;
        qs[bi * qk + i + qk / 2] = x1;
    }
}

static void pack_q4_0_quants(block_q4_0 * x, const uint8_t * qs, unsigned int bi) {
    static const int qk = QK4_0;

    for (unsigned int i = 0; i < qk / 2; ++i) {
        const uint8_t x0 = qs[bi * qk + i + 0];
        const uint8_t x1 = qs[bi * qk + i + qk / 2];
        x->qs[i]         = x0 | (x1 << 4);
    }
}

static void repack_row_q4x4x2(uint8_t * y, const block_q4_0 * x, int64_t k) {
    static const int qk = QK_Q4_0x4x2;
    const int        nb = (k + qk - 1) / qk;  // number of blocks (padded)
    const int        nloe = k % qk;           // leftovers

    const int dblk_size = 8 * 2;              // 8x __fp16
    const int qblk_size = qk / 2;             // int4
    const int qrow_size = k / 2;              // int4 (not padded to blocks)

    uint8_t * y_q = y + 0;                    // quants first
    uint8_t * y_d = y + qrow_size;            // then scales

    if (opt_verbose > 2) {
        for (int i = 0; i < nb; i++) {
            dump_block_q4_0(&x[i * 8 + 0], 0);
            dump_block_q4_0(&x[i * 8 + 1], 1);
            dump_block_q4_0(&x[i * 8 + 2], 2);
            dump_block_q4_0(&x[i * 8 + 3], 3);
            dump_block_q4_0(&x[i * 8 + 4], 4);
            dump_block_q4_0(&x[i * 8 + 5], 5);
            dump_block_q4_0(&x[i * 8 + 6], 6);
            dump_block_q4_0(&x[i * 8 + 7], 7);
        }
    }

    // Repack the quants
    for (int i = 0; i < nb; i++) {
        uint8_t qs[QK_Q4_0x4x2];  // unpacked quants
        unpack_q4_0_quants(qs, &x[i * 8 + 0], 0);
        unpack_q4_0_quants(qs, &x[i * 8 + 1], 1);
        unpack_q4_0_quants(qs, &x[i * 8 + 2], 2);
        unpack_q4_0_quants(qs, &x[i * 8 + 3], 3);
        unpack_q4_0_quants(qs, &x[i * 8 + 4], 4);
        unpack_q4_0_quants(qs, &x[i * 8 + 5], 5);
        unpack_q4_0_quants(qs, &x[i * 8 + 6], 6);
        unpack_q4_0_quants(qs, &x[i * 8 + 7], 7);

        bool partial = (nloe && i == nb-1);

        uint8_t * q = y_q + (i * qblk_size);
        for (int j = 0; j < qk / 2; j++) {
            q[j] = partial ? (qs[j*2+1] << 4) | qs[j*2+0] : (qs[j+128] << 4) | qs[j+000];
        }
    }

    // Repack the scales
    // Note: Do not combine with the loop above. For tensor sizes not multiple of 256 (QK_Q4_0x4x2)
    // the last block is truncated and overridden by the scales.
    for (int i = 0; i < nb; i++) {
        // Repack the scales
        lm_ggml_half * d = (lm_ggml_half *) (y_d + i * dblk_size);
        d[0]          = x[i * 8 + 0].d;
        d[1]          = x[i * 8 + 1].d;
        d[2]          = x[i * 8 + 2].d;
        d[3]          = x[i * 8 + 3].d;
        d[4]          = x[i * 8 + 4].d;
        d[5]          = x[i * 8 + 5].d;
        d[6]          = x[i * 8 + 6].d;
        d[7]          = x[i * 8 + 7].d;
    }

    if (opt_verbose > 2) {
        for (int i = 0; i < nb; i++) {
            dump_packed_block_q4x4x2(y, i, k);
        }
    }
}

static void unpack_row_q4x4x2(block_q4_0 * x, const uint8_t * y, int64_t k) {
    static const int qk = QK_Q4_0x4x2;
    const int        nb = (k + qk - 1) / qk;  // number of blocks (padded)
    const int        nloe = k % qk;           // leftovers

    const int dblk_size = 8 * 2;              // 8x __fp16
    const int qblk_size = qk / 2;             // int4
    const int qrow_size = k / 2;              // int4 (not padded to blocks)

    const uint8_t * y_q = y + 0;              // quants first
    const uint8_t * y_d = y + qrow_size;      // then scales

    if (opt_verbose > 2) {
        for (int i = 0; i < nb; i++) {
            dump_packed_block_q4x4x2(y, i, k);
        }
    }

    // Unpack the quants
    for (int i = 0; i < nb; i++) {
        uint8_t qs[QK_Q4_0x4x2];  // unpacked quants

        bool partial = (nloe && i == nb-1);

        const uint8_t * q = y_q + (i * qblk_size);
        for (int j = 0; j < qk / 2; j++) {
            if (partial) {
                qs[j*2+0] = q[j] & 0xf;
                qs[j*2+1] = q[j] >> 4;
            } else {
                qs[j+000] = q[j] & 0xf;
                qs[j+128] = q[j] >> 4;
            }
        }

        pack_q4_0_quants(&x[i * 8 + 0], qs, 0);
        pack_q4_0_quants(&x[i * 8 + 1], qs, 1);
        pack_q4_0_quants(&x[i * 8 + 2], qs, 2);
        pack_q4_0_quants(&x[i * 8 + 3], qs, 3);
        pack_q4_0_quants(&x[i * 8 + 4], qs, 4);
        pack_q4_0_quants(&x[i * 8 + 5], qs, 5);
        pack_q4_0_quants(&x[i * 8 + 6], qs, 6);
        pack_q4_0_quants(&x[i * 8 + 7], qs, 7);
    }

    // Repack the scales
    // Note: Do not combine with the loop above. For tensor sizes not multiple of 256 (QK_Q4_0x4x2)
    // the last block is truncated and overridden by the scales.
    for (int i = 0; i < nb; i++) {
        // Unpack the scales
        const lm_ggml_half * d = (const lm_ggml_half *) (y_d + i * dblk_size);
        x[i * 8 + 0].d      = d[0];
        x[i * 8 + 1].d      = d[1];
        x[i * 8 + 2].d      = d[2];
        x[i * 8 + 3].d      = d[3];
        x[i * 8 + 4].d      = d[4];
        x[i * 8 + 5].d      = d[5];
        x[i * 8 + 6].d      = d[6];
        x[i * 8 + 7].d      = d[7];
    }

    if (opt_verbose > 2) {
        for (int i = 0; i < nb; i++) {
            dump_block_q4_0(&x[i * 8 + 0], 0);
            dump_block_q4_0(&x[i * 8 + 1], 1);
            dump_block_q4_0(&x[i * 8 + 2], 2);
            dump_block_q4_0(&x[i * 8 + 3], 3);
            dump_block_q4_0(&x[i * 8 + 4], 4);
            dump_block_q4_0(&x[i * 8 + 5], 5);
            dump_block_q4_0(&x[i * 8 + 6], 6);
            dump_block_q4_0(&x[i * 8 + 7], 7);
        }
    }
}

static void init_row_q4x4x2(block_q4_0 * x, int64_t k) {
    static const int qk = QK_Q4_0x4x2;
    const int        nb = (k + qk - 1) / qk;  // number of blocks (padded)

    // Init the quants such that they unpack into zeros
    uint8_t qs[QK_Q4_0x4x2];  // unpacked quants
    memset(qs, 8, sizeof(qs));

    for (int i = 0; i < nb; i++) {
        pack_q4_0_quants(&x[i * 8 + 0], qs, 0);
        pack_q4_0_quants(&x[i * 8 + 1], qs, 1);
        pack_q4_0_quants(&x[i * 8 + 2], qs, 2);
        pack_q4_0_quants(&x[i * 8 + 3], qs, 3);
        pack_q4_0_quants(&x[i * 8 + 4], qs, 4);
        pack_q4_0_quants(&x[i * 8 + 5], qs, 5);
        pack_q4_0_quants(&x[i * 8 + 6], qs, 6);
        pack_q4_0_quants(&x[i * 8 + 7], qs, 7);
    }

    // Init the scales
    // Note: Do not combine with the loop above. For tensor sizes not multiple of 256 (QK_Q4_0x4x2)
    // the last block is truncated and overridden by the scales.
    for (int i = 0; i < nb; i++) {
        // Unpack the scales
        x[i * 8 + 0].d = 0;
        x[i * 8 + 1].d = 0;
        x[i * 8 + 2].d = 0;
        x[i * 8 + 3].d = 0;
        x[i * 8 + 4].d = 0;
        x[i * 8 + 5].d = 0;
        x[i * 8 + 6].d = 0;
        x[i * 8 + 7].d = 0;
    }
}

// repack q4_0 data into q4x4x2 tensor
static void repack_q4_0_q4x4x2(lm_ggml_tensor * t, const void * data, size_t size) {
    int64_t nrows = lm_ggml_nrows(t);

    size_t row_size    = lm_ggml_row_size(t->type, t->ne[0]);
    size_t row_size_pd = lm_ggml_row_size(t->type, hex_round_up(t->ne[0], QK_Q4_0x4x2));  // extra elements for the pad
    size_t row_size_rp = row_size_pd;  // scratch must hold one full padded tile (qblk_size/2 quants + scales)

    // Ensure we don't try to read more data than is available in the source buffer 'data'
    // or write more than the tensor can hold.
    const size_t total_tensor_size = (size_t)nrows * row_size;
    const size_t n_bytes_to_copy = size < total_tensor_size ? size : total_tensor_size;

    // Calculate how many full rows and how many remaining bytes we need to process.
    const int64_t n_full_rows = n_bytes_to_copy / row_size;
    const size_t  n_rem_bytes = n_bytes_to_copy % row_size;

    void * buf_pd = lm_ggml_aligned_malloc(row_size_pd);
    LM_GGML_ASSERT(buf_pd != NULL);

    void * buf_rp = lm_ggml_aligned_malloc(row_size_rp);
    LM_GGML_ASSERT(buf_rp != NULL);

    HEX_VERBOSE("ggml-hex: repack-q4_0-q4x4x2 %s : data %p size %zu dims %ldx%ld row-size %zu\n", t->name, data, size,
                t->ne[0], nrows, row_size);

    init_row_q4x4x2((block_q4_0 *) buf_pd, t->ne[0]);  // init padded buffer to make sure the tail is all zeros

    // 1. Process all the full rows
    for (int64_t i = 0; i < n_full_rows; i++) {
        const uint8_t * src = (const uint8_t *) data + (i * row_size);
        uint8_t *       dst = (uint8_t *) t->data + (i * row_size);

        memcpy(buf_pd, src, row_size);
        repack_row_q4x4x2((uint8_t *) buf_rp, (const block_q4_0 *) buf_pd, t->ne[0]);
        memcpy(dst, buf_rp, row_size);
    }

    // 2. Process the final, potentially partial, row
    if (n_rem_bytes > 0) {
        const int64_t i = n_full_rows;
        const uint8_t * src = (const uint8_t *) data + (i * row_size);
        uint8_t *       dst = (uint8_t *) t->data + (i * row_size);

        // re-init the row because we are potentially copying a partial row
        init_row_q4x4x2((block_q4_0 *) buf_pd, t->ne[0]);

        // Copy only the remaining bytes from the source.
        memcpy(buf_pd, src, n_rem_bytes);

        // Repack the entire buffer
        repack_row_q4x4x2((uint8_t *) buf_rp, (const block_q4_0 *) buf_pd, t->ne[0]);

        // Write only the corresponding remaining bytes to the destination tensor.
        memcpy(dst, buf_rp, n_rem_bytes);
    }

    lm_ggml_aligned_free(buf_pd, row_size_pd);
    lm_ggml_aligned_free(buf_rp, row_size_rp);
}

// repack q4x4x2 tensor into q4_0 data
static void repack_q4x4x2_q4_0(void * data, const lm_ggml_tensor * t, size_t size) {
    int64_t nrows = lm_ggml_nrows(t);

    size_t row_size    = lm_ggml_row_size(t->type, t->ne[0]);
    size_t row_size_pd = lm_ggml_row_size(t->type, hex_round_up(t->ne[0], QK_Q4_0x4x2));  // extra elements for the pad
    size_t row_size_rp = row_size_pd;  // scratch must hold one full padded tile (qblk_size/2 quants + scales)

    // Ensure we don't try to copy more data than the tensor actually contains.
    const size_t total_tensor_size = (size_t)nrows * row_size;
    const size_t n_bytes_to_copy = size < total_tensor_size ? size : total_tensor_size;

    // Calculate how many full rows and how many remaining bytes we need to process.
    const int64_t n_full_rows = n_bytes_to_copy / row_size;
    const size_t  n_rem_bytes = n_bytes_to_copy % row_size;

    void * buf_pd = lm_ggml_aligned_malloc(row_size_pd);
    LM_GGML_ASSERT(buf_pd != NULL);

    void * buf_rp = lm_ggml_aligned_malloc(row_size_rp);
    LM_GGML_ASSERT(buf_rp != NULL);

    HEX_VERBOSE("ggml-hex: repack-q4x4x2-q4_0 %s : data %p size %zu dims %ldx%ld row-size %zu\n", t->name, data, size,
                t->ne[0], nrows, row_size);

    memset(buf_pd, 0, row_size_pd);  // clear-out padded buffer to make sure the tail is all zeros

    // 1. Process all the full rows
    for (int64_t i = 0; i < n_full_rows; i++) {
        const uint8_t * src = (const uint8_t *) t->data + (i * row_size);
        uint8_t *       dst = (uint8_t *) data + (i * row_size);

        memcpy(buf_pd, src, row_size);
        unpack_row_q4x4x2((block_q4_0 *) buf_rp, (const uint8_t *) buf_pd, t->ne[0]);
        memcpy(dst, buf_rp, row_size);
    }

    // 2. Process the final, potentially partial, row
    if (n_rem_bytes > 0) {
        const int64_t i = n_full_rows;
        const uint8_t * src = (const uint8_t *) t->data + (i * row_size);
        uint8_t *       dst = (uint8_t *) data + (i * row_size);

        // We still need to read and unpack the entire source row because quantization is block-based.
        memcpy(buf_pd, src, row_size);
        unpack_row_q4x4x2((block_q4_0 *) buf_rp, (const uint8_t *) buf_pd, t->ne[0]);

        // But we only copy the remaining number of bytes to the destination.
        memcpy(dst, buf_rp, n_rem_bytes);
    }

    lm_ggml_aligned_free(buf_pd, row_size_pd);
    lm_ggml_aligned_free(buf_rp, row_size_rp);
}

static void unpack_q4_1_quants(uint8_t * qs, const block_q4_1 * x, unsigned int bi) {
    static const int qk = QK4_1;

    for (unsigned int i = 0; i < qk / 2; ++i) {
        const int x0             = (x->qs[i] & 0x0F);
        const int x1             = (x->qs[i] >> 4);
        qs[bi * qk + i + 0]      = x0;
        qs[bi * qk + i + qk / 2] = x1;
    }
}

static void pack_q4_1_quants(block_q4_1 * x, const uint8_t * qs, unsigned int bi) {
    static const int qk = QK4_1;

    for (unsigned int i = 0; i < qk / 2; ++i) {
        const uint8_t x0 = qs[bi * qk + i + 0];
        const uint8_t x1 = qs[bi * qk + i + qk / 2];
        x->qs[i]         = x0 | (x1 << 4);
    }
}

static void repack_row_q4_1x4x2(uint8_t * y, const block_q4_1 * x, int64_t k) {
    static const int qk = QK_Q4_0x4x2;
    const int        nb = (k + qk - 1) / qk;  // number of blocks (padded)
    const int        nloe = k % qk;           // leftovers

    const int dblk_size = 8 * 4;              // 8x (d, m) __fp16 = 32 bytes
    const int qblk_size = qk / 2;             // int4 = 128 bytes
    const int qrow_size = k / 2;              // int4 (not padded to blocks)

    uint8_t * y_q = y + 0;                    // quants first
    uint8_t * y_d = y + qrow_size;            // then scales/offsets

    // Repack the quants
    for (int i = 0; i < nb; i++) {
        uint8_t qs[QK_Q4_0x4x2];  // unpacked quants
        unpack_q4_1_quants(qs, &x[i * 8 + 0], 0);
        unpack_q4_1_quants(qs, &x[i * 8 + 1], 1);
        unpack_q4_1_quants(qs, &x[i * 8 + 2], 2);
        unpack_q4_1_quants(qs, &x[i * 8 + 3], 3);
        unpack_q4_1_quants(qs, &x[i * 8 + 4], 4);
        unpack_q4_1_quants(qs, &x[i * 8 + 5], 5);
        unpack_q4_1_quants(qs, &x[i * 8 + 6], 6);
        unpack_q4_1_quants(qs, &x[i * 8 + 7], 7);

        bool partial = (nloe && i == nb-1);

        uint8_t * q = y_q + (i * qblk_size);
        for (int j = 0; j < qk / 2; j++) {
            q[j] = partial ? (qs[j*2+1] << 4) | qs[j*2+0] : (qs[j+128] << 4) | qs[j+000];
        }
    }

    // Repack the scales and offsets
    for (int i = 0; i < nb; i++) {
        lm_ggml_half * d_m = (lm_ggml_half *) (y_d + i * dblk_size);
        for (int j = 0; j < 8; j++) {
            d_m[j * 2 + 0] = x[i * 8 + j].d;
            d_m[j * 2 + 1] = x[i * 8 + j].m;
        }
    }
}

static void unpack_row_q4_1x4x2(block_q4_1 * x, const uint8_t * y, int64_t k) {
    static const int qk = QK_Q4_0x4x2;
    const int        nb = (k + qk - 1) / qk;  // number of blocks (padded)
    const int        nloe = k % qk;           // leftovers

    const int dblk_size = 8 * 4;              // 8x (d, m) __fp16 = 32 bytes
    const int qblk_size = qk / 2;             // int4 = 128 bytes
    const int qrow_size = k / 2;              // int4 (not padded to blocks)

    const uint8_t * y_q = y + 0;              // quants first
    const uint8_t * y_d = y + qrow_size;      // then scales/offsets

    // Unpack the quants
    for (int i = 0; i < nb; i++) {
        uint8_t qs[QK_Q4_0x4x2];
        bool partial = (nloe && i == nb-1);

        const uint8_t * q = y_q + (i * qblk_size);
        for (int j = 0; j < qk / 2; j++) {
            if (partial) {
                qs[j*2+0] = q[j] & 0x0F;
                qs[j*2+1] = q[j] >> 4;
            } else {
                qs[j+000] = q[j] & 0x0F;
                qs[j+128] = q[j] >> 4;
            }
        }

        pack_q4_1_quants(&x[i * 8 + 0], qs, 0);
        pack_q4_1_quants(&x[i * 8 + 1], qs, 1);
        pack_q4_1_quants(&x[i * 8 + 2], qs, 2);
        pack_q4_1_quants(&x[i * 8 + 3], qs, 3);
        pack_q4_1_quants(&x[i * 8 + 4], qs, 4);
        pack_q4_1_quants(&x[i * 8 + 5], qs, 5);
        pack_q4_1_quants(&x[i * 8 + 6], qs, 6);
        pack_q4_1_quants(&x[i * 8 + 7], qs, 7);
    }

    // Unpack the scales and offsets
    for (int i = 0; i < nb; i++) {
        const lm_ggml_half * d_m = (const lm_ggml_half *) (y_d + i * dblk_size);
        for (int j = 0; j < 8; j++) {
            x[i * 8 + j].d = d_m[j * 2 + 0];
            x[i * 8 + j].m = d_m[j * 2 + 1];
        }
    }
}

static void init_row_q4_1x4x2(block_q4_1 * x, int64_t k) {
    static const int qk = QK_Q4_0x4x2;
    const int        nb = (k + qk - 1) / qk;  // number of blocks (padded)

    uint8_t qs[QK_Q4_0x4x2];  // unpacked quants
    memset(qs, 0, sizeof(qs));

    for (int i = 0; i < nb; i++) {
        pack_q4_1_quants(&x[i * 8 + 0], qs, 0);
        pack_q4_1_quants(&x[i * 8 + 1], qs, 1);
        pack_q4_1_quants(&x[i * 8 + 2], qs, 2);
        pack_q4_1_quants(&x[i * 8 + 3], qs, 3);
        pack_q4_1_quants(&x[i * 8 + 4], qs, 4);
        pack_q4_1_quants(&x[i * 8 + 5], qs, 5);
        pack_q4_1_quants(&x[i * 8 + 6], qs, 6);
        pack_q4_1_quants(&x[i * 8 + 7], qs, 7);
    }

    for (int i = 0; i < nb; i++) {
        for (int j = 0; j < 8; j++) {
            x[i * 8 + j].d = 0;
            x[i * 8 + j].m = 0;
        }
    }
}

static void repack_q4_1_q4x4x2(lm_ggml_tensor * t, const void * data, size_t size) {
    int64_t nrows = lm_ggml_nrows(t);

    size_t row_size    = lm_ggml_row_size(t->type, t->ne[0]);
    size_t row_size_pd = lm_ggml_row_size(t->type, hex_round_up(t->ne[0], QK_Q4_0x4x2));
    size_t row_size_rp = row_size_pd;  // scratch must hold one full padded tile (qblk_size/2 quants + scales)

    const size_t total_tensor_size = (size_t)nrows * row_size;
    const size_t n_bytes_to_copy = size < total_tensor_size ? size : total_tensor_size;

    const int64_t n_full_rows = n_bytes_to_copy / row_size;
    const size_t  n_rem_bytes = n_bytes_to_copy % row_size;

    void * buf_pd = lm_ggml_aligned_malloc(row_size_pd);
    LM_GGML_ASSERT(buf_pd != NULL);

    void * buf_rp = lm_ggml_aligned_malloc(row_size_rp);
    LM_GGML_ASSERT(buf_rp != NULL);

    HEX_VERBOSE("ggml-hex: repack-q4_1-q4x4x2 %s : data %p size %zu dims %ldx%ld row-size %zu\n", t->name, data, size,
                t->ne[0], nrows, row_size);

    init_row_q4_1x4x2((block_q4_1 *) buf_pd, t->ne[0]);

    for (int64_t i = 0; i < n_full_rows; i++) {
        const uint8_t * src = (const uint8_t *) data + (i * row_size);
        uint8_t *       dst = (uint8_t *) t->data + (i * row_size);

        memcpy(buf_pd, src, row_size);
        repack_row_q4_1x4x2((uint8_t *) buf_rp, (const block_q4_1 *) buf_pd, t->ne[0]);
        memcpy(dst, buf_rp, row_size);
    }

    if (n_rem_bytes > 0) {
        const int64_t i = n_full_rows;
        const uint8_t * src = (const uint8_t *) data + (i * row_size);
        uint8_t *       dst = (uint8_t *) t->data + (i * row_size);

        init_row_q4_1x4x2((block_q4_1 *) buf_pd, t->ne[0]);
        memcpy(buf_pd, src, n_rem_bytes);
        repack_row_q4_1x4x2((uint8_t *) buf_rp, (const block_q4_1 *) buf_pd, t->ne[0]);
        memcpy(dst, buf_rp, n_rem_bytes);
    }

    lm_ggml_aligned_free(buf_pd, row_size_pd);
    lm_ggml_aligned_free(buf_rp, row_size_rp);
}

static void repack_q4x4x2_q4_1(void * data, const lm_ggml_tensor * t, size_t size) {
    int64_t nrows = lm_ggml_nrows(t);

    size_t row_size    = lm_ggml_row_size(t->type, t->ne[0]);
    size_t row_size_pd = lm_ggml_row_size(t->type, hex_round_up(t->ne[0], QK_Q4_0x4x2));
    size_t row_size_rp = row_size_pd;  // scratch must hold one full padded tile (qblk_size/2 quants + scales)

    const size_t total_tensor_size = (size_t)nrows * row_size;
    const size_t n_bytes_to_copy = size < total_tensor_size ? size : total_tensor_size;

    const int64_t n_full_rows = n_bytes_to_copy / row_size;
    const size_t  n_rem_bytes = n_bytes_to_copy % row_size;

    void * buf_pd = lm_ggml_aligned_malloc(row_size_pd);
    LM_GGML_ASSERT(buf_pd != NULL);

    void * buf_rp = lm_ggml_aligned_malloc(row_size_rp);
    LM_GGML_ASSERT(buf_rp != NULL);

    HEX_VERBOSE("ggml-hex: repack-q4x4x2-q4_1 %s : data %p size %zu dims %ldx%ld row-size %zu\n", t->name, data, size,
                t->ne[0], nrows, row_size);

    memset(buf_rp, 0, row_size_rp);  // clear-out padded buffer to make sure the tail is all zeros

    for (int64_t i = 0; i < n_full_rows; i++) {
        const uint8_t * src = (const uint8_t *) t->data + (i * row_size);
        uint8_t *       dst = (uint8_t *) data + (i * row_size);

        memcpy(buf_rp, src, row_size);
        unpack_row_q4_1x4x2((block_q4_1 *) buf_pd, (const uint8_t *) buf_rp, t->ne[0]);
        memcpy(dst, buf_pd, row_size);
    }

    if (n_rem_bytes > 0) {
        const int64_t i = n_full_rows;
        const uint8_t * src = (const uint8_t *) t->data + (i * row_size);
        uint8_t *       dst = (uint8_t *) data + (i * row_size);

        // We still need to read and unpack the entire source row because quantization is block-based.
        memcpy(buf_rp, src, row_size);
        unpack_row_q4_1x4x2((block_q4_1 *) buf_pd, (const uint8_t *) buf_rp, t->ne[0]);
        memcpy(dst, buf_pd, n_rem_bytes);
    }

    lm_ggml_aligned_free(buf_pd, row_size_pd);
    lm_ggml_aligned_free(buf_rp, row_size_rp);
}

// ======== Q8x4x2 ====================
static void dump_block_q8_0(const block_q8_0 * b, int i) {
    HEX_VERBOSE("ggml-hex: repack q8_0 %d: %d %d %d %d ... %d %d %d %d : %.6f\n", i, b->qs[0], b->qs[1], b->qs[2],
                b->qs[3], b->qs[28], b->qs[29], b->qs[30], b->qs[31], LM_GGML_FP16_TO_FP32(b->d));
}

static void dump_packed_block_q8x4x2(const uint8_t * v, unsigned int i, size_t k) {
    static const int qk        = QK_Q8_0x4x2;
    const int        dblk_size = 8 * 2;   // 8x __fp16
    const int        qblk_size = qk;      // int8
    const int        qrow_size = k;       // int8 (not padded)

    const uint8_t * v_q = v + 0;          // quants first
    const uint8_t * v_d = v + qrow_size;  // then scales

    const uint8_t *   q = v_q + i * qblk_size;
    const lm_ggml_half * d = (const lm_ggml_half *) (v_d + i * dblk_size);

    HEX_VERBOSE("ggml-hex: repack q8x4x2-%d: %d %d %d %d ... %d %d %d %d ... %d %d %d %d : %.6f %.6f %.6f %.6f\n", i,
                q[0], q[1], q[2], q[3], q[60], q[61], q[62], q[63], q[124], q[125], q[126], q[127],
                LM_GGML_FP16_TO_FP32(d[0]), LM_GGML_FP16_TO_FP32(d[1]), LM_GGML_FP16_TO_FP32(d[2]), LM_GGML_FP16_TO_FP32(d[3]));

    HEX_VERBOSE("ggml-hex: repack q8x4x2-%d: %d %d %d %d ... %d %d %d %d ... %d %d %d %d : %.6f %.6f %.6f %.6f\n",
                i + 1, q[128], q[129], q[130], q[131], q[192], q[193], q[194], q[195], q[252], q[253], q[254], q[255],
                LM_GGML_FP16_TO_FP32(d[4]), LM_GGML_FP16_TO_FP32(d[5]), LM_GGML_FP16_TO_FP32(d[6]), LM_GGML_FP16_TO_FP32(d[7]));
}

static void unpack_q8_0_quants(uint8_t * qs, const block_q8_0 * x, unsigned int bi) {
    static const int qk = QK8_0;

    for (unsigned int i = 0; i < qk; ++i) {
        qs[bi * qk + i] = x->qs[i];
    }
}

static void pack_q8_0_quants(block_q8_0 * x, const uint8_t * qs, unsigned int bi) {
    static const int qk = QK8_0;

    for (unsigned int i = 0; i < qk; ++i) {
        x->qs[i] = qs[bi * qk + i];
    }
}

static void repack_row_q8x4x2(uint8_t * y, const block_q8_0 * x, int64_t k) {
    static const int qk = QK_Q8_0x4x2;
    const int        nb = (k + qk - 1) / qk;  // number of blocks (padded)

    const int dblk_size = 8 * 2;              // 8x __fp16
    const int qblk_size = qk;                 // int8
    const int qrow_size = k;                  // int8 (not padded to blocks)

    uint8_t * y_q = y + 0;                    // quants first
    uint8_t * y_d = y + qrow_size;            // then scales

    if (opt_verbose > 2) {
        for (int i = 0; i < nb; i++) {
            dump_block_q8_0(&x[i * 8 + 0], 0);
            dump_block_q8_0(&x[i * 8 + 1], 1);
            dump_block_q8_0(&x[i * 8 + 2], 2);
            dump_block_q8_0(&x[i * 8 + 3], 3);
            dump_block_q8_0(&x[i * 8 + 4], 4);
            dump_block_q8_0(&x[i * 8 + 5], 5);
            dump_block_q8_0(&x[i * 8 + 6], 6);
            dump_block_q8_0(&x[i * 8 + 7], 7);
        }
    }

    // Repack the quants
    for (int i = 0; i < nb; i++) {
        uint8_t qs[QK_Q8_0x4x2];  // unpacked quants

        unpack_q8_0_quants(qs, &x[i * 8 + 0], 0);
        unpack_q8_0_quants(qs, &x[i * 8 + 1], 1);
        unpack_q8_0_quants(qs, &x[i * 8 + 2], 2);
        unpack_q8_0_quants(qs, &x[i * 8 + 3], 3);
        unpack_q8_0_quants(qs, &x[i * 8 + 4], 4);
        unpack_q8_0_quants(qs, &x[i * 8 + 5], 5);
        unpack_q8_0_quants(qs, &x[i * 8 + 6], 6);
        unpack_q8_0_quants(qs, &x[i * 8 + 7], 7);

        uint8_t * q = y_q + (i * qblk_size);
        for (int j = 0; j < qk; j++) {
            q[j] = qs[j];
        }
    }

    // Repack the scales
    // Note: Do not combine with the loop above. For tensor sizes not multiple of 256 (QK_Q4_0x4x2)
    // the last block is truncated and overridden by the scales.
    for (int i = 0; i < nb; i++) {
        // Repack the scales
        lm_ggml_half * d = (lm_ggml_half *) (y_d + i * dblk_size);
        d[0]          = x[i * 8 + 0].d;
        d[1]          = x[i * 8 + 1].d;
        d[2]          = x[i * 8 + 2].d;
        d[3]          = x[i * 8 + 3].d;
        d[4]          = x[i * 8 + 4].d;
        d[5]          = x[i * 8 + 5].d;
        d[6]          = x[i * 8 + 6].d;
        d[7]          = x[i * 8 + 7].d;
    }

    if (opt_verbose > 2) {
        for (int i = 0; i < nb; i++) {
            dump_packed_block_q8x4x2(y, i, k);
        }
    }
}

static void unpack_row_q8x4x2(block_q8_0 * x, const uint8_t * y, int64_t k) {
    static const int qk = QK_Q8_0x4x2;
    const int        nb = (k + qk - 1) / qk;  // number of blocks (padded)

    const int dblk_size = 8 * 2;              // 8x __fp16
    const int qblk_size = qk;                 // int8
    const int qrow_size = k;                  // int8 (not padded to blocks)

    const uint8_t * y_q = y + 0;              // quants first
    const uint8_t * y_d = y + qrow_size;      // then scales

    if (opt_verbose > 2) {
        for (int i = 0; i < nb; i++) {
            dump_packed_block_q8x4x2(y, i, k);
        }
    }

    // Unpack the quants
    for (int i = 0; i < nb; i++) {
        uint8_t qs[QK_Q4_0x4x2];  // unpacked quants

        const uint8_t * q = y_q + (i * qblk_size);
        for (int j = 0; j < qk; j++) {
            qs[j] = q[j];
        }

        pack_q8_0_quants(&x[i * 8 + 0], qs, 0);
        pack_q8_0_quants(&x[i * 8 + 1], qs, 1);
        pack_q8_0_quants(&x[i * 8 + 2], qs, 2);
        pack_q8_0_quants(&x[i * 8 + 3], qs, 3);
        pack_q8_0_quants(&x[i * 8 + 4], qs, 4);
        pack_q8_0_quants(&x[i * 8 + 5], qs, 5);
        pack_q8_0_quants(&x[i * 8 + 6], qs, 6);
        pack_q8_0_quants(&x[i * 8 + 7], qs, 7);
    }

    // Repack the scales
    // Note: Do not combine with the loop above. For tensor sizes not multiple of 256 (QK_Q4_0x4x2)
    // the last block is truncated and overridden by the scales.
    for (int i = 0; i < nb; i++) {
        // Unpack the scales
        const lm_ggml_half * d = (const lm_ggml_half *) (y_d + i * dblk_size);
        x[i * 8 + 0].d      = d[0];
        x[i * 8 + 1].d      = d[1];
        x[i * 8 + 2].d      = d[2];
        x[i * 8 + 3].d      = d[3];
        x[i * 8 + 4].d      = d[4];
        x[i * 8 + 5].d      = d[5];
        x[i * 8 + 6].d      = d[6];
        x[i * 8 + 7].d      = d[7];
    }

    if (opt_verbose > 2) {
        for (int i = 0; i < nb; i++) {
            dump_block_q8_0(&x[i * 8 + 0], 0);
            dump_block_q8_0(&x[i * 8 + 1], 1);
            dump_block_q8_0(&x[i * 8 + 2], 2);
            dump_block_q8_0(&x[i * 8 + 3], 3);
            dump_block_q8_0(&x[i * 8 + 4], 4);
            dump_block_q8_0(&x[i * 8 + 5], 5);
            dump_block_q8_0(&x[i * 8 + 6], 6);
            dump_block_q8_0(&x[i * 8 + 7], 7);
        }
    }
}

static void init_row_q8x4x2(block_q8_0 * x, int64_t k) {
    static const int qk = QK_Q8_0x4x2;
    const int        nb = (k + qk - 1) / qk;  // number of blocks (padded)

    // Init the quants such that they unpack into zeros
    uint8_t qs[QK_Q8_0x4x2];  // unpacked quants
    memset(qs, 0, sizeof(qs));

    for (int i = 0; i < nb; i++) {
        pack_q8_0_quants(&x[i * 8 + 0], qs, 0);
        pack_q8_0_quants(&x[i * 8 + 1], qs, 1);
        pack_q8_0_quants(&x[i * 8 + 2], qs, 2);
        pack_q8_0_quants(&x[i * 8 + 3], qs, 3);
        pack_q8_0_quants(&x[i * 8 + 4], qs, 4);
        pack_q8_0_quants(&x[i * 8 + 5], qs, 5);
        pack_q8_0_quants(&x[i * 8 + 6], qs, 6);
        pack_q8_0_quants(&x[i * 8 + 7], qs, 7);
    }

    // Init the scales
    // Note: Do not combine with the loop above. For tensor sizes not multiple of 256 (QK_Q8_0x4x2)
    // the last block is truncated and overridden by the scales.
    for (int i = 0; i < nb; i++) {
        // Unpack the scales
        x[i * 8 + 0].d = 0;
        x[i * 8 + 1].d = 0;
        x[i * 8 + 2].d = 0;
        x[i * 8 + 3].d = 0;
        x[i * 8 + 4].d = 0;
        x[i * 8 + 5].d = 0;
        x[i * 8 + 6].d = 0;
        x[i * 8 + 7].d = 0;
    }
}

// repack q8_0 data into q8x4x2 tensor
static void repack_q8_0_q8x4x2(lm_ggml_tensor * t, const void * data, size_t size) {
    int64_t nrows = lm_ggml_nrows(t);

    size_t row_size    = lm_ggml_row_size(t->type, t->ne[0]);
    size_t row_size_pd = lm_ggml_row_size(t->type, hex_round_up(t->ne[0], QK_Q8_0x4x2));  // extra elements for the pad
    size_t row_size_rp = row_size_pd;  // scratch must hold one full padded tile (qblk_size quants + scales)

    // Ensure we don't try to read more data than is available in the source buffer 'data'
    // or write more than the tensor can hold.
    const size_t total_tensor_size = (size_t)nrows * row_size;
    const size_t n_bytes_to_copy = size < total_tensor_size ? size : total_tensor_size;

    // Calculate how many full rows and how many remaining bytes we need to process.
    const int64_t n_full_rows = n_bytes_to_copy / row_size;
    const size_t  n_rem_bytes = n_bytes_to_copy % row_size;

    void * buf_pd = lm_ggml_aligned_malloc(row_size_pd);
    LM_GGML_ASSERT(buf_pd != NULL);

    void * buf_rp = lm_ggml_aligned_malloc(row_size_rp);
    LM_GGML_ASSERT(buf_rp != NULL);

    HEX_VERBOSE("ggml-hex: repack-q8_0-q8x4x2 %s : data %p size %zu dims %ldx%ld row-size %zu\n", t->name, data, size,
                t->ne[0], nrows, row_size);

    init_row_q8x4x2((block_q8_0 *) buf_pd, t->ne[0]);  // init padded buffer to make sure the tail is all zeros

    // 1. Process all the full rows
    for (int64_t i = 0; i < n_full_rows; i++) {
        const uint8_t * src = (const uint8_t *) data + (i * row_size);
        uint8_t *       dst = (uint8_t *) t->data + (i * row_size);

        memcpy(buf_pd, src, row_size);
        repack_row_q8x4x2((uint8_t *) buf_rp, (const block_q8_0 *) buf_pd, t->ne[0]);
        memcpy(dst, buf_rp, row_size);
    }

    // 2. Process the final, potentially partial, row
    if (n_rem_bytes > 0) {
        const int64_t i = n_full_rows;
        const uint8_t * src = (const uint8_t *) data + (i * row_size);
        uint8_t *       dst = (uint8_t *) t->data + (i * row_size);

        // re-init the row because we are potentially copying a partial row
        init_row_q8x4x2((block_q8_0 *) buf_pd, t->ne[0]);

        // Copy only the remaining bytes from the source.
        memcpy(buf_pd, src, n_rem_bytes);

        // Repack the entire buffer
        repack_row_q8x4x2((uint8_t *) buf_rp, (const block_q8_0 *) buf_pd, t->ne[0]);

        // Write only the corresponding remaining bytes to the destination tensor.
        memcpy(dst, buf_rp, n_rem_bytes);
    }

    lm_ggml_aligned_free(buf_pd, row_size_pd);
    lm_ggml_aligned_free(buf_rp, row_size_rp);
}

// repack q8x4x2 tensor into q8_0 data
static void repack_q8x4x2_q8_0(void * data, const lm_ggml_tensor * t, size_t size) {
    int64_t nrows = lm_ggml_nrows(t);

    size_t row_size    = lm_ggml_row_size(t->type, t->ne[0]);
    size_t row_size_pd = lm_ggml_row_size(t->type, hex_round_up(t->ne[0], QK_Q8_0x4x2));  // extra elements for the pad
    size_t row_size_rp = row_size_pd;  // scratch must hold one full padded tile (qblk_size quants + scales)

    // Ensure we don't try to copy more data than the tensor actually contains.
    const size_t total_tensor_size = (size_t)nrows * row_size;
    const size_t n_bytes_to_copy = size < total_tensor_size ? size : total_tensor_size;

    // Calculate how many full rows and how many remaining bytes we need to process.
    const int64_t n_full_rows = n_bytes_to_copy / row_size;
    const size_t  n_rem_bytes = n_bytes_to_copy % row_size;

    void * buf_pd = lm_ggml_aligned_malloc(row_size_pd);
    LM_GGML_ASSERT(buf_pd != NULL);

    void * buf_rp = lm_ggml_aligned_malloc(row_size_rp);
    LM_GGML_ASSERT(buf_rp != NULL);

    HEX_VERBOSE("ggml-hex: repack-q8x4x2-q8_0 %s : data %p size %zu dims %ldx%ld row-size %zu\n", t->name, data, size,
                t->ne[0], nrows, row_size);

    memset(buf_pd, 0, row_size_pd);  // clear-out padded buffer to make sure the tail is all zeros

    // 1. Process all the full rows
    for (int64_t i = 0; i < n_full_rows; i++) {
        const uint8_t * src = (const uint8_t *) t->data + (i * row_size);
        uint8_t *       dst = (uint8_t *) data + (i * row_size);

        memcpy(buf_pd, src, row_size);
        unpack_row_q8x4x2((block_q8_0 *) buf_rp, (const uint8_t *) buf_pd, t->ne[0]);
        memcpy(dst, buf_rp, row_size);
    }

    // 2. Process the final, potentially partial, row
    if (n_rem_bytes > 0) {
        const int64_t i = n_full_rows;
        const uint8_t * src = (const uint8_t *) t->data + (i * row_size);
        uint8_t *       dst = (uint8_t *) data + (i * row_size);

        // We still need to read and unpack the entire source row because quantization is block-based.
        memcpy(buf_pd, src, row_size);
        unpack_row_q8x4x2((block_q8_0 *) buf_rp, (const uint8_t *) buf_pd, t->ne[0]);

        // But we only copy the remaining number of bytes to the destination.
        memcpy(dst, buf_rp, n_rem_bytes);
    }

    lm_ggml_aligned_free(buf_pd, row_size_pd);
    lm_ggml_aligned_free(buf_rp, row_size_rp);
}

// ======== MXFP4x4x2 ====================
struct x2_mxfp4 {
    int v[2];
};

static x2_mxfp4 unpack_mxfp4(uint8_t v) {
    x2_mxfp4 x;
    x.v[0] = kvalues_mxfp4[(v & 0x0f)];
    x.v[1] = kvalues_mxfp4[(v >> 4)];
    return x;
}

static void dump_block_mxfp4(const block_mxfp4 * b, int i) {
    HEX_VERBOSE("ggml-hex: repack mxfp4 %d: %d %d %d %d ... %d %d %d %d : %.6f\n", i, unpack_mxfp4(b->qs[0]).v[0],
                unpack_mxfp4(b->qs[1]).v[0], unpack_mxfp4(b->qs[2]).v[0], unpack_mxfp4(b->qs[3]).v[0],
                unpack_mxfp4(b->qs[12]).v[1], unpack_mxfp4(b->qs[13]).v[1], unpack_mxfp4(b->qs[14]).v[1],
                unpack_mxfp4(b->qs[15]).v[1], LM_GGML_E8M0_TO_FP32_HALF(b->e));
}

static void dump_packed_block_mxfp4x4x2(const uint8_t * v, unsigned int i, size_t k) {
    static const int qk        = QK_MXFP4x4x2;
    const int        eblk_size = 8 * 1;   // 8x E8M0
    const int        qblk_size = qk / 2;  // int4
    const int        qrow_size = k / 2;   // int4 (not padded)

    const uint8_t * v_q = v + 0;          // quants first
    const uint8_t * v_e = v + qrow_size;  // then scales

    const uint8_t * q = v_q + i * qblk_size;
    const uint8_t * e = (const uint8_t *) (v_e + i * eblk_size);

    HEX_VERBOSE("ggml-hex: repack mxfp4x4x2-%d: %d %d %d %d ... %d %d %d %d ... %d %d %d %d : %.6f %.6f %.6f %.6f\n", i,
                unpack_mxfp4(q[0]).v[0], unpack_mxfp4(q[1]).v[0], unpack_mxfp4(q[2]).v[0], unpack_mxfp4(q[3]).v[0],
                unpack_mxfp4(q[60]).v[0], unpack_mxfp4(q[61]).v[0], unpack_mxfp4(q[62]).v[0], unpack_mxfp4(q[63]).v[0],
                unpack_mxfp4(q[124]).v[0], unpack_mxfp4(q[125]).v[0], unpack_mxfp4(q[126]).v[0],
                unpack_mxfp4(q[127]).v[0], LM_GGML_E8M0_TO_FP32_HALF(e[0]), LM_GGML_E8M0_TO_FP32_HALF(e[1]),
                LM_GGML_E8M0_TO_FP32_HALF(e[2]), LM_GGML_E8M0_TO_FP32_HALF(e[3]));

    HEX_VERBOSE("ggml-hex: repack mxfp4x4x2-%d: %d %d %d %d ... %d %d %d %d ... %d %d %d %d : %.6f %.6f %.6f %.6f\n",
                i + 1, unpack_mxfp4(q[0]).v[1], unpack_mxfp4(q[1]).v[1], unpack_mxfp4(q[2]).v[1],
                unpack_mxfp4(q[3]).v[1], unpack_mxfp4(q[60]).v[1], unpack_mxfp4(q[61]).v[1], unpack_mxfp4(q[62]).v[1],
                unpack_mxfp4(q[63]).v[1], unpack_mxfp4(q[124]).v[1], unpack_mxfp4(q[125]).v[1],
                unpack_mxfp4(q[126]).v[1], unpack_mxfp4(q[127]).v[1], LM_GGML_E8M0_TO_FP32_HALF(e[4]),
                LM_GGML_E8M0_TO_FP32_HALF(e[5]), LM_GGML_E8M0_TO_FP32_HALF(e[6]), LM_GGML_E8M0_TO_FP32_HALF(e[7]));
}

static void unpack_mxfp4_quants(uint8_t * qs, const block_mxfp4 * x, unsigned int bi) {
    static const int qk = QK_MXFP4;

    for (unsigned int i = 0; i < qk / 2; ++i) {
        const uint8_t x0         = (x->qs[i] & 0x0F);
        const uint8_t x1         = (x->qs[i] >> 4);
        qs[bi * qk + i + 0]      = x0;
        qs[bi * qk + i + qk / 2] = x1;
    }
}

static void pack_mxfp4_quants(block_mxfp4 * x, const uint8_t * qs, unsigned int bi) {
    static const int qk = QK4_0;

    for (unsigned int i = 0; i < qk / 2; ++i) {
        const uint8_t x0 = qs[bi * qk + i + 0];
        const uint8_t x1 = qs[bi * qk + i + qk / 2];
        x->qs[i]         = x0 | (x1 << 4);
    }
}

static void repack_row_mxfp4x4x2(uint8_t * y, const block_mxfp4 * x, int64_t k) {
    static const int qk = QK_MXFP4x4x2;
    const int        nb = (k + qk - 1) / qk;  // number of blocks (padded)
    const int        nloe = k % qk;           // leftovers

    const int eblk_size = 8 * 1;              // 8x E8M0
    const int qblk_size = qk / 2;             // int4
    const int qrow_size = k / 2;              // int4 (not padded to blocks)

    uint8_t * y_q = y + 0;                    // quants first
    uint8_t * y_e = y + qrow_size;            // then scales

    if (opt_verbose > 2) {
        for (int i = 0; i < nb; i++) {
            dump_block_mxfp4(&x[i * 8 + 0], 0);
            dump_block_mxfp4(&x[i * 8 + 1], 1);
            dump_block_mxfp4(&x[i * 8 + 2], 2);
            dump_block_mxfp4(&x[i * 8 + 3], 3);
            dump_block_mxfp4(&x[i * 8 + 4], 4);
            dump_block_mxfp4(&x[i * 8 + 5], 5);
            dump_block_mxfp4(&x[i * 8 + 6], 6);
            dump_block_mxfp4(&x[i * 8 + 7], 7);
        }
    }

    // Repack the quants
    for (int i = 0; i < nb; i++) {
        uint8_t qs[QK_MXFP4x4x2];  // unpacked quants

        unpack_mxfp4_quants(qs, &x[i * 8 + 0], 0);
        unpack_mxfp4_quants(qs, &x[i * 8 + 1], 1);
        unpack_mxfp4_quants(qs, &x[i * 8 + 2], 2);
        unpack_mxfp4_quants(qs, &x[i * 8 + 3], 3);
        unpack_mxfp4_quants(qs, &x[i * 8 + 4], 4);
        unpack_mxfp4_quants(qs, &x[i * 8 + 5], 5);
        unpack_mxfp4_quants(qs, &x[i * 8 + 6], 6);
        unpack_mxfp4_quants(qs, &x[i * 8 + 7], 7);

        bool partial = (nloe && i == nb-1);

        uint8_t * q = y_q + (i * qblk_size);
        for (int j = 0; j < qk / 2; j++) {
            q[j] = partial ? (qs[j*2+1] << 4) | qs[j*2+0] : (qs[j+128] << 4) | qs[j+000];
        }
    }

    // Repack the scales
    // Note: Do not combine with the loop above. For tensor sizes not multiple of 256 (QK_MXFP4x4x2)
    // the last block is truncated and overridden by the scales.
    for (int i = 0; i < nb; i++) {
        // Repack the scales
        uint8_t * e = (uint8_t *) (y_e + i * eblk_size);
        e[0]        = x[i * 8 + 0].e;
        e[1]        = x[i * 8 + 1].e;
        e[2]        = x[i * 8 + 2].e;
        e[3]        = x[i * 8 + 3].e;
        e[4]        = x[i * 8 + 4].e;
        e[5]        = x[i * 8 + 5].e;
        e[6]        = x[i * 8 + 6].e;
        e[7]        = x[i * 8 + 7].e;
    }

    if (opt_verbose > 2) {
        for (int i = 0; i < nb; i++) {
            dump_packed_block_mxfp4x4x2(y, i, k);
        }
    }
}

static void unpack_row_mxfp4x4x2(block_mxfp4 * x, const uint8_t * y, int64_t k) {
    static const int qk = QK_MXFP4x4x2;
    const int        nb = (k + qk - 1) / qk;  // number of blocks (padded)
    const int        nloe = k % qk;           // leftovers

    const int eblk_size = 8 * 1;              // 8x E8M0
    const int qblk_size = qk / 2;             // int4
    const int qrow_size = k / 2;              // int4 (not padded to blocks)

    const uint8_t * y_q = y + 0;              // quants first
    const uint8_t * y_e = y + qrow_size;      // then scales

    if (opt_verbose > 2) {
        for (int i = 0; i < nb; i++) {
            dump_packed_block_mxfp4x4x2(y, i, k);
        }
    }

    // Unpack the quants
    for (int i = 0; i < nb; i++) {
        uint8_t qs[QK_MXFP4x4x2];  // unpacked quants

        bool partial = (nloe && i == nb-1);

        const uint8_t * q = y_q + (i * qblk_size);
        for (int j = 0; j < qk / 2; j++) {
            if (partial) {
                qs[j*2+0] = q[j] & 0xf;
                qs[j*2+1] = q[j] >> 4;
            } else {
                qs[j+000] = q[j] & 0xf;
                qs[j+128] = q[j] >> 4;
            }
        }

        pack_mxfp4_quants(&x[i * 8 + 0], qs, 0);
        pack_mxfp4_quants(&x[i * 8 + 1], qs, 1);
        pack_mxfp4_quants(&x[i * 8 + 2], qs, 2);
        pack_mxfp4_quants(&x[i * 8 + 3], qs, 3);
        pack_mxfp4_quants(&x[i * 8 + 4], qs, 4);
        pack_mxfp4_quants(&x[i * 8 + 5], qs, 5);
        pack_mxfp4_quants(&x[i * 8 + 6], qs, 6);
        pack_mxfp4_quants(&x[i * 8 + 7], qs, 7);
    }

    // Repack the scales
    // Note: Do not combine with the loop above. For tensor sizes not multiple of 256 (QK_MXFP4_0x4x2)
    // the last block is truncated and overridden by the scales.
    for (int i = 0; i < nb; i++) {
        // Unpack the scales
        const uint8_t * e = (const uint8_t *) (y_e + i * eblk_size);
        x[i * 8 + 0].e    = e[0];
        x[i * 8 + 1].e    = e[1];
        x[i * 8 + 2].e    = e[2];
        x[i * 8 + 3].e    = e[3];
        x[i * 8 + 4].e    = e[4];
        x[i * 8 + 5].e    = e[5];
        x[i * 8 + 6].e    = e[6];
        x[i * 8 + 7].e    = e[7];
    }

    if (opt_verbose > 2) {
        for (int i = 0; i < nb; i++) {
            dump_block_mxfp4(&x[i * 8 + 0], 0);
            dump_block_mxfp4(&x[i * 8 + 1], 1);
            dump_block_mxfp4(&x[i * 8 + 2], 2);
            dump_block_mxfp4(&x[i * 8 + 3], 3);
            dump_block_mxfp4(&x[i * 8 + 4], 4);
            dump_block_mxfp4(&x[i * 8 + 5], 5);
            dump_block_mxfp4(&x[i * 8 + 6], 6);
            dump_block_mxfp4(&x[i * 8 + 7], 7);
        }
    }
}

static void init_row_mxfp4x4x2(block_mxfp4 * x, int64_t k) {
    static const int qk = QK_MXFP4x4x2;
    const int        nb = (k + qk - 1) / qk;  // number of blocks (padded)

    // Init the quants such that they unpack into zeros
    uint8_t qs[QK_MXFP4x4x2];  // unpacked quants
    memset(qs, 0, sizeof(qs));

    for (int i = 0; i < nb; i++) {
        pack_mxfp4_quants(&x[i * 8 + 0], qs, 0);
        pack_mxfp4_quants(&x[i * 8 + 1], qs, 1);
        pack_mxfp4_quants(&x[i * 8 + 2], qs, 2);
        pack_mxfp4_quants(&x[i * 8 + 3], qs, 3);
        pack_mxfp4_quants(&x[i * 8 + 4], qs, 4);
        pack_mxfp4_quants(&x[i * 8 + 5], qs, 5);
        pack_mxfp4_quants(&x[i * 8 + 6], qs, 6);
        pack_mxfp4_quants(&x[i * 8 + 7], qs, 7);
    }

    // Init the scales
    // Note: Do not combine with the loop above. For tensor sizes not multiple of 256 (QK_MXFP4x4x2)
    // the last block is truncated and overridden by the scales.
    for (int i = 0; i < nb; i++) {
        // Unpack the scales
        x[i * 8 + 0].e = 0;
        x[i * 8 + 1].e = 0;
        x[i * 8 + 2].e = 0;
        x[i * 8 + 3].e = 0;
        x[i * 8 + 4].e = 0;
        x[i * 8 + 5].e = 0;
        x[i * 8 + 6].e = 0;
        x[i * 8 + 7].e = 0;
    }
}

// repack mxfp4 data into mxfp4x4x2 tensor
static void repack_mxfp4_mxfp4x4x2(lm_ggml_tensor * t, const void * data, size_t size) {
    int64_t nrows = lm_ggml_nrows(t);

    size_t row_size    = lm_ggml_row_size(t->type, t->ne[0]);
    size_t row_size_pd = lm_ggml_row_size(t->type, hex_round_up(t->ne[0], QK_MXFP4x4x2));  // extra elements for the pad
    size_t row_size_rp = row_size_pd;  // scratch must hold one full padded tile (qblk_size/2 quants + scales)

    // Ensure we don't try to read more data than is available in the source buffer 'data'
    // or write more than the tensor can hold.
    const size_t total_tensor_size = (size_t)nrows * row_size;
    const size_t n_bytes_to_copy = size < total_tensor_size ? size : total_tensor_size;

    // Calculate how many full rows and how many remaining bytes we need to process.
    const int64_t n_full_rows = n_bytes_to_copy / row_size;
    const size_t  n_rem_bytes = n_bytes_to_copy % row_size;

    void * buf_pd = lm_ggml_aligned_malloc(row_size_pd);
    LM_GGML_ASSERT(buf_pd != NULL);

    void * buf_rp = lm_ggml_aligned_malloc(row_size_rp);
    LM_GGML_ASSERT(buf_rp != NULL);

    HEX_VERBOSE("ggml-hex: repack-mxfp4-mxfp4x4x2 %s : data %p size %zu dims %ldx%ld row-size %zu\n", t->name, data,
                size, t->ne[0], nrows, row_size);

    init_row_mxfp4x4x2((block_mxfp4 *) buf_pd, t->ne[0]);  // init padded buffer to make sure the tail is all zeros

    // 1. Process all the full rows
    for (int64_t i = 0; i < n_full_rows; i++) {
        const uint8_t * src = (const uint8_t *) data + (i * row_size);
        uint8_t *       dst = (uint8_t *) t->data + (i * row_size);

        memcpy(buf_pd, src, row_size);
        repack_row_mxfp4x4x2((uint8_t *) buf_rp, (const block_mxfp4 *) buf_pd, t->ne[0]);
        memcpy(dst, buf_rp, row_size);
    }

    // 2. Process the final, potentially partial, row
    if (n_rem_bytes > 0) {
        const int64_t i = n_full_rows;
        const uint8_t * src = (const uint8_t *) data + (i * row_size);
        uint8_t *       dst = (uint8_t *) t->data + (i * row_size);

        // re-init the row because we are potentially copying a partial row
        init_row_mxfp4x4x2((block_mxfp4 *) buf_pd, t->ne[0]);

        // Copy only the remaining bytes from the source.
        memcpy(buf_pd, src, n_rem_bytes);

        // Repack the entire buffer (partial data + zero padding).
        repack_row_mxfp4x4x2((uint8_t *) buf_rp, (const block_mxfp4 *) buf_pd, t->ne[0]);

        // Write only the corresponding remaining bytes to the destination tensor.
        memcpy(dst, buf_rp, n_rem_bytes);
    }

    lm_ggml_aligned_free(buf_pd, row_size_pd);
    lm_ggml_aligned_free(buf_rp, row_size_rp);
}

// repack mxfp4x4x2 tensor into mxfp4 data
static void repack_mxfp4x4x2_mxfp4(void * data, const lm_ggml_tensor * t, size_t size) {
    int64_t nrows = lm_ggml_nrows(t);

    size_t row_size    = lm_ggml_row_size(t->type, t->ne[0]);
    size_t row_size_pd = lm_ggml_row_size(t->type, hex_round_up(t->ne[0], QK_MXFP4x4x2));  // extra elements for the pad
    size_t row_size_rp = row_size_pd;  // scratch must hold one full padded tile (qblk_size/2 quants + scales)

    // Ensure we don't try to copy more data than the tensor actually contains.
    const size_t total_tensor_size = (size_t)nrows * row_size;
    const size_t n_bytes_to_copy = size < total_tensor_size ? size : total_tensor_size;

    // Calculate how many full rows and how many remaining bytes we need to process.
    const int64_t n_full_rows = n_bytes_to_copy / row_size;
    const size_t  n_rem_bytes = n_bytes_to_copy % row_size;

    void * buf_pd = lm_ggml_aligned_malloc(row_size_pd);
    LM_GGML_ASSERT(buf_pd != NULL);

    void * buf_rp = lm_ggml_aligned_malloc(row_size_rp);
    LM_GGML_ASSERT(buf_rp != NULL);

    HEX_VERBOSE("ggml-hex: repack-mxfp4x4x2-mxfp4 %s : data %p size %zu dims %ldx%ld row-size %zu\n", t->name, data,
                size, t->ne[0], nrows, row_size);

    memset(buf_pd, 0, row_size_pd);  // clear-out padded buffer to make sure the tail is all zeros

    // 1. Process all the full rows
    for (int64_t i = 0; i < n_full_rows; i++) {
        const uint8_t * src = (const uint8_t *) t->data + (i * row_size);
        uint8_t *       dst = (uint8_t *) data + (i * row_size);

        memcpy(buf_pd, src, row_size);
        unpack_row_mxfp4x4x2((block_mxfp4 *) buf_rp, (const uint8_t *) buf_pd, t->ne[0]);
        memcpy(dst, buf_rp, row_size);
    }

    // 2. Process the final, potentially partial, row
    if (n_rem_bytes > 0) {
        const int64_t i = n_full_rows;
        const uint8_t * src = (const uint8_t *) t->data + (i * row_size);
        uint8_t *       dst = (uint8_t *) data + (i * row_size);

        // We still need to read and unpack the entire source row because the format is block-based.
        memcpy(buf_pd, src, row_size);
        unpack_row_mxfp4x4x2((block_mxfp4 *) buf_rp, (const uint8_t *) buf_pd, t->ne[0]);

        // But we only copy the remaining number of bytes to the destination to respect the size limit.
        memcpy(dst, buf_rp, n_rem_bytes);
    }

    lm_ggml_aligned_free(buf_pd, row_size_pd);
    lm_ggml_aligned_free(buf_rp, row_size_rp);
}

static void lm_ggml_backend_hexagon_buffer_set_tensor(lm_ggml_backend_buffer_t buffer,
                                                   lm_ggml_tensor *         tensor,
                                                   const void *          data,
                                                   size_t                offset,
                                                   size_t                size) {
    auto sbuf = (lm_ggml_hexagon_shared_buffer *) buffer->context;
    auto sess = sbuf->sess;

    HEX_VERBOSE("ggml-hex: %s set-tensor %s : data %p offset %zu size %zu\n", sess->c_name(), tensor->name, data, offset, size);

    switch (tensor->type) {
        case LM_GGML_TYPE_Q4_0:
            LM_GGML_ASSERT(offset == 0);
            LM_GGML_ASSERT(offset + size <= lm_ggml_nbytes(tensor));
            repack_q4_0_q4x4x2(tensor, data, size);
            break;

        case LM_GGML_TYPE_Q4_1:
            LM_GGML_ASSERT(offset == 0);
            LM_GGML_ASSERT(offset + size <= lm_ggml_nbytes(tensor));
            repack_q4_1_q4x4x2(tensor, data, size);
            break;

        case LM_GGML_TYPE_Q8_0:
            LM_GGML_ASSERT(offset == 0);
            LM_GGML_ASSERT(offset + size <= lm_ggml_nbytes(tensor));
            repack_q8_0_q8x4x2(tensor, data, size);
            break;

        case LM_GGML_TYPE_IQ4_NL:
            LM_GGML_ASSERT(offset == 0);
            LM_GGML_ASSERT(offset + size <= lm_ggml_nbytes(tensor));
            // IQ4_NL has identical block layout to Q4_0 (lm_ggml_half d + uint8_t qs[16])
            repack_q4_0_q4x4x2(tensor, data, size);
            break;

        case LM_GGML_TYPE_MXFP4:
            LM_GGML_ASSERT(offset == 0);
            LM_GGML_ASSERT(offset + size <= lm_ggml_nbytes(tensor));
            repack_mxfp4_mxfp4x4x2(tensor, data, size);
            break;

        default:
            memcpy((char *) tensor->data + offset, data, size);
            break;
    }
}

static void lm_ggml_backend_hexagon_buffer_get_tensor(lm_ggml_backend_buffer_t buffer,
                                                   const lm_ggml_tensor *   tensor,
                                                   void *                data,
                                                   size_t                offset,
                                                   size_t                size) {
    auto sbuf = (lm_ggml_hexagon_shared_buffer *) buffer->context;
    auto sess = sbuf->sess;

    HEX_VERBOSE("ggml-hex: %s get-tensor %s : data %p offset %zu size %zu\n", sess->c_name(), tensor->name, data, offset, size);

    switch (tensor->type) {
        case LM_GGML_TYPE_Q4_0:
            LM_GGML_ASSERT(offset == 0);
            LM_GGML_ASSERT(offset + size <= lm_ggml_nbytes(tensor));
            repack_q4x4x2_q4_0(data, tensor, size);
            break;

        case LM_GGML_TYPE_Q4_1:
            LM_GGML_ASSERT(offset == 0);
            LM_GGML_ASSERT(offset + size <= lm_ggml_nbytes(tensor));
            repack_q4x4x2_q4_1(data, tensor, size);
            break;

        case LM_GGML_TYPE_Q8_0:
            LM_GGML_ASSERT(offset == 0);
            LM_GGML_ASSERT(offset + size <= lm_ggml_nbytes(tensor));
            repack_q8x4x2_q8_0(data, tensor, size);
            break;

        case LM_GGML_TYPE_IQ4_NL:
            LM_GGML_ASSERT(offset == 0);
            LM_GGML_ASSERT(offset + size <= lm_ggml_nbytes(tensor));
            repack_q4x4x2_q4_0(data, tensor, size);
            break;

        case LM_GGML_TYPE_MXFP4:
            LM_GGML_ASSERT(offset == 0);
            LM_GGML_ASSERT(offset + size <= lm_ggml_nbytes(tensor));
            repack_mxfp4x4x2_mxfp4(data, tensor, size);
            break;

        default:
            memcpy(data, (const char *) tensor->data + offset, size);
            break;
    }
}

static bool lm_ggml_backend_hexagon_buffer_cpy_tensor(lm_ggml_backend_buffer_t      buffer,
                                                   const struct lm_ggml_tensor * src,
                                                   struct lm_ggml_tensor *       dst) {
    LM_GGML_UNUSED(buffer);
    LM_GGML_UNUSED(src);
    LM_GGML_UNUSED(dst);
    // we might optimize this later, for now take the slow path (ie get/set_tensor)
    return false;
}

static void lm_ggml_backend_hexagon_buffer_clear(lm_ggml_backend_buffer_t buffer, uint8_t value) {
    auto sbuf = (lm_ggml_hexagon_shared_buffer *) buffer->context;
    auto sess = sbuf->sess;
    HEX_VERBOSE("ggml-hex: %s clear-buff base %p size %zu\n", sess->c_name(), (void *) sbuf->base, sbuf->size);
    memset(sbuf->base, value, sbuf->size);
}

static lm_ggml_backend_buffer_i lm_ggml_backend_hexagon_buffer_interface = {
    /* .free_buffer     = */ lm_ggml_backend_hexagon_buffer_free_buffer,
    /* .get_base        = */ lm_ggml_backend_hexagon_buffer_get_base,
    /* .init_tensor     = */ lm_ggml_backend_hexagon_buffer_init_tensor,
    /* .memset_tensor   = */ NULL,
    /* .set_tensor      = */ lm_ggml_backend_hexagon_buffer_set_tensor,
    /* .get_tensor      = */ lm_ggml_backend_hexagon_buffer_get_tensor,
    /* .set_tensor_2d   = */ NULL,
    /* .get_tensor_2d   = */ NULL,
    /* .cpy_tensor      = */ lm_ggml_backend_hexagon_buffer_cpy_tensor,
    /* .clear           = */ lm_ggml_backend_hexagon_buffer_clear,
    /* .reset           = */ NULL,
};

// ** backend buffer type

static const char * lm_ggml_backend_hexagon_buffer_type_name(lm_ggml_backend_buffer_type_t buffer_type) {
    return static_cast<lm_ggml_backend_hexagon_buffer_type_context *>(buffer_type->context)->name.c_str();
}

static lm_ggml_backend_buffer_t lm_ggml_backend_hexagon_buffer_type_alloc_buffer(
            lm_ggml_backend_buffer_type_t buffer_type, size_t size) {
    auto sess = static_cast<lm_ggml_backend_hexagon_buffer_type_context *>(buffer_type->context)->sess;
    try {
        size += 4 * 1024;  // guard page
        lm_ggml_hexagon_shared_buffer * sbuf = new lm_ggml_hexagon_shared_buffer(sess, size);
        return lm_ggml_backend_buffer_init(buffer_type, lm_ggml_backend_hexagon_buffer_interface, sbuf, size);
    } catch (const std::exception & exc) {
        LM_GGML_LOG_ERROR("ggml-hex: %s failed to allocate buffer context (host): %s\n", sess->c_name(), exc.what());
        return nullptr;
    }
}

static lm_ggml_backend_buffer_t lm_ggml_backend_hexagon_repack_buffer_type_alloc_buffer(
            lm_ggml_backend_buffer_type_t buffer_type, size_t size) {
    auto sess = static_cast<lm_ggml_backend_hexagon_buffer_type_context *>(buffer_type->context)->sess;
    try {
        size += 4 * 1024;  // guard page
        lm_ggml_hexagon_shared_buffer * sbuf = new lm_ggml_hexagon_shared_buffer(sess, size);
        return lm_ggml_backend_buffer_init(buffer_type, lm_ggml_backend_hexagon_buffer_interface, sbuf, size);
    } catch (const std::exception & exc) {
        LM_GGML_LOG_ERROR("ggml-hex: %s failed to allocate buffer context (repack): %s\n", sess->c_name(), exc.what());
        return nullptr;
    }
}

static size_t lm_ggml_backend_hexagon_buffer_type_get_alignment(lm_ggml_backend_buffer_type_t buffer_type) {
    return 128;  // HVX alignment
    LM_GGML_UNUSED(buffer_type);
}

static size_t lm_ggml_backend_hexagon_buffer_type_get_alloc_size(lm_ggml_backend_buffer_type_t buft, const struct lm_ggml_tensor * t) {
    return lm_ggml_nbytes(t);
}

static size_t lm_ggml_backend_hexagon_buffer_type_get_max_size(lm_ggml_backend_buffer_type_t buffer_type) {
    return opt_mbuf; // typically 1GB per buffer
    LM_GGML_UNUSED(buffer_type);
}

static bool lm_ggml_backend_hexagon_buffer_type_is_host(lm_ggml_backend_buffer_type_t buft) {
    return opt_hostbuf;
    LM_GGML_UNUSED(buft);
}

static bool lm_ggml_backend_hexagon_repack_buffer_type_is_host(lm_ggml_backend_buffer_type_t buft) {
    return false;
    LM_GGML_UNUSED(buft);
}

static lm_ggml_backend_buffer_type_i lm_ggml_backend_hexagon_buffer_type_interface = {
    /* .get_name         = */ lm_ggml_backend_hexagon_buffer_type_name,
    /* .alloc_buffer     = */ lm_ggml_backend_hexagon_buffer_type_alloc_buffer,
    /* .get_alignment    = */ lm_ggml_backend_hexagon_buffer_type_get_alignment,
    /* .get_max_size     = */ lm_ggml_backend_hexagon_buffer_type_get_max_size,
    /* .get_alloc_size   = */ lm_ggml_backend_hexagon_buffer_type_get_alloc_size,
    /* .is_host          = */ lm_ggml_backend_hexagon_buffer_type_is_host,
};

static lm_ggml_backend_buffer_type_i lm_ggml_backend_hexagon_repack_buffer_type_interface = {
    /* .get_name         = */ lm_ggml_backend_hexagon_buffer_type_name,
    /* .alloc_buffer     = */ lm_ggml_backend_hexagon_repack_buffer_type_alloc_buffer,
    /* .get_alignment    = */ lm_ggml_backend_hexagon_buffer_type_get_alignment,
    /* .get_max_size     = */ lm_ggml_backend_hexagon_buffer_type_get_max_size,
    /* .get_alloc_size   = */ lm_ggml_backend_hexagon_buffer_type_get_alloc_size,
    /* .is_host          = */ lm_ggml_backend_hexagon_repack_buffer_type_is_host,
};

struct lm_ggml_hexagon_opbatch {
    lm_ggml_hexagon_session*            sess;

    std::vector<htp_opnode>          ops;       // htp_opnode of ops

    std::vector<htp_buf_desc>        h_bufs;    // htp buffer descriptors
    std::vector<htp_tensor>          h_tens;    // htp tensor descriptors
    std::vector<htp_op_desc>         h_ops;     // htp op descriptors

    std::unordered_map<int, int>                b_map; // buffer fd   to index
    std::unordered_map<const lm_ggml_tensor*, int> t_map; // tensor ptr  to index
    std::unordered_multimap<void*, int>         d_map; // tensor data to index

    unsigned int n_bufs;     // num buffers in the batch
    unsigned int n_tens;     // num tensors ...
    unsigned int n_ops;      // num ops ...
    size_t       b_vmem;     // sum of all buffer sizes

    unsigned int n_bufs_max;
    unsigned int n_tens_max;
    unsigned int n_ops_max;
    size_t       b_vmem_max;

    void reset() {
        n_bufs = 0;
        n_tens = 0;
        n_ops  = 0;
        b_vmem = 0;

        b_map.clear();
        t_map.clear();
        d_map.clear();
    }

    lm_ggml_hexagon_opbatch(lm_ggml_hexagon_session *sess, size_t batch_size, size_t max_vmem) {
        this->sess = sess;

        n_bufs_max = HTP_OP_MAX_BUFS;
        n_ops_max  = batch_size;
        n_tens_max = n_ops_max + n_ops_max * HTP_OP_MAX_INPUTS;

        b_vmem_max = max_vmem;

        ops.resize(n_ops_max);

        h_bufs.resize(n_bufs_max);
        h_tens.resize(n_tens_max);
        h_ops.resize(n_ops_max);

        b_map.reserve(n_bufs_max);
        t_map.reserve(n_tens_max);
        d_map.reserve(n_tens_max);

        LM_GGML_LOG_INFO("ggml-hex: %s op batching: n-bufs %u n-tensors %u n-ops %u vmem %zu\n",
                sess->c_name(), n_bufs_max, n_tens_max, n_ops_max, b_vmem_max);

        reset();
    }

    bool empty() const { return n_ops == 0; }

    // add buffer and return its index
    int add_buffer(lm_ggml_hexagon_shared_buffer * sbuf) {
        // Lookup by fd
        auto it = b_map.find(sbuf->fd);
        if (it != b_map.end()) { return it->second; }

        // Add new buffer to the batch
        int bi = n_bufs++;
        LM_GGML_ASSERT(n_bufs < HTP_OP_MAX_BUFS);

        b_map.insert({sbuf->fd, bi});

        htp_buf_desc &b = h_bufs[bi];
        b.base = (uint64_t) sbuf->base;
        b.fd   = sbuf->fd;
        b.size = sbuf->size;

        b_vmem += b.size;

        HEX_VERBOSE("ggml-hex: add-buffer #%u : fd %d base %p size %zu : vmem %zu\n", bi, b.fd, (void*) sbuf->base, (size_t) b.size, b_vmem);

        return bi;
    }

    bool same_shape(const htp_tensor * h, const lm_ggml_tensor * t) const {
        return (h->ne[0] == t->ne[0]) && (h->ne[1] == t->ne[1]) && (h->ne[2] == t->ne[2]) && (h->ne[3] == t->ne[3]) &&
               (h->nb[0] == t->nb[0]) && (h->nb[1] == t->nb[1]) && (h->nb[2] == t->nb[2]) && (h->nb[3] == t->nb[3]);
    }

    // add tensor and return its index
    int add_tensor(const lm_ggml_tensor * t) {
        auto sbuf = static_cast<lm_ggml_hexagon_shared_buffer *>(t->buffer->context);

        // First lookup by tensor data
        auto range = d_map.equal_range(t->data);
        for (auto it = range.first; it != range.second; ++it) {
            htp_tensor * h = &h_tens[it->second];
            if (same_shape(h, t)) { return it->second; }
        }

        // Lookup by tensor ptr
        auto it = t_map.find(t);
        if (it != t_map.end()) { return it->second; }

        // Add new tensor to the batch
        int ti = n_tens++;
        LM_GGML_ASSERT(n_tens <= n_tens_max);

        t_map.insert({t,       ti});
        d_map.insert({t->data, ti});

        uint64_t t_offset = (uint8_t *) t->data - sbuf->base;
        size_t   t_size   = lm_ggml_nbytes(t);

        htp_tensor &h = h_tens[ti];
        h.bi    = add_buffer(sbuf);
        h.data  = t_offset;
        h.size  = t_size;
        h.type  = t->type;
        h.ne[0] = t->ne[0]; h.ne[1] = t->ne[1]; h.ne[2] = t->ne[2]; h.ne[3] = t->ne[3];
        h.nb[0] = t->nb[0]; h.nb[1] = t->nb[1]; h.nb[2] = t->nb[2]; h.nb[3] = t->nb[3];

        h.flags = 0;
        if (lm_ggml_backend_buffer_get_usage(t->buffer) == LM_GGML_BACKEND_BUFFER_USAGE_COMPUTE) {
            h.flags |= HTP_TENSOR_COMPUTE;
        }

        HEX_VERBOSE("ggml-hex: add-tensor #%u %s : bi %d data %p offset %zu size %zu flags 0x%x : %zu:%zu:%zu:%zu\n",
                ti, t->name, h.bi, (void*) t->data, (size_t) t_offset, t_size, h.flags,
                (size_t) t->ne[0], (size_t) t->ne[1], (size_t) t->ne[2], (size_t) t->ne[3]);

        return ti;
    }

    bool fit_op(const htp_opnode & node) const {
        if (n_ops >= n_ops_max ) return false;

        // check how much extras we will need
        size_t extra_bufs = 0;
        size_t extra_vmem = 0;
        size_t extra_tens = 0;

        auto fit_tensor = [&](const lm_ggml_tensor *t) {
            if (!t) return;
            if (!t_map.count(t)) {
                extra_tens++;

                auto sbuf = static_cast<lm_ggml_hexagon_shared_buffer *>(t->buffer->context);
                if (!b_map.count(sbuf->fd)) {
                    extra_vmem += sbuf->size;
                    extra_bufs += 1;
                }
            }
        };

        for (const auto * src : node.get_inputs()) {
            fit_tensor(src);
        }
        fit_tensor(node.dst());

        if ((extra_bufs + n_bufs) > n_bufs_max) return false;
        if ((extra_tens + n_tens) > n_tens_max) return false;
        if ((extra_vmem + b_vmem) > b_vmem_max) return false;

        return true;
    }

    // assumes that fit_op() was called first and returned true
    void add_op(const htp_opnode & node) {
        // Add new op

        unsigned int n = n_ops++;
        LM_GGML_ASSERT(n_ops <= n_ops_max);

        ops[n] = node;

        htp_op_desc &o = h_ops[n];
        memcpy(&o.params, &node.node->op_params, sizeof(node.node->op_params));
        o.opcode = node.opcode;
        o.flags  = 0;

        if (!(opt_opstage & HTP_OPSTAGE_COMPUTE)) {
            o.flags |= HTP_OPFLAGS_SKIP_COMPUTE;
        }

        lm_ggml_hexagon_dump_op_exec(sess->c_name(), node, o.flags);

        auto inputs = node.get_inputs();
        for (unsigned int i=0; i < HTP_OP_MAX_INPUTS; i++) {
            o.src[i] = (i < inputs.size() && inputs[i]) ? add_tensor(inputs[i]) : 0xffff;
        }
        o.dst = add_tensor(node.dst());
    }
};

struct lm_ggml_hexagon_opqueue {
    // Shared buffer for storing batches
    lm_ggml_hexagon_shared_buffer *shm_buf;
    size_t                      shm_blk_size;

    using opvec = std::vector<htp_opnode>;

    std::queue<unsigned int>    done;       // completed batch ids
    std::vector<opvec>          op_cache;   // per batch op cache
    std::vector<uint64_t>       start_usec; // per batch start time

    lm_ggml_hexagon_opqueue(lm_ggml_hexagon_session *sess, size_t batch_size, size_t depth) {
        size_t n_bufs    = HTP_OP_MAX_BUFS;
        size_t n_ops     = batch_size;
        size_t n_tensors = n_ops + n_ops * HTP_OP_MAX_INPUTS;

        size_t tr_size = 0;
        if (opt_profile == 3) {
            tr_size = (HTP_MAX_NTHREADS + 1) * opt_optrace * sizeof(htp_trace_desc);
        }

        shm_blk_size = sizeof(htp_buf_desc)  * n_bufs    +
                       sizeof(htp_tensor)    * n_tensors +
                       sizeof(htp_op_desc)   * n_ops     +
                       sizeof(htp_prof_desc) * n_ops     +
                       tr_size;

        shm_buf = new lm_ggml_hexagon_shared_buffer(sess, shm_blk_size * depth, true /* pinned */);

        op_cache.resize(depth);
        start_usec.resize(depth, 0);

        // init done queue
        for (unsigned int i = 0; i < depth; i++) { done.push(i); }

        if (opt_verbose) {
            LM_GGML_LOG_INFO("ggml-hex: %s allocated op-queue : batch-size %zu depth %zu shm-size %zu shm-block-size %zu\n",
                    sess->c_name(), batch_size, depth, shm_buf->size, shm_blk_size);
        }
    }

    ~lm_ggml_hexagon_opqueue() {
        delete shm_buf;
    }

    // push new batch
    bool push(htp_opbatch_req& req, dspqueue_buffer& dbuf, lm_ggml_hexagon_opbatch* op_batch) {
        static_assert(sizeof(htp_opbatch_req) % 8 == 0, "sizeof(htp_opbatch_req) must be multiple of 8");
        static_assert(sizeof(htp_opbatch_rsp) % 8 == 0, "sizeof(htp_opbatch_rsp) must be multiple of 8");
        static_assert(sizeof(htp_buf_desc)    % 8 == 0, "sizeof(htp_buf_desc) must be multiple of 8");
        static_assert(sizeof(htp_tensor)      % 8 == 0, "sizeof(htp_tensor) must be multiple of 8");
        static_assert(sizeof(htp_op_desc)     % 8 == 0, "sizeof(htp_op_desc) must be multiple of 8");
        static_assert(sizeof(htp_prof_desc)   % 8 == 0, "sizeof(htp_prof_desc) must be multiple of 8");

        if (done.empty()) { return false; }

        req.id        = done.front(); done.pop(); // batch id
        req.n_bufs    = op_batch->n_bufs;
        req.n_tensors = op_batch->n_tens;
        req.n_ops     = op_batch->n_ops;

        op_cache[req.id]   = op_batch->ops;
        start_usec[req.id] = lm_ggml_time_us();

        const size_t b_size = sizeof(htp_buf_desc)  * req.n_bufs;
        const size_t t_size = sizeof(htp_tensor)    * req.n_tensors;
        const size_t o_size = sizeof(htp_op_desc)   * req.n_ops;
        const size_t p_size = sizeof(htp_prof_desc) * req.n_ops;

        size_t tr_size = 0;
        if (opt_profile == 3) {
            req.n_traces = opt_optrace;
            tr_size = (HTP_MAX_NTHREADS + 1) * req.n_traces * sizeof(htp_trace_desc);
        } else {
            req.n_traces = 0;
        }

        dbuf.ptr      = shm_buf->base + (req.id * shm_blk_size);
        dbuf.fd       = shm_buf->fd;
        dbuf.flags    = DSPQUEUE_BUFFER_FLAG_FLUSH_SENDER | DSPQUEUE_BUFFER_FLAG_INVALIDATE_RECIPIENT;
        dbuf.offset   = (uint8_t*) dbuf.ptr - (uint8_t*) shm_buf->base;
        dbuf.size     = b_size + t_size + o_size + p_size + tr_size;

        LM_GGML_ASSERT(dbuf.size <= shm_blk_size);

        uint8_t * m_ptr = (uint8_t*) dbuf.ptr;
        uint8_t * b_ptr = m_ptr; m_ptr += b_size;
        uint8_t * t_ptr = m_ptr; m_ptr += t_size;
        uint8_t * o_ptr = m_ptr;

        memcpy(b_ptr, (void *) op_batch->h_bufs.data(), b_size);
        memcpy(t_ptr, (void *) op_batch->h_tens.data(), t_size);
        memcpy(o_ptr, (void *) op_batch->h_ops.data(),  o_size);

        HEX_VERBOSE("ggml-hex: %s op-queue push batch #%u : n-bufs %u n-tensors %u n-ops %u vmem %zu : b-size %zu t-size %zu o-size %zu m-size %zu\n",
                shm_buf->sess->c_name(), req.id, req.n_bufs, req.n_tensors, req.n_ops, op_batch->b_vmem,
                b_size, t_size, o_size, (size_t) dbuf.size);

        op_batch->reset();

        if (opt_verbose > 1) {
            htp_buf_desc *b = (htp_buf_desc*) b_ptr;
            for (unsigned int i=0; i < req.n_bufs; i++) {
                LM_GGML_LOG_DEBUG("ggml-hex: %s htp-buf #%u : fd %d base %p size %zu\n", shm_buf->sess->c_name(), i,
                            b[i].fd, (void *) b[i].base, (size_t) b[i].size);
            }
            htp_tensor *t = (htp_tensor*) t_ptr;
            for (unsigned int i=0; i < req.n_tensors; i++) {
                LM_GGML_LOG_DEBUG("ggml-hex: %s htp-tensor #%u : bi %u offset %u size %u : %zu:%zu:%zu:%zu\n",
                            shm_buf->sess->c_name(), i, t[i].bi, t[i].data, t[i].size,
                            (size_t) t[i].ne[0], (size_t) t[i].ne[1], (size_t) t[i].ne[2], (size_t) t[i].ne[3]);
            }
        }

        return true;
    }

    void pop(htp_opbatch_rsp rsp, dspqueue_buffer dbuf) {
        LM_GGML_ASSERT(rsp.id < op_cache.size());

        done.push(rsp.id);

        const size_t b_size = sizeof(htp_buf_desc)  * rsp.n_bufs;
        const size_t t_size = sizeof(htp_tensor)    * rsp.n_tensors;
        const size_t o_size = sizeof(htp_op_desc)   * rsp.n_ops;
        const size_t p_size = sizeof(htp_prof_desc) * rsp.n_ops;

        size_t tr_size = 0;
        uint32_t n_traces = 0;
        if (opt_profile == 3) {
            n_traces = opt_optrace;
            tr_size = (HTP_MAX_NTHREADS + 1) * n_traces * sizeof(htp_trace_desc);
        }

        const size_t m_size = b_size + t_size + o_size + p_size + tr_size;
        LM_GGML_ASSERT(m_size <= shm_blk_size);

        HEX_VERBOSE("ggml-hex: %s op-queue pop batch #%u : n-bufs %u n-tensors %u n-ops %u : m-size %zu b-size %zu t-size %zu o-size %zu\n",
                shm_buf->sess->c_name(), rsp.id, rsp.n_bufs, rsp.n_tensors, rsp.n_ops,
                (size_t) dbuf.size, b_size, t_size, o_size);

        uint8_t * m_ptr = (uint8_t*) dbuf.ptr;
        uint8_t * p_ptr = m_ptr + (b_size + t_size + o_size);

        if (opt_profile && rsp.n_ops > 0) {
            auto & ops = op_cache[rsp.id];

            uint64_t batch_usec = lm_ggml_time_us() - start_usec[rsp.id];
            uint32_t htp_usec   = 0;

            LM_GGML_ASSERT(rsp.n_ops <= ops.size());

            const htp_prof_desc * pd = (const htp_prof_desc *) p_ptr;

            const htp_trace_desc * trace_events = nullptr;

            if (opt_profile == 3) {
                trace_events = (const htp_trace_desc *) (p_ptr + p_size);
            }

            uint32_t trace_idx[HTP_MAX_NTHREADS + 1] = {0};
            uint32_t valid_cnt[HTP_MAX_NTHREADS + 1] = {0};

            if (opt_profile == 3) {
                for (uint32_t t = 0; t <= HTP_MAX_NTHREADS; t++) {
                    uint32_t count = rsp.n_traces[t];
                    valid_cnt[t] = count > n_traces ? n_traces : count;
                }
            }

            for (uint32_t i = 0; i < rsp.n_ops; i++) {
                htp_usec += pd[i].usecs;

                lm_ggml_hexagon_dump_op_prof(shm_buf->sess->name, ops[i], pd[i]);

                if (opt_profile == 3) {
                    uint32_t op_duration = pd[i].cycles_stop - pd[i].cycles_start;

                    for (uint32_t t = 0; t <= HTP_MAX_NTHREADS; t++) {
                        while (trace_idx[t] < valid_cnt[t]) {
                            const auto & e = trace_events[t * n_traces + trace_idx[t]];
                            uint32_t offset = e.cycles - pd[i].cycles_start;
                            if (offset >= 0x80000000) {
                                trace_idx[t]++;
                                continue;
                            }
                            if (offset > op_duration) {
                                break;
                            }
                            bool is_stop = (e.info & 0x8000) != 0;
                            uint16_t info = e.info & 0x7FFF;
                            LM_GGML_LOG_DEBUG("ggml-hex: %s trace-op %s: thread %u event %s info %u %s %u\n",
                                           shm_buf->sess->c_name(), ops[i].op_name().c_str(), t, htp_event_name(e.id), info, is_stop ? "stop" : "start", e.cycles);
                            trace_idx[t]++;
                        }
                    }
                }
            }

            char evt_str[256] = "";
            if (opt_profile == 3) {
                sprintf(evt_str, " evt [%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u]",
                        rsp.n_traces[0], rsp.n_traces[1], rsp.n_traces[2], rsp.n_traces[3],
                        rsp.n_traces[4], rsp.n_traces[5], rsp.n_traces[6], rsp.n_traces[7],
                        rsp.n_traces[8], rsp.n_traces[9], rsp.n_traces[10]);
            }

            LM_GGML_LOG_DEBUG("ggml-hex: %s profile-batch n-ops %u batch-dur-usec %lld htp-ops-usec %u%s\n",
                           shm_buf->sess->c_name(), rsp.n_ops, (long long) batch_usec, htp_usec, evt_str);
        }
    }
};

// Flush HTP response queue i.e wait for all outstanding requests to complete
void lm_ggml_hexagon_session::flush_pending(bool all) {
    while (this->op_pending) {
        struct htp_opbatch_rsp rsp;
        uint32_t               rsp_size;
        uint32_t               flags;

        struct dspqueue_buffer dbuf;
        uint32_t               n_dbufs;

        // Read response packet from queue
        const uint32_t timeo = opt_oppoll ? 0 : DSPQUEUE_TIMEOUT;
        int err = dspqueue_read(this->queue, &flags, 1, &n_dbufs, &dbuf, sizeof(rsp), &rsp_size, (uint8_t *) &rsp, timeo);
        if (err == AEE_EEXPIRED) {
            continue;
        }

        if (err != 0) {
            LM_GGML_ABORT("ggml-hex: dspqueue_read failed: 0x%08x\n", (unsigned) err);
        }

        // Basic sanity checks
        if (rsp_size != sizeof(rsp) || n_dbufs != 1) {
            LM_GGML_ABORT("ggml-hex: %s dspcall : bad response : size %u dspbufs %u\n", this->c_name(), rsp_size, n_dbufs);
        }

        if (rsp.status != HTP_STATUS_OK) {
            LM_GGML_LOG_ERROR("ggml-hex: %s dspcall : dsp-rsp: %s\n", this->c_name(), status_to_str(rsp.status));
            // TODO: handle errors
        }

        op_queue->pop(rsp, dbuf);

        this->op_pending--;  // atomic dec

        if (!all) break;
    }
}

void lm_ggml_hexagon_session::flush_batch() {
    if (op_batch->empty()) { return; }

    htp_opbatch_req req {};
    dspqueue_buffer dbuf{};

    if (!op_queue->push(req, dbuf, op_batch)) {
        flush_pending(false);
        op_queue->push(req, dbuf, op_batch);
    }

    // Bump pending flag (cleared in the session::flush once we get the response)
    this->op_pending++;  // atomic inc

    HEX_VERBOSE("ggml-hex: %s queue-opbatch: %p size %u\n", this->c_name(), dbuf.ptr, dbuf.size);

    int err = dspqueue_write(this->queue, 0, 1, &dbuf, sizeof(req), (const uint8_t*) &req, DSPQUEUE_TIMEOUT);
    if (err != 0) {
        LM_GGML_ABORT("ggml-hex: %s dspqueue_write failed: 0x%08x\n", this->c_name(), (unsigned) err);
    }
}

void lm_ggml_hexagon_session::enqueue_op(const htp_opnode & node) {
    if (!op_batch->fit_op(node)) {
        flush_batch();
    }
    op_batch->add_op(node);
}

// Flush HTP response queue i.e wait for all outstanding requests to complete
void lm_ggml_hexagon_session::flush(bool all) {
    flush_batch();
    flush_pending(all);
}

static size_t lm_ggml_hexagon_measure_max_vmem(lm_ggml_hexagon_session *sess) {
    // Allocate a bunch pinned buffers till failure.
    // This is kind of expensive but handy for figuring out exactly how much we can mmap on a specific device.
    // Typically we're going to allocate all/most of these buffers anyway for the model weights.

    std::vector<lm_ggml_hexagon_shared_buffer *> sbufs;

    const size_t MiB = 1024 * 1024;
    const size_t GiB = MiB  * 1024;

    size_t vmem = 0;
    size_t step = 256u * MiB;

    try {
        sbufs.push_back(new lm_ggml_hexagon_shared_buffer(sess, GiB, true)); vmem += GiB;
        sbufs.push_back(new lm_ggml_hexagon_shared_buffer(sess, GiB, true)); vmem += GiB;
        sbufs.push_back(new lm_ggml_hexagon_shared_buffer(sess, GiB, true)); vmem += GiB;

        while (1) {
            sbufs.push_back(new lm_ggml_hexagon_shared_buffer(sess, step, true));
            vmem += step;
        }
    } catch (...) { }

    for (auto b : sbufs) { delete b; }

    return vmem - step; // backoff to account for overhead from internal mappings
}

void lm_ggml_hexagon_session::allocate(int dev_id) noexcept(false) {
    this->valid_session = false;
    this->valid_handle  = false;
    this->valid_queue   = false;
    this->valid_iface   = false;

    this->domain_id  = 3;  // Default for CDSP, updated after the session is created
    this->session_id = 0;  // Default for CDSP, updated after the session is created
    this->dev_id     = dev_id;
    this->name       = std::string("HTP") + std::to_string(dev_id);

    this->op_pending  = 0;

    LM_GGML_LOG_DEBUG("ggml-hex: %s allocating new session\n", this->name.c_str());

    domain * my_domain = get_domain(this->domain_id);
    if (my_domain == NULL) {
        LM_GGML_LOG_ERROR("ggml-hex: unable to get domain struct for CDSP\n");
        throw std::runtime_error("ggml-hex: failed to get CDSP domain (see log for details)");
    }

    // Create new session
    if (dev_id != 0) {
        struct remote_rpc_reserve_new_session n;
        n.domain_name_len  = strlen(CDSP_DOMAIN_NAME);
        n.domain_name      = const_cast<char *>(CDSP_DOMAIN_NAME);
        n.session_name     = const_cast<char *>(this->name.c_str());
        n.session_name_len = this->name.size();

        int err = remote_session_control(FASTRPC_RESERVE_NEW_SESSION, (void *) &n, sizeof(n));
        if (err != AEE_SUCCESS) {
            LM_GGML_LOG_ERROR("ggml-hex: failed to reserve new session %d : error 0x%x\n", dev_id, err);
            throw std::runtime_error("ggml-hex: remote_session_control(new-sess) failed (see log for details)");
        }

        // Save the IDs
        this->session_id    = n.session_id;
        this->domain_id     = n.effective_domain_id;
        this->valid_session = true;
    }

    // Get session URI

    char session_uri[256];
    {
        char htp_uri[256];
        snprintf(htp_uri, sizeof(htp_uri), "file:///libggml-htp-v%u.so?htp_iface_skel_handle_invoke&_modver=1.0", opt_arch);

        struct remote_rpc_get_uri u = {};
        u.session_id      = this->session_id;
        u.domain_name     = const_cast<char *>(CDSP_DOMAIN_NAME);
        u.domain_name_len = strlen(CDSP_DOMAIN_NAME);
        u.module_uri      = const_cast<char *>(htp_uri);
        u.module_uri_len  = strlen(htp_uri);
        u.uri             = session_uri;
        u.uri_len         = sizeof(session_uri);

        int err = remote_session_control(FASTRPC_GET_URI, (void *) &u, sizeof(u));
        if (err != AEE_SUCCESS) {
            // fallback to single session uris
            int htp_URI_domain_len = strlen(htp_uri) + MAX_DOMAIN_NAMELEN;

            snprintf(session_uri, htp_URI_domain_len, "%s%s", htp_uri, my_domain->uri);

            LM_GGML_LOG_WARN("ggml-hex: failed to get URI for session %d : error 0x%x. Falling back to single session URI: %s\n", dev_id, err, session_uri);
        }
    }

    // Enable Unsigned PD
    {
        struct remote_rpc_control_unsigned_module u;
        u.domain = this->domain_id;
        u.enable = 1;
        int err  = remote_session_control(DSPRPC_CONTROL_UNSIGNED_MODULE, (void *) &u, sizeof(u));
        if (err != AEE_SUCCESS) {
            LM_GGML_LOG_ERROR("ggml-hex: failed to enable unsigned PD for session %d : error 0x%x\n", dev_id, err);
            throw std::runtime_error("ggml-hex: remote_session_control(unsign) failed (see log for details)");
        }
    }

    // Open session
    int err = htp_iface_open(session_uri, &this->handle);
    if (err != AEE_SUCCESS) {
        LM_GGML_LOG_ERROR("ggml-hex: failed to open session %d : error 0x%x\n", dev_id, err);
        throw std::runtime_error("ggml-hex: failed to open session (see log for details)");
    }

    this->valid_handle = true;

    // Enable FastRPC QoS mode
    {
        struct remote_rpc_control_latency l;
        l.enable = 1;

        int err = remote_handle64_control(this->handle, DSPRPC_CONTROL_LATENCY, (void *) &l, sizeof(l));
        if (err != 0) {
            LM_GGML_LOG_WARN("ggml-hex: failed to enable fastrpc QOS mode: 0x%08x\n", (unsigned) err);
        }
    }

    LM_GGML_LOG_INFO("ggml-hex: %s new session : session-id %d domain-id %d uri %s handle 0x%lx\n", this->c_name(),
                  this->session_id, this->domain_id, session_uri, (unsigned long) this->handle);

    const size_t req_q_size = (sizeof(htp_opbatch_req) * opt_opqueue * 2) + 1024;
    const size_t rsp_q_size = (sizeof(htp_opbatch_rsp) * opt_opqueue * 2) + 1024;

    // Now let's setup the DSP queue
    err = dspqueue_create(this->domain_id,
                          0,              // Flags
                          req_q_size,     // Request  queue size (in bytes)
                          rsp_q_size,     // Response queue size (in bytes)
                          nullptr,        // Read packet callback (we handle reads explicitly)
                          nullptr,        // Error callback (we handle errors during reads)
                          (void *) this,  // Callback context
                          &queue);
    if (err != 0) {
        LM_GGML_LOG_ERROR("ggml-hex: %s dspqueue_create failed: 0x%08x\n", this->name.c_str(), (unsigned) err);
        throw std::runtime_error("ggml-hex: failed to create dspqueue (see log for details)");
    }

    this->valid_queue = true;

    // Export queue for use on the DSP
    err = dspqueue_export(queue, &this->queue_id);
    if (err != 0) {
        LM_GGML_LOG_ERROR("ggml-hex: dspqueue_export failed: 0x%08x\n", (unsigned) err);
        throw std::runtime_error("ggml-hex: dspqueue export failed (see log for details)");
    }

    if (opt_etm) {
        err = htp_iface_etm(this->handle, 1);
        if (err != 0) {
            LM_GGML_LOG_ERROR("ggml-hex: failed to enable ETM tracing: 0x%08x\n", (unsigned) err);
        }
    }

    if (opt_profile) {
        htp_iface_pmu_conf pmu_conf{};
        std::copy(opt_pmu_evt.begin(), opt_pmu_evt.end(), pmu_conf.events);

        err = htp_iface_profiler(this->handle, opt_profile, &pmu_conf);
        if (err != 0) {
            LM_GGML_LOG_ERROR("ggml-hex: failed to enable profiling: 0x%08x\n", (unsigned) err);
        }
    }

    // Allocate buffers and state for op batching
    this->op_queue = new lm_ggml_hexagon_opqueue(this, opt_opbatch, opt_opqueue);

    if (!opt_vmem) {
        opt_vmem = lm_ggml_hexagon_measure_max_vmem(this);
        LM_GGML_LOG_INFO("ggml-hex: %s measured max vmem %zu\n", this->c_name(), opt_vmem);
    }

    this->op_batch = new lm_ggml_hexagon_opbatch(this, opt_opbatch, opt_vmem);

    // Start dspqueue/opbatch processing
    err = htp_iface_start(this->handle, dev_id, this->queue_id, opt_nhvx, opt_use_hmx, opt_vmem);
    if (err != 0) {
        LM_GGML_LOG_ERROR("ggml-hex: %s failed to start session: 0x%08x\n", this->c_name(), (unsigned) err);
        throw std::runtime_error("ggml-hex: iface start failed (see log for details)");
    }
    this->valid_iface = true;
}

void lm_ggml_hexagon_session::release() noexcept(true) {
    LM_GGML_LOG_INFO("ggml-hex: releasing session: %s\n", this->name.c_str());

    int err;

    if (this->valid_iface) {
        // Stop dspqueue/opbatch processing
        err = htp_iface_stop(this->handle);
        if (err != 0) {
            LM_GGML_ABORT("ggml-hex: htp_iface_stop failed: 0x%08x\n", (unsigned) err);
        }
    }

    delete this->op_batch;
    delete this->op_queue;

    if (opt_etm) {
        err = htp_iface_etm(this->handle, 0);
        if (err != 0) {
            LM_GGML_LOG_ERROR("ggml-hex: warn : failed to disable ETM tracing: 0x%08x\n", (unsigned) err);
        }
    }

    if (opt_profile) {
        htp_iface_pmu_conf pmu_conf{};
        err = htp_iface_profiler(this->handle, 0, &pmu_conf);
        if (err != 0) {
            LM_GGML_LOG_ERROR("ggml-hex: warn : failed to disable profiling: 0x%08x\n", (unsigned) err);
        }
    }

    if (this->valid_queue) {
        err = dspqueue_close(queue);
        if (err != 0) {
            LM_GGML_ABORT("ggml-hex: dspqueue_close failed: 0x%08x\n", (unsigned) err);
        }
    }

    if (this->valid_handle) {
        htp_iface_close(this->handle);
    }
}

lm_ggml_hexagon_session::lm_ggml_hexagon_session(int dev_id, lm_ggml_backend_dev_t dev) noexcept(false) {
    buffer_type.device        = dev;
    repack_buffer_type.device = dev;

    op_batch = nullptr;
    op_queue = nullptr;

    try {
        allocate(dev_id);

        buffer_type.iface   = lm_ggml_backend_hexagon_buffer_type_interface;
        buffer_type.context = new lm_ggml_backend_hexagon_buffer_type_context(this->name, this);

        repack_buffer_type.iface   = lm_ggml_backend_hexagon_repack_buffer_type_interface;
        repack_buffer_type.context = new lm_ggml_backend_hexagon_buffer_type_context(this->name + "-REPACK", this);
    } catch (const std::exception & exc) {
        release();
        throw;
    }
}

lm_ggml_hexagon_session::~lm_ggml_hexagon_session() noexcept(true) {
    release();

    delete static_cast<lm_ggml_backend_hexagon_buffer_type_context *>(buffer_type.context);
    delete static_cast<lm_ggml_backend_hexagon_buffer_type_context *>(repack_buffer_type.context);
}

// ** backend interface

static bool lm_ggml_backend_buffer_is_hexagon(const struct lm_ggml_backend_buffer * b) {
    return b->buft->iface.get_alignment == lm_ggml_backend_hexagon_buffer_type_get_alignment;
}

static inline bool lm_ggml_backend_buffer_is_hexagon_repack(const struct lm_ggml_backend_buffer * b) {
    if (!opt_hostbuf) {
        return lm_ggml_backend_buffer_is_hexagon(b);
    }
    return b->buft->iface.alloc_buffer == lm_ggml_backend_hexagon_repack_buffer_type_alloc_buffer;
}

static bool lm_ggml_hexagon_supported_flash_attn_ext(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * src0 = op->src[0];
    const struct lm_ggml_tensor * src1 = op->src[1];
    const struct lm_ggml_tensor * src2 = op->src[2];
    const struct lm_ggml_tensor * src3 = op->src[3];
    const struct lm_ggml_tensor * src4 = op->src[4];
    const struct lm_ggml_tensor * dst  = op;

    // Check for F16 support only as requested
    if ((src0->type != LM_GGML_TYPE_F16 && src0->type != LM_GGML_TYPE_F32) || src1->type != LM_GGML_TYPE_F16 || src2->type != LM_GGML_TYPE_F16) {
        return false;
    }

    if (src3 && src3->type != LM_GGML_TYPE_F16) {  // mask
        return false;
    }

    if (src4 && src4->type != LM_GGML_TYPE_F32) {  // sinks
        return false;
    }

    // For now we support F32 or F16 output as htp backend often converts output on the fly if needed,
    // but the op implementation writes to F16 or F32.
    // Let's assume dst can be F32 or F16.
    if (dst->type != LM_GGML_TYPE_F32 && dst->type != LM_GGML_TYPE_F16) {
        return false;
    }

    if (dst->ne[3] != 1) {
        return false;
    }

    return true;
}

static bool lm_ggml_hexagon_supported_gated_delta_net(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * q     = op->src[0];
    const struct lm_ggml_tensor * k     = op->src[1];
    const struct lm_ggml_tensor * v     = op->src[2];
    const struct lm_ggml_tensor * g     = op->src[3];
    const struct lm_ggml_tensor * beta  = op->src[4];
    const struct lm_ggml_tensor * state = op->src[5];
    const struct lm_ggml_tensor * dst   = op;

    if (!q || !k || !v || !g || !beta || !state) {
        return false;
    }

    if (q->type != LM_GGML_TYPE_F32 || k->type != LM_GGML_TYPE_F32 || v->type != LM_GGML_TYPE_F32 ||
        g->type != LM_GGML_TYPE_F32 || beta->type != LM_GGML_TYPE_F32 || state->type != LM_GGML_TYPE_F32 ||
        dst->type != LM_GGML_TYPE_F32) {
        return false;
    }

    if (!lm_ggml_is_contiguous_rows(q) || !lm_ggml_is_contiguous_rows(k) || !lm_ggml_is_contiguous_rows(v) ||
        !lm_ggml_is_contiguous(g) || !lm_ggml_is_contiguous(beta) || !lm_ggml_is_contiguous(state) ||
        !lm_ggml_is_contiguous(dst)) {
        return false;
    }

    const int64_t S_v      = v->ne[0];
    const int64_t H        = v->ne[1];
    const int64_t n_tokens = v->ne[2];
    const int64_t n_seqs   = v->ne[3];
    const int64_t K        = lm_ggml_get_op_params_i32(op, 0);

    if (S_v <= 0 || S_v > 128 || H <= 0 || n_tokens <= 0 || n_seqs <= 0) {
        return false;
    }
    if (q->ne[0] != S_v || k->ne[0] != S_v || q->ne[1] <= 0 || k->ne[1] <= 0 ||
        q->ne[2] != n_tokens || k->ne[2] != n_tokens || q->ne[3] <= 0 || k->ne[3] <= 0 ||
        (n_seqs % q->ne[3]) != 0 || (n_seqs % k->ne[3]) != 0) {
        return false;
    }
    if ((g->ne[0] != 1 && g->ne[0] != S_v) || beta->ne[0] != 1) {
        return false;
    }
    // state holds s0 only [S_v, S_v, H, n_seqs]; K is op param 0.
    if (lm_ggml_nelements(state) != S_v * S_v * H * n_seqs) {
        return false;
    }
    if (dst->ne[0] != S_v * H || dst->ne[1] != n_tokens * n_seqs + S_v * n_seqs * K) {
        return false;
    }

    LM_GGML_UNUSED(sess);
    return true;
}

static bool lm_ggml_hexagon_supported_mul_mat(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * dst) {
    const struct lm_ggml_tensor * src0 = dst->src[0];
    const struct lm_ggml_tensor * src1 = dst->src[1];

    if (dst->type != LM_GGML_TYPE_F32) {
        return false;
    }

    if (src1->type != LM_GGML_TYPE_F32 && src1->type != LM_GGML_TYPE_F16) {
        return false;
    }

    switch (src0->type) {
        case LM_GGML_TYPE_Q4_0:
        case LM_GGML_TYPE_Q4_1:
        case LM_GGML_TYPE_Q8_0:
        case LM_GGML_TYPE_IQ4_NL:
        case LM_GGML_TYPE_MXFP4:
            if (src0->ne[0] % 32) {
                return false;
            }

            if (lm_ggml_nrows(src0) > 16 * 1024) {
                return false;  // typically the lm-head which would be too large for VTCM
            }

            if (lm_ggml_nrows(src1) > 1024 || src1->ne[2] != 1 || src1->ne[3] != 1) {
                return false;  // no huge batches or broadcasting (for now)
            }

            // src0 (weights) must be repacked
            if (src0->buffer && !lm_ggml_backend_buffer_is_hexagon_repack(src0->buffer)) {
                return false;
            }
            break;

        case LM_GGML_TYPE_F16:
            if (src0->nb[1] < src0->nb[0]) {
                LM_GGML_LOG_DEBUG("lm_ggml_hexagon_supported_mul_mat: permuted F16 src0 not supported\n");
                return false;
            }
            if (src1->ne[2] < src0->ne[2] || src1->ne[3] < src0->ne[3]) {
                LM_GGML_LOG_DEBUG("lm_ggml_hexagon_supported_mul_mat: src1 broadcasting not supported\n");
                return false;
            }
            if (lm_ggml_nrows(src1) > 1024) {
                return false;  // no huge batches (for now)
            }
            break;

        case LM_GGML_TYPE_F32:
            if (src1->type != LM_GGML_TYPE_F32) {
                return false;
            }
            if (src0->nb[1] < src0->nb[0]) {
                LM_GGML_LOG_DEBUG("lm_ggml_hexagon_supported_mul_mat: permuted F32 src0 not supported\n");
                return false;
            }
            if (src1->ne[2] < src0->ne[2] || src1->ne[3] < src0->ne[3]) {
                LM_GGML_LOG_DEBUG("lm_ggml_hexagon_supported_mul_mat: src1 broadcasting not supported\n");
                return false;
            }
            if (lm_ggml_nrows(src1) > 1024) {
                return false;  // no huge batches (for now)
            }
            break;

        default:
            return false;
    }

    return true;
}

static bool lm_ggml_hexagon_supported_mul_mat_id(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * src0 = op->src[0];
    const struct lm_ggml_tensor * src1 = op->src[1];
    const struct lm_ggml_tensor * src2 = op->src[2];
    const struct lm_ggml_tensor * dst  = op;

    if (src1->type != LM_GGML_TYPE_F32 || dst->type != LM_GGML_TYPE_F32 || src2->type != LM_GGML_TYPE_I32) {
        return false;
    }

    switch (src0->type) {
        case LM_GGML_TYPE_Q4_0:
        case LM_GGML_TYPE_Q4_1:
        case LM_GGML_TYPE_Q8_0:
        case LM_GGML_TYPE_IQ4_NL:
        case LM_GGML_TYPE_MXFP4:
            if ((src0->ne[0] % 32)) {
                return false;
            }

            // src0 (weights) must be repacked
            if (src0->buffer && !lm_ggml_backend_buffer_is_hexagon_repack(src0->buffer)) {
                return false;
            }
            break;

        default:
            return false;
    }

    return true;
}

static bool lm_ggml_hexagon_supported_binary(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * src0 = op->src[0];
    const struct lm_ggml_tensor * src1 = op->src[1];
    const struct lm_ggml_tensor * dst  = op;

    if (src0->type == LM_GGML_TYPE_F32) {
        if (src1->type != LM_GGML_TYPE_F32) {
            return false;
        }
        if (dst->type != LM_GGML_TYPE_F32) {
            return false;
        }
    }
    else if (src0->type == LM_GGML_TYPE_F16) {
        if (src1->type != LM_GGML_TYPE_F16) {
            return false;
        }
        if (dst->type != LM_GGML_TYPE_F16) {
            return false;
        }
    }
    else {
        return false;
    }

    if (!lm_ggml_are_same_shape(src0, dst)) {
        return false;
    }
    if (!lm_ggml_can_repeat(src1, src0) || lm_ggml_is_permuted(src1)) {
        return false;
    }

    return true;
}

static bool lm_ggml_hexagon_supported_add_id(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * src0 = op->src[0];
    const struct lm_ggml_tensor * src1 = op->src[1];
    const struct lm_ggml_tensor * dst  = op;

    if (src0->type != LM_GGML_TYPE_F32) {
        return false;
    }
    if (src1->type != LM_GGML_TYPE_F32) {
        return false;
    }
    if (dst->type != LM_GGML_TYPE_F32) {
        return false;
    }
    if (!lm_ggml_are_same_shape(src0, dst)) {
        return false;
    }

    // REVISIT: add support for non-contigiuos tensors
    if (!lm_ggml_is_contiguous(src0) || !lm_ggml_is_contiguous(src1) || !lm_ggml_is_contiguous(dst)) {
        return false;
    }

    return true;
}

static bool lm_ggml_hexagon_supported_unary(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * src0 = op->src[0];
    const struct lm_ggml_tensor * dst  = op;

    if (src0->type != LM_GGML_TYPE_F32) {
        return false;
    }
    if (dst->type != LM_GGML_TYPE_F32) {
        return false;
    }
    if (!lm_ggml_are_same_shape(src0, dst)) {
        return false;
    }

    // dst must be contiguous; src0 may be non-contiguous
    if (!lm_ggml_is_contiguous(dst)) {
        return false;
    }

    return true;
}

static bool lm_ggml_hexagon_supported_sum_rows(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * src0 = op->src[0];
    const struct lm_ggml_tensor * dst  = op;

    if (src0->type != LM_GGML_TYPE_F32) {
        return false;
    }
    if (dst->type != LM_GGML_TYPE_F32) {
        return false;
    }

    // TODO: add support for non-contigiuos tensors
    if (!lm_ggml_is_contiguous(src0) || !lm_ggml_is_contiguous(dst)) {
        return false;
    }

    return true;
}

static bool lm_ggml_hexagon_supported_activations(const struct lm_ggml_hexagon_session * sess,
                                               const struct lm_ggml_tensor *          op) {
    const struct lm_ggml_tensor * src0 = op->src[0];
    const struct lm_ggml_tensor * src1 = op->src[1];
    const struct lm_ggml_tensor * dst  = op;

    if (src0->type != LM_GGML_TYPE_F32) {
        return false;
    }
    if (dst->type != LM_GGML_TYPE_F32) {
        return false;
    }

    if (!lm_ggml_is_contiguous(src0) || !lm_ggml_is_contiguous(dst)) {
        return false;
    }

    if (src1) {
        if (src1->type != LM_GGML_TYPE_F32) {
            return false;
        }
        if (!lm_ggml_are_same_shape(src0, src1)) {
            return false;
        }
        if (!lm_ggml_is_contiguous(src1)) {
            return false;
        }
    }

    return true;
}

static bool lm_ggml_hexagon_supported_softmax(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * src0 = op->src[0];
    const struct lm_ggml_tensor * src1 = op->src[1];
    const struct lm_ggml_tensor * src2 = op->src[2];
    const struct lm_ggml_tensor * dst  = op;

    if (src2) {
        return false;  // FIXME: add support for sinks
    }

    if (src0->type != LM_GGML_TYPE_F32) {
        return false;
    }
    if (dst->type != LM_GGML_TYPE_F32) {
        return false;
    }

    if (src1) {
        if (src1->type != LM_GGML_TYPE_F32 && src1->type != LM_GGML_TYPE_F16) {
            return false;
        }
        if (src0->ne[0] != src1->ne[0]) {
            return false;
        }
        if (src1->ne[1] < src0->ne[1]) {
            return false;
        }
        if (src0->ne[2] % src1->ne[2] != 0) {
            return false;
        }
        if (src0->ne[3] % src1->ne[3] != 0) {
            return false;
        }
    }

    if (src1) {
        if (!lm_ggml_is_contiguous(src0) || !lm_ggml_is_contiguous(src1) || !lm_ggml_is_contiguous(dst)) {
            return false;
        }
    } else {
        if (!lm_ggml_is_contiguous(src0) || !lm_ggml_is_contiguous(dst)) {
            return false;
        }
    }

    // Reject non-HVX-aligned sizes when ne[0] > HVX_F32_LANES
    // The HVX softmax implementation has issues with tail handling for larger non-aligned sizes
    // Small sizes (ne[0] <= 32) work correctly with tail-only processing
    const int64_t ne0 = src0->ne[0];
    if (ne0 > 32 && (ne0 & (32 - 1)) != 0) {
        return false;
    }

    // HVX vector size constraints for softmax
    #define SOFTMAX_MAX_ROW_SIZE 131072  // 128K elements max for numerical precision

    // Reject very large row sizes to avoid numerical precision issues
    // Softmax accumulation over many elements can lead to precision loss
    if (ne0 > SOFTMAX_MAX_ROW_SIZE) {
        return false;
    }

    return true;
}

static bool lm_ggml_hexagon_supported_set_rows(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * src0 = op->src[0]; // values
    const struct lm_ggml_tensor * src1 = op->src[1]; // indices
    const struct lm_ggml_tensor * dst  = op;

    if (src0->type != LM_GGML_TYPE_F32) {
        return false;
    }

    if (src1->type != LM_GGML_TYPE_I32 && src1->type != LM_GGML_TYPE_I64) {
        return false;
    }

    if (dst->type != LM_GGML_TYPE_F16) {
        return false;
    }

    return true;
}

static bool lm_ggml_hexagon_supported_get_rows(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * src0 = op->src[0]; // values
    const struct lm_ggml_tensor * src1 = op->src[1]; // indices
    const struct lm_ggml_tensor * dst  = op;

    if (src0->type != LM_GGML_TYPE_F32) {
        return false;
    }

    if (src1->type != LM_GGML_TYPE_I32 && src1->type != LM_GGML_TYPE_I64) {
        return false;
    }

    if (dst->type != LM_GGML_TYPE_F32) {
        return false;
    }

    return true;
}

static bool lm_ggml_hexagon_supported_argsort(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * src0 = op->src[0]; // values
    const struct lm_ggml_tensor * dst  = op;         // indices

    if (src0->type != LM_GGML_TYPE_F32) {
        return false;
    }

    if (dst->type != LM_GGML_TYPE_I32) {
        return false;
    }

    if (src0->ne[0] > (16*1024)) {
        // reject tensors with huge rows for now
        return false;
    }

    return true;
}

static bool lm_ggml_hexagon_supported_rope(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const int32_t * op_params = &op->op_params[0];

    int mode = op_params[2];

    if (mode == LM_GGML_ROPE_TYPE_VISION) {
        return false;
    }
    if (mode & 1) {
        return false;
    }

    const struct lm_ggml_tensor * src0 = op->src[0];
    const struct lm_ggml_tensor * src1 = op->src[1];
    const struct lm_ggml_tensor * src2 = op->src[2];
    const struct lm_ggml_tensor * dst  = op;

    if (src0->type != LM_GGML_TYPE_F32) {
        return false;  // FIXME: add support for LM_GGML_TYPE_F16 for src0
    }
    if (dst->type != LM_GGML_TYPE_F32) {
        return false;
    }
    if (src1->type != LM_GGML_TYPE_I32) {
        return false;
    }
    if (src2) {
        if (src2->type != LM_GGML_TYPE_F32) {
            return false;
        }
        int n_dims = op_params[1];
        if (src2->ne[0] < (n_dims / 2)) {
            return false;
        }
    }

    if (src2) {
        if (!lm_ggml_is_contiguous(src0) || !lm_ggml_is_contiguous(src1) || !lm_ggml_is_contiguous(src2) ||
            !lm_ggml_is_contiguous(dst)) {
            return false;
        }
    } else {
        if (!lm_ggml_is_contiguous(src0) || !lm_ggml_is_contiguous(src1) || !lm_ggml_is_contiguous(dst)) {
            return false;
        }
    }

    return true;
}

static bool lm_ggml_hexagon_supported_ssm_conv(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * src0 = op->src[0];
    const struct lm_ggml_tensor * src1 = op->src[1];
    const struct lm_ggml_tensor * dst  = op;

    // Only support FP32 for now
    if (src0->type != LM_GGML_TYPE_F32 || src1->type != LM_GGML_TYPE_F32 || dst->type != LM_GGML_TYPE_F32) {
        return false;
    }

    // Check IO tensor shapes and dims
    if (src0->ne[3] != 1 || src1->ne[2] != 1 || src1->ne[3] != 1 || dst->ne[3] != 1) {
        return false; // src0 should be effectively 3D
    }

    const int d_conv = src1->ne[0];
    const int d_inner = src0->ne[1];
    const int n_t = dst->ne[1];
    const int n_s = dst->ne[2];

    if (src0->ne[0] != d_conv - 1 + n_t || src0->ne[1] != d_inner || src0->ne[2] != n_s) {
        return false;
    }
    if (src1->ne[0] != d_conv || src1->ne[1] != d_inner) {
        return false;
    }
    if (dst->ne[0] != d_inner || dst->ne[1] != n_t || dst->ne[2] != n_s) {
        return false;
    }
    if (src0->nb[0] != sizeof(float) || src1->nb[0] != sizeof(float) || dst->nb[0] != sizeof(float)) {
        return false;
    }
    if (src0->nb[1] != src0->ne[0] * sizeof(float) || src1->nb[1] != src1->ne[0] * sizeof(float)) {
        return false;
    }

    return true;
}

static bool lm_ggml_hexagon_supported_pad(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * src0 = op->src[0];
    const struct lm_ggml_tensor * dst  = op;

    if (src0->type != LM_GGML_TYPE_F32 || dst->type != LM_GGML_TYPE_F32) {
        return false;
    }

    LM_GGML_UNUSED(sess);
    return true;
}

static bool lm_ggml_hexagon_supported_cumsum(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * src0 = op->src[0];
    const struct lm_ggml_tensor * dst  = op;

    if (src0->type != LM_GGML_TYPE_F32 || dst->type != LM_GGML_TYPE_F32) {
        return false;
    }

    if (!lm_ggml_is_contiguous(src0) || !lm_ggml_is_contiguous(dst)) {
        return false;
    }

    LM_GGML_UNUSED(sess);
    return true;
}

static bool lm_ggml_hexagon_supported_diag(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * src0 = op->src[0];
    const struct lm_ggml_tensor * dst  = op;

    // diag only supports F32 currently
    if (src0->type != LM_GGML_TYPE_F32 || dst->type != LM_GGML_TYPE_F32) {
        return false;
    }

    // Input must have ne[1] == 1 (vector input)
    if (src0->ne[1] != 1) {
        return false;
    }

    // Output must be square in first two dimensions
    if (dst->ne[0] != dst->ne[1] || dst->ne[0] != src0->ne[0]) {
        return false;
    }

    LM_GGML_UNUSED(sess);
    return true;
}

static bool lm_ggml_hexagon_supported_solve_tri(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * src0 = op->src[0]; // A
    const struct lm_ggml_tensor * src1 = op->src[1]; // B
    const struct lm_ggml_tensor * dst  = op;         // X

    if (!src0 || !src1) {
        return false;
    }

    if (src0->type != LM_GGML_TYPE_F32 || src1->type != LM_GGML_TYPE_F32 || dst->type != LM_GGML_TYPE_F32) {
        return false;
    }

    if (src0->ne[0] != src0->ne[1]) {
        return false;
    }

    if (src0->ne[1] != src1->ne[1]) {
        return false;
    }

    if (src0->ne[2] != src1->ne[2] || src0->ne[3] != src1->ne[3]) {
        return false;
    }

    if (dst->ne[0] != src1->ne[0] || dst->ne[1] != src1->ne[1] || dst->ne[2] != src1->ne[2] || dst->ne[3] != src1->ne[3]) {
        return false;
    }

    LM_GGML_UNUSED(sess);
    return true;
}

static bool lm_ggml_hexagon_supported_tri(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {

    const struct lm_ggml_tensor * src0 = op->src[0];
    const struct lm_ggml_tensor * dst  = op;

    if (src0->type != LM_GGML_TYPE_F32) { return false; }
    if (dst->type  != LM_GGML_TYPE_F32) { return false; }
    if (!lm_ggml_are_same_shape(src0, dst)) { return false; }
    if (!lm_ggml_is_contiguous(src0) || !lm_ggml_is_contiguous(dst)) { return false; }

    return true;

    LM_GGML_UNUSED(sess);
}

static const char * lm_ggml_backend_hexagon_name(lm_ggml_backend_t backend) {
    auto sess = static_cast<lm_ggml_hexagon_session *>(backend->context);
    return sess->c_name();
}

static void lm_ggml_backend_hexagon_free(lm_ggml_backend_t backend) {
    // we just need to delete the backend here
    // the sessions are allocated & freed as part of the registry
    delete backend;
}

static htp_op_code op_remap_to_htp(const lm_ggml_tensor * t) {
    switch (t->op) {
        case LM_GGML_OP_FLASH_ATTN_EXT:  return HTP_OP_FLASH_ATTN_EXT;
        case LM_GGML_OP_MUL_MAT:         return HTP_OP_MUL_MAT;
        case LM_GGML_OP_MUL_MAT_ID:      return HTP_OP_MUL_MAT_ID;
        case LM_GGML_OP_MUL:             return HTP_OP_MUL;
        case LM_GGML_OP_ADD:             return HTP_OP_ADD;
        case LM_GGML_OP_ADD_ID:          return HTP_OP_ADD_ID;
        case LM_GGML_OP_SUB:             return HTP_OP_SUB;
        case LM_GGML_OP_DIV:             return HTP_OP_DIV;
        case LM_GGML_OP_CPY:             return HTP_OP_CPY;
        case LM_GGML_OP_CONT:            return HTP_OP_CPY;
        case LM_GGML_OP_GET_ROWS:        return HTP_OP_GET_ROWS;
        case LM_GGML_OP_SET_ROWS:        return HTP_OP_SET_ROWS;
        case LM_GGML_OP_SUM_ROWS:        return HTP_OP_SUM_ROWS;
        case LM_GGML_OP_ARGSORT:         return HTP_OP_ARGSORT;
        case LM_GGML_OP_NORM:            return HTP_OP_NORM;
        case LM_GGML_OP_L2_NORM:         return HTP_OP_L2_NORM;
        case LM_GGML_OP_RMS_NORM:        return HTP_OP_RMS_NORM;
        case LM_GGML_OP_CONCAT:          return HTP_OP_CONCAT;
        case LM_GGML_OP_SCALE:           return HTP_OP_SCALE;
        case LM_GGML_OP_SQR:             return HTP_OP_SQR;
        case LM_GGML_OP_SQRT:            return HTP_OP_SQRT;
        case LM_GGML_OP_SOFT_MAX:        return HTP_OP_SOFTMAX;
        case LM_GGML_OP_SSM_CONV:        return HTP_OP_SSM_CONV;
        case LM_GGML_OP_GATED_DELTA_NET: return HTP_OP_GATED_DELTA_NET;
        case LM_GGML_OP_ROPE:            return HTP_OP_ROPE;
        case LM_GGML_OP_REPEAT:          return HTP_OP_REPEAT;
        case LM_GGML_OP_CUMSUM:          return HTP_OP_CUMSUM;
        case LM_GGML_OP_FILL:            return HTP_OP_FILL;
        case LM_GGML_OP_DIAG:            return HTP_OP_DIAG;
        case LM_GGML_OP_SOLVE_TRI:       return HTP_OP_SOLVE_TRI;
        case LM_GGML_OP_TRI:             return HTP_OP_TRI;
        case LM_GGML_OP_PAD:             return HTP_OP_PAD;

        case LM_GGML_OP_UNARY:
            switch (lm_ggml_get_unary_op(t)) {
                case LM_GGML_UNARY_OP_SILU:       return HTP_OP_UNARY_SILU;
                case LM_GGML_UNARY_OP_GELU:       return HTP_OP_UNARY_GELU;
                case LM_GGML_UNARY_OP_GELU_QUICK: return HTP_OP_UNARY_GELU;
                case LM_GGML_UNARY_OP_SIGMOID:    return HTP_OP_UNARY_SIGMOID;
                case LM_GGML_UNARY_OP_NEG:        return HTP_OP_UNARY_NEG;
                case LM_GGML_UNARY_OP_EXP:        return HTP_OP_UNARY_EXP;
                case LM_GGML_UNARY_OP_SOFTPLUS:   return HTP_OP_UNARY_SOFTPLUS;
                case LM_GGML_UNARY_OP_TANH:       return HTP_OP_UNARY_TANH;
            default:
                break;
            }
            break;

        case LM_GGML_OP_GLU:
            switch (lm_ggml_get_glu_op(t)) {
                case LM_GGML_GLU_OP_SWIGLU:     return HTP_OP_GLU_SWIGLU;
                case LM_GGML_GLU_OP_SWIGLU_OAI: return HTP_OP_GLU_SWIGLU_OAI;
                case LM_GGML_GLU_OP_GEGLU:      return HTP_OP_GLU_GEGLU;
                default: break;
            }
            break;

        default:
            LM_GGML_ABORT("\nggml-hex: graph-compute %s is not supported\n", lm_ggml_op_desc(t));
    }
    return HTP_OP_INVALID;
}

static inline bool op_is_compute(lm_ggml_tensor *node)
{
    return !lm_ggml_op_is_empty(node->op) && !lm_ggml_is_empty(node) && (node->flags & LM_GGML_TENSOR_FLAG_COMPUTE);
}

static lm_ggml_status lm_ggml_backend_hexagon_graph_compute(lm_ggml_backend_t backend, lm_ggml_cgraph * graph) {
    auto sess = static_cast<lm_ggml_hexagon_session *>(backend->context);

    HEX_VERBOSE("ggml-hex: %s graph-compute n_nodes %d\n", sess->c_name(), graph->n_nodes);

    std::vector<htp_opnode> nodes;
    nodes.reserve(graph->n_nodes);

    // Fusion
    for (int i = 0; i < graph->n_nodes; ++i) {
        lm_ggml_tensor * n = graph->nodes[i];
        if (!op_is_compute(n)) {
            continue;
        }

        lm_ggml_tensor * next_node = (i + 1 < graph->n_nodes) ? graph->nodes[i + 1] : nullptr;

        htp_opnode node = {
            /*.node =*/ n,
            /*.fused =*/ {},
            /*.opcode =*/ HTP_OP_INVALID
        };

        if (n->op == LM_GGML_OP_RMS_NORM && next_node) {
            if (next_node->op == LM_GGML_OP_MUL && op_is_compute(next_node) && lm_ggml_can_fuse(graph, i, { LM_GGML_OP_RMS_NORM, LM_GGML_OP_MUL })) {
                node.add_fused(next_node);
                node.opcode = HTP_OP_RMS_NORM_MUL;
                i++; // skip the fused MUL node
            }
        }

        if (node.opcode == HTP_OP_INVALID) {
            node.opcode = op_remap_to_htp(n);
        }

        nodes.push_back(std::move(node));
    }

    // Queue and execute
    if (opt_opstage & HTP_OPSTAGE_QUEUE) {
        for (const auto & node : nodes) {
            sess->enqueue_op(node);
        }
    }

    // Wait until all pending ops complete
    sess->flush();

    return LM_GGML_STATUS_SUCCESS;
}

static void lm_ggml_backend_hexagon_synchronize(lm_ggml_backend_t backend) {
    auto sess = static_cast<lm_ggml_hexagon_session *>(backend->context);

    HEX_VERBOSE("ggml-hex: %s synchronize\n", sess->c_name());

    // Wait until all pending ops complete
    sess->flush();
}

static std::vector<int> lm_ggml_hexagon_graph_optimize_reorder(const std::vector<htp_opnode> & nodes) {
    const int n = nodes.size();

    std::vector<int> res;
    res.reserve(n);

    std::vector<bool> used(n, false);

    // The main goal here is to stack the MUL_MAT ops with the same src1 input.
    // This allows use to reuse dynamically quantized src1 in VTCM.

    // TODO: the current version might do incorrect reordering in cases where quantized src0
    //       input is an output of another Op.

    for (int i0 = 0; i0 < n; i0++) {
        if (used[i0]) {
            continue;
        }

        res.push_back(i0);

        const auto & node0 = nodes[i0];

        if (!node0.stackable()) {
            continue;
        }

        // that many nodes forward to search for stackable nodes that can reuse VTCM
        constexpr int N_FORWARD = 16;

        for (int i1 = i0 + 1; i1 < i0 + N_FORWARD && i1 < n; i1++) {
            if (used[i1]) {
                continue;
            }

            const auto & node1 = nodes[i1];

            if (node1.stackable() && node1.same_input(node0)) {
                res.push_back(i1);
                used[i1] = true;
            }
        }
    }

    return res;
}

static void lm_ggml_backend_hexagon_graph_optimize(lm_ggml_backend_t backend, lm_ggml_cgraph * gf) {
    const int n = gf->n_nodes;

    constexpr int MAX_FUSE = 16;

    enum lm_ggml_op ops[MAX_FUSE];

    std::vector<htp_opnode> nodes;
    nodes.reserve(gf->n_nodes);

    // fuse nodes:
    // we don't want to make reorders that break fusing, so we first pack all fusable tensors
    //   and perform the reorder over the fused nodes. after the reorder is done, we unfuse
    for (int i = 0; i < n; i++) {
        htp_opnode node = {
            /*.node =*/gf->nodes[i],
            /*.fused =*/{},
        };

        // fuse only ops that start with these operations
        // can be expanded when needed
        if (node.op() == LM_GGML_OP_ADD ||
            node.op() == LM_GGML_OP_NORM ||
            node.op() == LM_GGML_OP_RMS_NORM) {
            ops[0] = node.op();

            int f = i + 1;
            while (f < n && f < i + MAX_FUSE) {
                // conservatively allow fusing only these ops
                // can be expanded when needed
                if (gf->nodes[f]->op != LM_GGML_OP_ADD &&
                    gf->nodes[f]->op != LM_GGML_OP_MUL &&
                    gf->nodes[f]->op != LM_GGML_OP_NORM &&
                    gf->nodes[f]->op != LM_GGML_OP_RMS_NORM) {
                    break;
                }
                ops[f - i] = gf->nodes[f]->op;
                f++;
            }

            f -= i;
            for (; f > 1; f--) {
                if (lm_ggml_can_fuse(gf, i, ops, f)) {
                    break;
                }
            }

            // add the fused tensors into the node info so we can unfuse them later
            for (int k = 1; k < f; k++) {
                ++i;

                // the .dst() becomes the last fused tensor
                node.add_fused(gf->nodes[i]);
            }
        }

        nodes.push_back(std::move(node));
    }

    const auto order = lm_ggml_hexagon_graph_optimize_reorder(nodes);

    // unfuse
    {
        int j = 0;
        for (const auto i : order) {
            const auto & node = nodes[i];

            gf->nodes[j++] = node.node;

            for (auto * fused : node.fused) {
                gf->nodes[j++] = fused;
            }
        }
    }
}

static struct lm_ggml_backend_i hexagon_backend_i = {
    /* .get_name                = */ lm_ggml_backend_hexagon_name,
    /* .free                    = */ lm_ggml_backend_hexagon_free,
    /* .set_tensor_async        = */ NULL,
    /* .get_tensor_async        = */ NULL,
    /* .set_tensor_2d_async     = */ NULL,
    /* .get_tensor_2d_async     = */ NULL,
    /* .cpy_tensor_async        = */ NULL,
    /* .synchronize             = */ lm_ggml_backend_hexagon_synchronize,
    /* .graph_plan_create       = */ NULL,
    /* .graph_plan_free         = */ NULL,
    /* .graph_plan_update       = */ NULL,
    /* .graph_plan_compute      = */ NULL,
    /* .graph_compute           = */ lm_ggml_backend_hexagon_graph_compute,
    /* .event_record            = */ NULL,
    /* .event_wait              = */ NULL,
    /* .graph_optimize          = */ lm_ggml_backend_hexagon_graph_optimize,
};

static lm_ggml_guid_t lm_ggml_backend_hexagon_guid() {
    static lm_ggml_guid guid = { 0x7b, 0x57, 0xdc, 0xaf, 0xde, 0x12, 0x1d, 0x49,
                              0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x11 };
    return &guid;
}

bool lm_ggml_backend_is_hexagon(lm_ggml_backend_t backend) {
    return backend && backend->iface.get_name == lm_ggml_backend_hexagon_name;
}

// device interface

static lm_ggml_backend_t lm_ggml_backend_hexagon_device_init(lm_ggml_backend_dev_t dev, const char * params) {
    auto sess = static_cast<lm_ggml_hexagon_session *>(dev->context);

    return new lm_ggml_backend{
        /* .guid      = */ lm_ggml_backend_hexagon_guid(),
        /* .interface = */ hexagon_backend_i,
        /* .device    = */ dev,
        /* .context   = */ sess,
    };

    LM_GGML_UNUSED(params);
}

static const char * lm_ggml_backend_hexagon_device_get_name(lm_ggml_backend_dev_t dev) {
    auto sess = static_cast<lm_ggml_hexagon_session *>(dev->context);
    return sess->c_name();

    LM_GGML_UNUSED(dev);
}

static const char * lm_ggml_backend_hexagon_device_get_description(lm_ggml_backend_dev_t dev) {
    return "Hexagon";
    LM_GGML_UNUSED(dev);
}

static void lm_ggml_backend_hexagon_device_get_memory(lm_ggml_backend_dev_t dev, size_t * free, size_t * total) {
    *free  = 0;
    *total = *free;

    LM_GGML_UNUSED(dev);
}

static enum lm_ggml_backend_dev_type lm_ggml_backend_hexagon_device_get_type(lm_ggml_backend_dev_t dev) {
    return LM_GGML_BACKEND_DEVICE_TYPE_GPU;

    LM_GGML_UNUSED(dev);
}

static void lm_ggml_backend_hexagon_device_get_props(lm_ggml_backend_dev_t dev, struct lm_ggml_backend_dev_props * props) {
    props->name        = lm_ggml_backend_hexagon_device_get_name(dev);
    props->description = lm_ggml_backend_hexagon_device_get_description(dev);
    props->type        = lm_ggml_backend_hexagon_device_get_type(dev);
    lm_ggml_backend_hexagon_device_get_memory(dev, &props->memory_free, &props->memory_total);
    props->caps = {
        /* .async                 = */ true,
        /* .host_buffer           = */ (bool) opt_hostbuf,
        /* .buffer_from_host_ptr  = */ false,
        /* .events                = */ false,
    };
}

static lm_ggml_backend_buffer_type_t lm_ggml_backend_hexagon_device_get_buffer_type(lm_ggml_backend_dev_t dev) {
    auto sess = static_cast<lm_ggml_hexagon_session *>(dev->context);
    return &sess->buffer_type;
}

static lm_ggml_backend_buffer_type_t lm_ggml_backend_hexagon_device_get_repack_buffer_type(lm_ggml_backend_dev_t dev) {
    auto sess = static_cast<lm_ggml_hexagon_session *>(dev->context);
    return &sess->repack_buffer_type;
}

static bool lm_ggml_hexagon_supported_buffer(lm_ggml_hexagon_session *sess, const struct lm_ggml_tensor * t) {
    if (t && t->buffer) {
        if (lm_ggml_backend_buffer_is_hexagon(t->buffer)      == false) return false; // not our buffer
        if (lm_ggml_backend_hexagon_buffer_get_sess(t->buffer) != sess) return false; // wrong session
    }
    return true;
}

static bool lm_ggml_hexagon_supported_buffers(lm_ggml_hexagon_session *sess, const struct lm_ggml_tensor * t) {
    // all srcs & dsts must be mapped to the same session
    if (!lm_ggml_hexagon_supported_buffer(sess, t)) {
        return false;
    }

    for (int i = 0; i < LM_GGML_MAX_SRC; i++) {
        if (!lm_ggml_hexagon_supported_buffer(sess, t->src[i])) {
            return false;
        }
    }

    return true;
}

static bool lm_ggml_hexagon_supported_cpy(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * src0 = op->src[0];
    const struct lm_ggml_tensor * dst  = op;

    // for now we can do f32 -> f16 and f16 -> f32 (without reshaping)
    if (src0->type != LM_GGML_TYPE_F32 && src0->type != LM_GGML_TYPE_F16) return false;
    if ( dst->type != LM_GGML_TYPE_F32 &&  dst->type != LM_GGML_TYPE_F16) return false;

    const bool sametype   = (src0->type == dst->type);
    const bool transposed = lm_ggml_is_transposed(src0) || lm_ggml_is_transposed(dst);
    const bool sameshape  = !transposed && lm_ggml_are_same_shape(src0, dst);

    // can handle any shape and any same-type (pretty slow if reshaping is required)
    if (sametype) return true;

    // cannot handle re-shaping and type conversion at the same time
    if (!sameshape) return false;

    return true;
}

static bool lm_ggml_hexagon_supported_cont(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    LM_GGML_UNUSED(sess);
    const struct lm_ggml_tensor * src0 = op->src[0];

    // CONT is same-type only, supports f32 and f16
    if (src0->type != LM_GGML_TYPE_F32 && src0->type != LM_GGML_TYPE_F16) return false;

    return true;
}

static bool lm_ggml_hexagon_supported_repeat(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    LM_GGML_UNUSED(sess);
    const struct lm_ggml_tensor * src0 = op->src[0];
    const struct lm_ggml_tensor * dst  = op;

    // Support f32 and f16
    if (src0->type != LM_GGML_TYPE_F32 && src0->type != LM_GGML_TYPE_F16) return false;

    // src and dst must be the same type
    if (src0->type != dst->type) return false;

    // dst dims must be multiples of src dims
    if (dst->ne[0] % src0->ne[0] != 0) return false;
    if (dst->ne[1] % src0->ne[1] != 0) return false;
    if (dst->ne[2] % src0->ne[2] != 0) return false;
    if (dst->ne[3] % src0->ne[3] != 0) return false;

    // require contiguous tensors (no transposition)
    if (lm_ggml_is_transposed(src0) || lm_ggml_is_transposed(dst)) return false;

    return true;
}

static bool lm_ggml_hexagon_supported_concat(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    int dim = ((const int32_t *) op->op_params)[0];
    if (dim < 0 || dim >= LM_GGML_MAX_DIMS) {
        return false;
    }

    for (int i = 0; i < LM_GGML_MAX_SRC; ++i) {
        const struct lm_ggml_tensor * src = op->src[i];
        if (!src) {
            continue;
        }
        if (src->type != LM_GGML_TYPE_F32 && src->type != LM_GGML_TYPE_I32 && src->type != LM_GGML_TYPE_F16) {
            return false;
        }
    }

    return true;
}

static bool lm_ggml_hexagon_supported_fill(const struct lm_ggml_hexagon_session * sess, const struct lm_ggml_tensor * op) {
    const struct lm_ggml_tensor * dst = op;

    if (dst->type != LM_GGML_TYPE_F32 && dst->type != LM_GGML_TYPE_F16) {
        return false;
    }

    LM_GGML_UNUSED(sess);
    return true;
}

static bool lm_ggml_backend_hexagon_device_supports_op(lm_ggml_backend_dev_t dev, const struct lm_ggml_tensor * op) {
    auto sess = static_cast<lm_ggml_hexagon_session *>(dev->context);

    // reject ops that match the filter
    if (opt_opfilter && std::regex_match(lm_ggml_op_desc(op), *opt_opfilter)) {
        return false;
    }

    // all srcs & dsts must be mapped to the same session
    if (!lm_ggml_hexagon_supported_buffers(sess, op)) {
        lm_ggml_hexagon_dump_op_supp(sess->name, op, false);
        return false;
    }

    bool supp = false;
    switch (op->op) {
        case LM_GGML_OP_NONE:
        case LM_GGML_OP_RESHAPE:
        case LM_GGML_OP_VIEW:
        case LM_GGML_OP_PERMUTE:
        case LM_GGML_OP_TRANSPOSE:
            supp = true;
            break;

        case LM_GGML_OP_MUL:
        case LM_GGML_OP_ADD:
        case LM_GGML_OP_SUB:
        case LM_GGML_OP_DIV:
            supp = lm_ggml_hexagon_supported_binary(sess, op);
            break;

        case LM_GGML_OP_MUL_MAT:
            supp = lm_ggml_hexagon_supported_mul_mat(sess, op);
            break;

        case LM_GGML_OP_MUL_MAT_ID:
            supp = lm_ggml_hexagon_supported_mul_mat_id(sess, op);
            break;

        case LM_GGML_OP_ADD_ID:
            supp = lm_ggml_hexagon_supported_add_id(sess, op);
            break;

        case LM_GGML_OP_NORM:
        case LM_GGML_OP_L2_NORM:
        case LM_GGML_OP_RMS_NORM:
        case LM_GGML_OP_SCALE:
            supp = lm_ggml_hexagon_supported_unary(sess, op);
            break;

        case LM_GGML_OP_SQR:
        case LM_GGML_OP_SQRT:
            supp = lm_ggml_hexagon_supported_unary(sess, op);
            break;

        case LM_GGML_OP_SUM_ROWS:
            supp = lm_ggml_hexagon_supported_sum_rows(sess, op);
            break;

        case LM_GGML_OP_SOFT_MAX:
            supp = lm_ggml_hexagon_supported_softmax(sess, op);
            break;

        case LM_GGML_OP_UNARY:
            switch (lm_ggml_get_unary_op(op)) {
                case LM_GGML_UNARY_OP_NEG:
                case LM_GGML_UNARY_OP_EXP:
                case LM_GGML_UNARY_OP_SIGMOID:
                case LM_GGML_UNARY_OP_SOFTPLUS:
                case LM_GGML_UNARY_OP_TANH:
                    supp = lm_ggml_hexagon_supported_unary(sess, op);
                    break;
                case LM_GGML_UNARY_OP_SILU:
                case LM_GGML_UNARY_OP_GELU:
                case LM_GGML_UNARY_OP_GELU_QUICK:
                    supp = lm_ggml_hexagon_supported_activations(sess, op);
                    break;
                default:
                    break;
            }
            break;

        case LM_GGML_OP_GLU:
            switch (lm_ggml_get_glu_op(op)) {
                case LM_GGML_GLU_OP_SWIGLU:
                case LM_GGML_GLU_OP_SWIGLU_OAI:
                case LM_GGML_GLU_OP_GEGLU:
                    supp = lm_ggml_hexagon_supported_activations(sess, op);
                    break;
                default:
                    break;
            }
            break;

        case LM_GGML_OP_ROPE:
            supp = lm_ggml_hexagon_supported_rope(sess, op);
            break;

        case LM_GGML_OP_FLASH_ATTN_EXT:
            supp = lm_ggml_hexagon_supported_flash_attn_ext(sess, op);
            break;

        case LM_GGML_OP_SET_ROWS:
            supp = lm_ggml_hexagon_supported_set_rows(sess, op);
            break;

        case LM_GGML_OP_GET_ROWS:
            supp = lm_ggml_hexagon_supported_get_rows(sess, op);
            break;

        case LM_GGML_OP_CPY:
            supp = lm_ggml_hexagon_supported_cpy(sess, op);
            break;

        case LM_GGML_OP_CONT:
            supp = lm_ggml_hexagon_supported_cont(sess, op);
            break;

        case LM_GGML_OP_REPEAT:
            supp = lm_ggml_hexagon_supported_repeat(sess, op);
            break;

        case LM_GGML_OP_ARGSORT:
            supp = lm_ggml_hexagon_supported_argsort(sess, op);
            break;

        case LM_GGML_OP_SSM_CONV:
            supp = lm_ggml_hexagon_supported_ssm_conv(sess, op);
            break;

        case LM_GGML_OP_GATED_DELTA_NET:
            supp = lm_ggml_hexagon_supported_gated_delta_net(sess, op);
            break;

        case LM_GGML_OP_CUMSUM:
            supp = lm_ggml_hexagon_supported_cumsum(sess, op);
            break;

        case LM_GGML_OP_CONCAT:
            supp = lm_ggml_hexagon_supported_concat(sess, op);
            break;

        case LM_GGML_OP_FILL:
            supp = lm_ggml_hexagon_supported_fill(sess, op);
            break;

        case LM_GGML_OP_DIAG:
            supp = lm_ggml_hexagon_supported_diag(sess, op);
            break;

        case LM_GGML_OP_SOLVE_TRI:
            supp = lm_ggml_hexagon_supported_solve_tri(sess, op);
            break;

        case LM_GGML_OP_TRI:
            supp = lm_ggml_hexagon_supported_tri(sess, op);
            break;

        case LM_GGML_OP_PAD:
            supp = lm_ggml_hexagon_supported_pad(sess, op);
            break;

        default:
            break;
    }

    lm_ggml_hexagon_dump_op_supp(sess->name, op, supp);
    return supp;
}

static bool lm_ggml_backend_hexagon_device_supports_buft(lm_ggml_backend_dev_t dev, lm_ggml_backend_buffer_type_t buft) {
    if (buft->iface.get_alignment != lm_ggml_backend_hexagon_buffer_type_get_alignment) {
        return false;
    }

    auto s0 = static_cast<lm_ggml_hexagon_session *>(dev->context);
    auto s1 = static_cast<lm_ggml_backend_hexagon_buffer_type_context *>(buft->context)->sess;

    // Need session/domain-id for buffers to be compatible
    bool supp = (s0->session_id == s1->session_id);

    HEX_VERBOSE("ggml-hex: %s device-supports-buft %s (%d)\n", s0->name.c_str(), s1->name.c_str(), (int) supp);

    return supp;
}

static lm_ggml_backend_buffer_type_t * lm_ggml_backend_hexagon_device_get_extra_buffers_type(lm_ggml_backend_dev_t dev) {
    auto s0 = static_cast<lm_ggml_hexagon_session *>(dev->context);
    HEX_VERBOSE("ggml-hex: device-get-extra-buft : %s \n", s0->name.c_str());

    static lm_ggml_backend_buffer_type_t bufts[2];
    bufts[0] = lm_ggml_backend_hexagon_device_get_repack_buffer_type(dev);
    bufts[1] = NULL;
    return bufts;
}

static const struct lm_ggml_backend_device_i lm_ggml_backend_hexagon_device_i = {
    /* .get_name             = */ lm_ggml_backend_hexagon_device_get_name,
    /* .get_description      = */ lm_ggml_backend_hexagon_device_get_description,
    /* .get_memory           = */ lm_ggml_backend_hexagon_device_get_memory,
    /* .get_type             = */ lm_ggml_backend_hexagon_device_get_type,
    /* .get_props            = */ lm_ggml_backend_hexagon_device_get_props,
    /* .init_backend         = */ lm_ggml_backend_hexagon_device_init,
    /* .get_buffer_type      = */ lm_ggml_backend_hexagon_device_get_buffer_type,
    /* .get_host_buffer_type = */ NULL,  // lm_ggml_backend_hexagon_device_get_host_buffer_type,
    /* .buffer_from_host_ptr = */ NULL,  // lm_ggml_backend_hexagon_device_buffer_from_ptr,
    /* .supports_op          = */ lm_ggml_backend_hexagon_device_supports_op,
    /* .supports_buft        = */ lm_ggml_backend_hexagon_device_supports_buft,
    /* .offload_op           = */ NULL,  // lm_ggml_backend_hexagon_device_offload_op,
    /* .event_new            = */ NULL,
    /* .event_free           = */ NULL,
    /* .event_synchronize    = */ NULL,
};

//** backend registry

#define LM_GGML_HEXAGON_MAX_SESSIONS 16

struct lm_ggml_hexagon_registry {
    lm_ggml_hexagon_registry(lm_ggml_backend_reg_t reg);
    ~lm_ggml_hexagon_registry();

    lm_ggml_backend_device devices[LM_GGML_HEXAGON_MAX_SESSIONS];
};

lm_ggml_hexagon_registry::lm_ggml_hexagon_registry(lm_ggml_backend_reg_t reg) {
    LM_GGML_LOG_INFO("ggml-hex: Hexagon backend (experimental) : allocating new registry : ndev %zu\n", opt_ndev);

    LM_GGML_LOG_INFO("ggml-hex: Hexagon Arch version v%d\n", opt_arch);

    // Create devices / sessions
    for (size_t i = 0; i < opt_ndev; i++) {
        devices[i].iface = lm_ggml_backend_hexagon_device_i;
        devices[i].reg   = reg;
        try {
            devices[i].context = new lm_ggml_hexagon_session(i, &devices[i]);
        } catch (const std::exception & exc) {
            LM_GGML_LOG_ERROR("ggml-hex: failed to create device/session %zu\n", i);
            devices[i].context = nullptr;
            opt_ndev = i;
            break;
        }
    }
}

lm_ggml_hexagon_registry::~lm_ggml_hexagon_registry() {
    LM_GGML_LOG_INFO("ggml-hex: releasing registry\n");

    // Release devices / sessions
    for (size_t i = 0; i < opt_ndev; i++) {
        auto sess = static_cast<lm_ggml_hexagon_session *>(devices[i].context);
        delete sess;
    }
}

static const char * lm_ggml_backend_hexagon_reg_get_name(lm_ggml_backend_reg_t reg) {
    return "HTP";
    LM_GGML_UNUSED(reg);
}

static size_t lm_ggml_backend_hexagon_reg_get_device_count(lm_ggml_backend_reg_t reg) {
    return opt_ndev;
    LM_GGML_UNUSED(reg);
}

static lm_ggml_backend_dev_t lm_ggml_backend_hexagon_reg_get_device(lm_ggml_backend_reg_t reg, size_t index) {
    auto hreg = static_cast<lm_ggml_hexagon_registry *>(reg->context);

    if (index >= opt_ndev || !hreg->devices[index].context) {
        return nullptr;
    }

    return &hreg->devices[index];
}

static void * lm_ggml_backend_hexagon_get_proc_address(lm_ggml_backend_reg_t reg, const char * name) {
    if (strcmp(name, "lm_ggml_backend_dev_get_extra_bufts") == 0 && opt_hostbuf) {
        lm_ggml_backend_dev_get_extra_bufts_t fct = lm_ggml_backend_hexagon_device_get_extra_buffers_type;
        return (void *) fct;
    }

    return NULL;
}

template<typename T> std::vector<T> str_to_vec(const char* str) {
    std::stringstream ss(str);
    std::vector<T> v;
    std::string    t;

    while (std::getline(ss, t, ',')) {
        v.push_back(std::stoul(t, nullptr, 0));
    }

    return v;
}

template<typename T, int BASE=10> std::string vec_to_str(std::vector<T> v) {
    std::stringstream ss;
    ss << std::setbase(BASE) << std::showbase;
    for (auto i : v) { ss << i << ','; }
    auto str = ss.str(); str.pop_back(); // drop last comma
    return str;
}

static void lm_ggml_hexagon_init(lm_ggml_backend_reg * reg) {
    // Basic sanity checks to make sure definitions match
    static_assert((unsigned int) HTP_TYPE_Q4_0 == (unsigned int) LM_GGML_TYPE_Q4_0,
                  "please update hexagon_type to match lm_ggml_type");
    static_assert((unsigned int) HTP_TYPE_Q4_1 == (unsigned int) LM_GGML_TYPE_Q4_1,
                  "please update hexagon_type to match lm_ggml_type");
    static_assert((unsigned int) HTP_TYPE_Q8_0 == (unsigned int) LM_GGML_TYPE_Q8_0,
                  "please update hexagon_type to match lm_ggml_type");
    static_assert((unsigned int) HTP_TYPE_MXFP4 == (unsigned int) LM_GGML_TYPE_MXFP4,
                  "please update hexagon_type to match lm_ggml_type");
    static_assert((unsigned int) HTP_TYPE_IQ4_NL == (unsigned int) LM_GGML_TYPE_IQ4_NL,
                  "please update hexagon_type to match lm_ggml_type");

    const char * str_verbose  = getenv("LM_GGML_HEXAGON_VERBOSE");
    const char * str_hostbuf  = getenv("LM_GGML_HEXAGON_HOSTBUF");
    const char * str_opstage  = getenv("LM_GGML_HEXAGON_OPSTAGE");
    const char * str_opbatch  = getenv("LM_GGML_HEXAGON_OPBATCH");
    const char * str_opqueue  = getenv("LM_GGML_HEXAGON_OPQUEUE");
    const char * str_oppoll   = getenv("LM_GGML_HEXAGON_OPPOLL");
    const char * str_optrace  = getenv("LM_GGML_HEXAGON_OPTRACE");
    const char * str_opfilter = getenv("LM_GGML_HEXAGON_OPFILTER");
    const char * str_profile  = getenv("LM_GGML_HEXAGON_PROFILE");
    const char * str_etm      = getenv("LM_GGML_HEXAGON_ETM");
    const char * str_nhvx     = getenv("LM_GGML_HEXAGON_NHVX");
    const char * str_use_hmx  = getenv("LM_GGML_HEXAGON_USE_HMX");
    const char * str_ndev     = getenv("LM_GGML_HEXAGON_NDEV");
    const char * str_arch     = getenv("LM_GGML_HEXAGON_ARCH");
    const char * str_vmem     = getenv("LM_GGML_HEXAGON_VMEM");
    const char * str_mbuf     = getenv("LM_GGML_HEXAGON_MBUF");

    // Init Arch first since it affects other defaults
    if (!str_arch) {
        int err = get_hex_arch_ver(CDSP_DOMAIN_ID, &opt_arch);
        if (err != 0) {
            LM_GGML_LOG_ERROR("ggml-hex: failed to query HTP version (err %d) defaulting to v73\n", err);
            opt_arch = 73;
        }
    } else {
        if (str_arch[0] == 'v' || str_arch[0] == 'V') {
            str_arch++;
        }
        opt_arch = strtoul(str_arch, NULL, 0);
    }

    size_t MiB = 1024 * 1024;

    // Update vmem default
    opt_vmem = opt_arch >= 75 ? HTP_OP_MAX_VMEM_DEFAULT : 3000 * MiB;

    auto RE_ICASE = std::regex_constants::icase;

    opt_opfilter  = str_opfilter ? new std::regex(str_opfilter, RE_ICASE) : NULL;
    opt_verbose   = str_verbose  ? atoi(str_verbose)                      : 0;
    opt_hostbuf   = str_hostbuf  ? atoi(str_hostbuf)                      : opt_hostbuf;
    opt_opstage   = str_opstage  ? strtoul(str_opstage, NULL, 0)          : opt_opstage;
    opt_opbatch   = str_opbatch  ? strtoul(str_opbatch, NULL, 0)          : opt_opbatch;
    opt_opqueue   = str_opqueue  ? strtoul(str_opqueue, NULL, 0)          : opt_opqueue;
    opt_oppoll    = str_oppoll   ? strtoul(str_oppoll,  NULL, 0)          : opt_oppoll;
    opt_optrace   = str_optrace  ? strtoul(str_optrace, NULL, 0)          : (opt_opbatch * 128);
    opt_profile   = str_profile  ? atoi(str_profile)                      : 0;
    opt_etm       = str_etm      ? atoi(str_etm)                          : 0;
    opt_nhvx      = str_nhvx     ? strtoul(str_nhvx, NULL, 0)             : opt_nhvx;
    opt_use_hmx   = str_use_hmx  ? atoi(str_use_hmx)                      : opt_use_hmx;
    opt_ndev      = str_ndev     ? strtoul(str_ndev, NULL, 0)             : opt_ndev;
    opt_hostbuf   = str_hostbuf  ? atoi(str_hostbuf)                      : opt_hostbuf;
    opt_mbuf      = str_mbuf     ? strtoul(str_mbuf, NULL, 0) * MiB       : opt_mbuf;
    opt_vmem      = str_vmem     ? strtoul(str_vmem, NULL, 0) * MiB       : opt_vmem;

    if (opt_ndev > LM_GGML_HEXAGON_MAX_SESSIONS) {
        opt_ndev = LM_GGML_HEXAGON_MAX_SESSIONS;
    }

#if defined(__ANDROID__)
    if (opt_arch < 75) {
        opt_ndev = 1;
        LM_GGML_LOG_WARN("ggml-hex: forcing ndev to 1 for SoCs archs lower than v75.\n");
    }
#endif

    if (str_profile) {
        opt_pmu_evt = [&]() -> std::vector<uint32_t> {
            auto v  = str_to_vec<uint32_t>(str_profile);
            switch (v.size()) {
                case 1:  opt_profile = v[0]; return opt_pmu_evt; // mode with default pmu events
                case 8:  opt_profile = 2;    return v;           // mode with custom  pmu events
                default: opt_profile = 0;    return {};          // garbage input
            }}();
        if (opt_profile == 1) opt_pmu_evt = {};
        LM_GGML_LOG_INFO("ggml-hex: Profiling mode %u : pmu-evt [ %s ]\n", opt_profile,
                vec_to_str<uint32_t, 16>(opt_pmu_evt).c_str());
    }

    reg->context = new lm_ggml_hexagon_registry(reg);
}

static const struct lm_ggml_backend_reg_i lm_ggml_backend_hexagon_reg_i = {
    /* .get_name         = */ lm_ggml_backend_hexagon_reg_get_name,
    /* .get_device_count = */ lm_ggml_backend_hexagon_reg_get_device_count,
    /* .get_device       = */ lm_ggml_backend_hexagon_reg_get_device,
    /* .get_proc_address = */ lm_ggml_backend_hexagon_get_proc_address,
};

lm_ggml_backend_reg_t lm_ggml_backend_hexagon_reg(void) {
    static bool initialized = false;

    static lm_ggml_backend_reg reg = { /* .api_version = */ LM_GGML_BACKEND_API_VERSION,
                                    /* .iface       = */ lm_ggml_backend_hexagon_reg_i,
                                    /* .context     = */ NULL };

    {
        static std::mutex           mutex;
        std::lock_guard<std::mutex> lock(mutex);
        if (!initialized) {
            auto nErr = htpdrv_init();
            if (nErr != AEE_SUCCESS) {
                return NULL;
            }

            lm_ggml_hexagon_init(&reg);
        }

        initialized = true;
    }

    return &reg;
}

LM_GGML_BACKEND_DL_IMPL(lm_ggml_backend_hexagon_reg)
